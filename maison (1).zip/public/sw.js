/*
 * MAISON service worker — quiet dispatch alerts.
 *
 * Registered only at moments of reader intent (onboarding Step 2 or the
 * Settings section), never on page load. Push payloads are built by the
 * server (see src/lib/server/push.ts): one collapsed notification per
 * source per ingestion run, tagged by source so the tray never stacks
 * duplicates from the same desk.
 */

const ICON = '/push-icon.png'

self.addEventListener('install', () => {
  self.skipWaiting()
})

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim())
})

self.addEventListener('push', (event) => {
  let data = {}
  try {
    data = event.data ? event.data.json() : {}
  } catch {
    data = {}
  }
  const title = data.displayTitle || 'MAISON'
  const body = data.body || 'A new dispatch has landed on the wire.'
  event.waitUntil(
    self.registration.showNotification(title, {
      body,
      icon: ICON,
      badge: ICON,
      // Same desk → replaces the previous card instead of stacking.
      tag: data.sourceId || 'maison',
      data: {
        url: data.url || '/',
        itemId: data.itemId || null,
      },
    })
  )
})

self.addEventListener('notificationclick', (event) => {
  event.notification.close()
  const url = (event.notification.data && event.notification.data.url) || '/'
  const itemId = (event.notification.data && event.notification.data.itemId) || null
  event.waitUntil(
    (async () => {
      // Prefer an open reader: focus it and lift the dispatch straight
      // into the modal; otherwise open a fresh one at the deep link.
      const clientList = await self.clients.matchAll({
        type: 'window',
        includeUncontrolled: true,
      })
      for (const client of clientList) {
        if ('focus' in client) {
          await client.focus()
          client.postMessage({ type: 'maison:open-item', itemId })
          return
        }
      }
      await self.clients.openWindow(url)
    })()
  )
})
