# MAISON — The Whole Wire, Beautifully Set

A production-ready, personalized editorial news wire: **85+ real RSS outlets**, optional **YouTube Data API** video ingestion, cross-source **story clustering**, full-text search, user accounts with server-side personalization, and an admin source-registry dashboard — in a considered magazine-inspired interface.

> Aggregation & discovery only. Headlines, short snippets, thumbnails and links out — never full article text. All rights remain with the original publishers (see the in-app About/Methodology page).

## Refinement summary

- **Design preserved, then polished:** retained the original MAISON editorial layout, warm paper-and-ink palette, supplied photography, serif/sans typography, and quiet gold accents. Added an adaptive deeper gold only for text on paper surfaces; the original light gold remains on dark overlays and decorative details.
- **Accessibility and interaction:** added a skip link, complete keyboard handling for the mobile menu, visible focus and reduced-motion/no-JavaScript safeguards. The main CTA keeps its editorial styling and transitions to a readable charcoal label over its gold hover layer.
- **Performance and debloat:** prioritize the lead image and self-host fonts at build time. Removed 66 unreferenced component files and cut declared direct dependencies from 78 to 23, while retaining active authentication, APIs, database features, and the story-brief SDK.
- **SEO and release safety:** add verified route declarations, WebSite structured data, accurate sharing metadata, and canonical/sitemap/feed URLs only when a real public origin is set. Preview/production session cookies default to `Secure; SameSite=None`; insecure cookies require a narrow local-development opt-in.
- **Quality gates:** TypeScript and ESLint pass; the standalone production build and homepage, route manifest, robots, sitemap, RSS, and anonymous-session endpoints return valid responses. Preview checks used a database copy; the supplied SQLite file remains unchanged.

---

## Quick start

```bash
# 1. Prerequisites: Node.js ≥ 20.9, npm 10.9, and an isolated MySQL database
cp .env.example .env.local    # never use a production DATABASE_URL locally

# 2. Install the pinned dependency set
npm ci

# 3. Apply committed, additive Prisma migrations to the configured database
npm run db:migrate

# 4. (Optional, empty isolated DB only) seed the source registry and an
#    explicitly configured administrator; this is not part of deployment
npm run seed

# 5. Run
npm run dev                   # http://localhost:3000
```

The first visit triggers a full ingestion cycle (~15s); the dashboard fills with live headlines immediately after. A background scheduler re-fetches every source on its own interval (5–30 min) with exponential backoff on failures.

The managed Webdev project supplies its MySQL `DATABASE_URL`; development and publication share that database. The committed `db/custom.db` is the original SQLite data snapshot used by the one-time migration, not the production datasource. The initial import of all 58,280 rows across nine application tables has been completed and verified with matching per-table SHA-256 digests. `scripts/migrate-sqlite-to-mysql.py` is an explicit, guarded one-time transfer utility; do not run seed scripts against the shared project database.

Guests get a fully usable terminal with sensible defaults; preferences persist locally until they create an account.

---

## What's inside

### Content pipeline
- **Source registry (DB-backed, admin-editable)** — no hard-coded feed lists; add/edit/disable/remove sources at runtime. 87 seeded RSS feeds from real publishers (BBC, Guardian, NYT, WSJ, Al Jazeera, NPR, CNBC, MarketWatch, Al Jazeera, DW, France 24, Euronews, Sky, CBC, Times of India, Economic Times, SCMP, Japan Times, Variety, Billboard, …). Feed URLs were live-verified; dead/blocked feeds were replaced during development.
- **Normalized content model** — RSS, YouTube and Instagram entries all map into one schema (`content_items`: type, title, snippet, source, author, topics, url, thumbnail, duration, language, country, `contentHash`).
- **Background scheduler** — per-source `fetchIntervalMin`, exponential backoff (×1…×5) on consecutive failures, per-source health logs, hourly retention pruning (`RETENTION_DAYS`, default 14). Started via `instrumentation.ts` **and** lazily from `/api/status` (idempotent).
- **Robust fetching** — UA rotation for CDN-hostile publishers, BOM/prologue-tolerant XML parsing, per-source error isolation (one bad feed never breaks ingestion for others).
- **Story clustering** — normalized titles + token-set Jaccard similarity with an inverted-index candidate lookup. Multi-source events merge into one card with "also covered by" chips.
- **Featured / Trending scoring** — `Σ(source prominence × recency decay) + 1.5 × distinct sources` over 48h/24h windows.

### YouTube integration
- Server-side only API key (`YOUTUBE_API_KEY`); uploads-playlist polling with duration enrichment; quota-exceeded → cached data + "key required" state instead of a broken UI.
- Without a key (the default), YouTube sources idle gracefully and the UI explains why. 20 verified news channels are pre-seeded.

### Instagram integration (honest fallback)
- Instagram's official API cannot aggregate public content without business-account linkage + app review. There is **no scraping and no fake content**: 12 curated accounts render as clearly-labeled link-out cards that deep-link to instagram.com. The limitation is documented in the admin panel and About page.

### Reader experience
- **Top bar** — global search (⌘K), live "UPD hh:mm" refresh indicator, theme toggle, account menu.
- **Featured** — clustered hero grid with cross-source attribution chips.
- **Live ticker** — recent headlines marquee (paused on hover, respects reduced motion).
- **Topic columns** — independently scrollable feeds (Latest, Trending + 11 topics), articles/videos interleaved, hide/reorder/drag in Settings, per-column skeletons and error states.
- **Newsroom** — dedicated two-pane Written News | Video layout with topic filter.
- **Search** — full-text + topic/source/type/language/date-range filters, newest/most-covered/by-source sorting, pagination.
- **Sources** — full registry with health badges (active/degraded/error), last-fetch times; click-through filters the whole dashboard.
- **Saved** — account-backed bookmarks with optimistic toggle.
- **Admin** — overview stats (7-day ingestion chart, top topics/sources), source CRUD + manual refetch + enable/disable, health logs, topic taxonomy, users.
- **Design system** — warm paper/charcoal editions with restrained gold details, Playfair Display + Inter, semantic editorial sections, keyboard-visible focus, reduced-motion support, and responsive layouts from mobile to desktop.

### Security
- `npm run db:backup` snapshots only the local SQLite migration source to `db/backups/` (rolling, last 7 kept); it is not a managed-MySQL backup. `npm run db:migrate` runs committed Prisma migrations and never resets or seeds data.
- scrypt password hashing, HMAC-signed httpOnly session cookies, role-gated admin APIs, parameterized queries via Prisma, per-IP sliding-window rate limits (auth: 8/15min, register: 5/15min, content: 120/min, manual ingest: 6/min), per-account login lockout (5 consecutive failures → 15-minute cooldown, generic error message), input validation on every mutation, secrets only in env vars (`.env.example` documents each).

### Performance
- In-memory TTL cache (30–45s hot queries) with **data-epoch invalidation** — every ingestion run bumps the epoch so stale cache entries die instantly.
- Paginated APIs (`page`/`pageSize` capped at 60), per-column feeds fetched and capped server-side, 60s status polling with client-side "new items" detection — no web-socket storms.

---

## Architecture

```
src/
├── app/                         # App Router UI, APIs, SEO, readiness endpoint
├── components/luxe/              # MAISON editorial sections and interactions
└── lib/
    ├── server/
    │   ├── prisma-connection.ts  # strict managed-MySQL TLS normalization
    │   ├── ingest.ts             # RSS/YouTube/Instagram pipeline + scheduler
    │   ├── cluster.ts            # dedupe/clustering/scoring engine
    │   ├── content.ts            # query layer + interleave + cache glue
    │   └── auth.ts               # sessions, scrypt hashing
    ├── db.ts                     # Prisma singleton
    └── types.ts                  # shared DTOs
scripts/
├── migrate-sqlite-to-mysql.py   # read-only export + collision preflight
├── import-mysql-snapshot.ts     # transactional import + digest verification
├── run-prisma-migrate.cjs       # schema deploy with strict TLS URL mapping
└── seed.ts                      # guarded; empty isolated database only
prisma/migrations/               # additive MySQL migrations
Dockerfile                       # pinned standalone production container
```

**Database and deployment:** Prisma targets managed MySQL/TiDB through the runtime-provided `DATABASE_URL`. Production uses committed, additive migrations (`npm run db:migrate`), a Node standalone container, and a DB readiness probe. Never use `db:push --accept-data-loss` against shared data. The original SQLite file remains a migration/backup artifact only. Before horizontal scaling, move the per-process scheduler into a dedicated worker/queue and replace the in-memory cache with a shared cache behind the existing `cacheGet/cacheSet` surface.

---

## Configuration reference

| Variable | Required | Purpose |
|---|---|---|
| `DATABASE_URL` | yes | Managed MySQL/TiDB DSN injected by Webdev; standalone development must use a separate isolated MySQL database |
| `AUTH_SECRET` | yes in production | Stable cryptographically random session HMAC key (at least 32 characters), supplied through protected production secret input; development may use a private generated key |
| `MAISON_ALLOW_HTTP_LOCAL_COOKIES` | no | Set `true` only for plain-HTTP local-network development; Preview/production default to `Secure; SameSite=None` |
| `ADMIN_EMAIL` / `ADMIN_PASSWORD` | optional seed only | Explicit administrator account for an empty, isolated development database; password must be at least 16 characters |
| `DEMO_EMAIL` / `DEMO_PASSWORD` | optional seed only | Optional explicitly configured demo account; no default credentials are shipped |
| `YOUTUBE_API_KEY` | no | Enables video ingestion (server-side only) |
| `INSTAGRAM_ACCESS_TOKEN` | no | Official API for owned accounts; otherwise link-out |
| `NEXT_PUBLIC_SITE_URL` | no | Real public HTTPS origin for canonical tags, social URLs, sitemap and RSS; omitted when unset |
| `RETENTION_DAYS` | no | Content retention (default 14) |
| `MAISON_DISABLE_BACKGROUND_INGESTION` | no | Set `true` only for a read-only smoke run; disables startup scheduler/bootstrap. Normal deployments should leave it unset. |

## Testing & verification

Core workflows verified end-to-end during development:
- Ingestion populates 2,800+ real articles from 84 healthy sources on a fresh DB
- Clustering groups multi-outlet coverage (verified 4–6 source clusters)
- Search/filter/sort combinations (e.g. `technology + video + last 24h`)
- Guest customization → localStorage; sign-in → server-side prefs
- Bookmarks save/persist per account; admin add/disable source reflects in dashboard
- Light/dark themes + desktop/tablet/mobile breakpoints
