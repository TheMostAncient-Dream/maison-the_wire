/**
 * Thumbnail backfill — one-shot repair pass over existing ContentItem rows.
 *
 * Phase 1 — repair: decode double-escaped entities (&#038; → &), null out
 *           tracking pixels / beacons masquerading as thumbnails.
 * Phase 2 — enrich: every article still missing a thumbnail gets its page
 *           fetched (head only) and its og:image / twitter:image scraped.
 *
 * Safe to re-run: only touches rows that still need work.
 */
import { db } from "../src/lib/db";
import {
  decodeUrlEntities,
  isUsableImageUrl,
  scrapePageImage,
} from "../src/lib/server/image";

const CONCURRENCY = 12;

async function main() {
  const total = await db.contentItem.count();
  const withThumbBefore = await db.contentItem.count({ where: { NOT: { thumbnailUrl: null } } });
  console.log(`[backfill] total=${total} withThumb=${withThumbBefore} missing=${total - withThumbBefore}`);

  // ── Phase 1: repair entity-mangled URLs, drop tracking pixels ──
  const candidates = await db.contentItem.findMany({
    where: { thumbnailUrl: { not: null } },
    select: { id: true, thumbnailUrl: true },
  });
  let repaired = 0;
  let dropped = 0;
  for (const row of candidates) {
    const orig = row.thumbnailUrl!;
    let next = decodeUrlEntities(orig);
    if (!isUsableImageUrl(next)) next = "";
    if (next !== orig) {
      await db.contentItem.update({
        where: { id: row.id },
        data: { thumbnailUrl: next || null },
      });
      if (next) repaired++;
      else dropped++;
    }
  }
  console.log(`[backfill] phase1: repaired=${repaired} dropped-junk=${dropped}`);

  // ── Phase 2: scrape og:image for everything still missing ──
  const missing = await db.contentItem.findMany({
    where: { thumbnailUrl: null, type: { not: "video" } },
    select: { id: true, url: true },
    orderBy: { publishedAt: "desc" },
  });
  console.log(`[backfill] phase2: enriching ${missing.length} articles (concurrency=${CONCURRENCY})`);

  let found = 0;
  let done = 0;
  let cursor = 0;
  const startedAt = Date.now();

  async function worker(wid: number) {
    while (cursor < missing.length) {
      const target = missing[cursor++];
      if (!target) break;
      const img = await scrapePageImage(target.url, 9_000);
      if (img) {
        await db.contentItem.update({ where: { id: target.id }, data: { thumbnailUrl: img } });
        found++;
      }
      done++;
      if (done % 50 === 0) {
        const rate = (done / ((Date.now() - startedAt) / 1000)).toFixed(1);
        console.log(`[backfill]   ${done}/${missing.length} done, ${found} images found (${rate}/s, w${wid})`);
      }
    }
  }

  await Promise.all(Array.from({ length: CONCURRENCY }, (_, i) => worker(i)));

  const withThumbAfter = await db.contentItem.count({ where: { NOT: { thumbnailUrl: null } } });
  console.log(
    `[backfill] DONE in ${((Date.now() - startedAt) / 1000).toFixed(0)}s — coverage ${withThumbBefore}/${total} → ${withThumbAfter}/${total} (${((withThumbAfter / total) * 100).toFixed(1)}%)`
  );
  await db.$disconnect();
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
