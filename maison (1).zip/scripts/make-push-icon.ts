/**
 * Generates public/push-icon.png — the glyph used inside browser
 * notifications (192×192, charcoal plate, gold serif M).
 * Run with: bun scripts/make-push-icon.ts
 */
import sharp from 'sharp'

const SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="192" height="192">
  <rect width="192" height="192" fill="#1A1A1A"/>
  <rect x="8" y="8" width="176" height="176" fill="none" stroke="#D4AF37" stroke-width="2" opacity="0.55"/>
  <text x="96" y="128" text-anchor="middle" font-family="Georgia, 'Times New Roman', serif"
        font-size="96" fill="#D4AF37">M</text>
</svg>`

await sharp(Buffer.from(SVG)).png().toFile('public/push-icon.png')
console.log('public/push-icon.png written')
