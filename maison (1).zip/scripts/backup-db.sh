#!/usr/bin/env bash
# Rolling snapshot of the supplied local SQLite migration input only.
# It does not back up the project's shared managed-MySQL database.
set -euo pipefail
cd "$(dirname "$0")/.."

mkdir -p db/backups
if [ -f db/custom.db ]; then
  target="db/backups/custom-$(date +%Y%m%d%H%M%S).db"
  cp db/custom.db "$target"
  # Retention cap: newest 7 survive.
  ls -1t db/backups/custom-*.db 2>/dev/null | tail -n +8 | xargs -r rm -f
  echo "[db:backup] $(basename "$target") saved (retaining last 7)"
else
  echo "[db:backup] no db/custom.db yet — nothing to back up"
fi
