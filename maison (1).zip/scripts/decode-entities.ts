/**
 * One-off repair — decode HTML entities stored in ContentItem titles and
 * snippets (some feeds, notably Yahoo, pre-escape their fields), and
 * recompute contentHash so future ingestions (which now decode on write)
 * dedupe against the repaired rows instead of inserting decoded twins.
 *
 * Idempotent: safe to run any number of times. P2002 collisions (a decoded
 * title already existing for the same source) are logged and skipped — the
 * polluted row stays rather than risking a destructive dedupe.
 *
 * Run with: bun scripts/decode-entities.ts
 */
import { db } from '../src/lib/db'
import { contentHash } from '../src/lib/server/cluster'
import { decodeEntities } from '../src/lib/server/ingest'

async function main() {
  const items = await db.contentItem.findMany({
    select: { id: true, title: true, snippet: true, contentHash: true, sourceId: true },
  })
  let fixed = 0
  let skipped = 0
  for (const it of items) {
    const title = decodeEntities(it.title).trim()
    const snippet = it.snippet ? decodeEntities(it.snippet) : null
    const hash = contentHash(title)
    if (title === it.title && snippet === it.snippet && hash === it.contentHash) continue
    try {
      await db.contentItem.update({
        where: { id: it.id },
        data: { title, snippet, contentHash: hash },
      })
      fixed++
    } catch (e: any) {
      if (e?.code === 'P2002') {
        skipped++
        continue
      }
      throw e
    }
  }
  console.log(
    `decode-entities: ${fixed} repaired, ${skipped} skipped (hash collision), ${items.length} scanned`
  )
}

main()
  .catch((e) => {
    console.error(e)
    process.exitCode = 1
  })
  .finally(() => db.$disconnect())
