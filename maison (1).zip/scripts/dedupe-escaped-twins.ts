/**
 * Remove the escaped-title duplicates that carry a clean twin:
 * rows whose contentHash no longer matches their decoded title AND whose
 * decoded (sourceId, contentHash) already exists. Reader bookmarks move to
 * the clean twin first (deduping if a reader saved both), then the
 * polluted row goes. Run AFTER the server runs the decode-on-ingest code.
 *
 * Run with: bun scripts/dedupe-escaped-twins.ts
 */
import { db } from '../src/lib/db'
import { contentHash } from '../src/lib/server/cluster'
import { decodeEntities } from '../src/lib/server/ingest'

async function main() {
  const items = await db.contentItem.findMany({
    select: { id: true, title: true, sourceId: true, contentHash: true },
  })
  let removed = 0
  for (const it of items) {
    const hash = contentHash(decodeEntities(it.title).trim())
    if (hash === it.contentHash) continue
    const twin = await db.contentItem.findFirst({
      where: { sourceId: it.sourceId, contentHash: hash },
      select: { id: true },
    })
    if (!twin) continue // no clean twin — repair scripts handle this row, leave it
    const marks = await db.bookmark.findMany({
      where: { itemId: it.id },
      select: { id: true, userId: true },
    })
    for (const mark of marks) {
      try {
        await db.bookmark.update({ where: { id: mark.id }, data: { itemId: twin.id } })
      } catch {
        // reader saved both twins — the polluted mark is a strict duplicate
        await db.bookmark.delete({ where: { id: mark.id } }).catch(() => {})
      }
    }
    await db.contentItem.delete({ where: { id: it.id } })
    removed++
    console.log(`removed polluted twin ${it.id}: ${it.title.slice(0, 80)}`)
  }
  console.log(`dedupe-escaped-twins: ${removed} removed`)
}

main()
  .catch((e) => {
    console.error(e)
    process.exitCode = 1
  })
  .finally(() => db.$disconnect())
