/**
 * Live-update verification helper.
 *   bun run scripts/live-update-test.ts insert N   → adds N synthetic dispatches (newest first)
 *   bun run scripts/live-update-test.ts cleanup    → removes every synthetic dispatch
 */
import { db } from "../src/lib/db";

const MARK = "WIRE-TEST::";

async function insert(n: number) {
  const source = await db.source.findFirst({ where: { type: "rss", isActive: true }, select: { id: true } });
  if (!source) throw new Error("no active rss source");
  const rows = Array.from({ length: n }, (_, i) => ({
    type: "article" as const,
    title: `${MARK}dispatch ${Date.now()}-${i} — synthetic verification story`,
    snippet: "Inserted by the live-update verification script; safe to disregard and delete.",
    sourceId: source.id,
    author: "Verification Desk",
    url: "https://example.com/wire-test",
    thumbnailUrl: null,
    durationSec: null,
    language: "en",
    country: "us",
    topicSlugs: JSON.stringify(["world"]),
    publishedAt: new Date(Date.now() + n - i), // i=0 is newest
    contentHash: `wire-test-${Date.now()}-${i}`,
  }));
  await db.contentItem.createMany({ data: rows });
  console.log(`inserted ${n} synthetic dispatches`);
}

async function cleanup() {
  const res = await db.contentItem.deleteMany({ where: { title: { startsWith: MARK } } });
  console.log(`deleted ${res.count} synthetic dispatches`);
}

const mode = process.argv[2];
if (mode === "insert") await insert(Number(process.argv[3] ?? 1));
else if (mode === "cleanup") await cleanup();
else console.log("usage: insert <n> | cleanup");
await db.$disconnect();
