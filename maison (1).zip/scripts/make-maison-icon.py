#!/usr/bin/env python3
"""
MAISON site icon — the brand mark, v2.

v1: charcoal plate, alabaster Playfair "M" (true glyph outline), gold rule.
v2: an N joins the monogram — half the M's cap height, angled toward
perpendicular, crossing the M's right stem. Wherever the N's edge passes
over the M's ink, the intersection is outlined in pure white (the classic
interlocked-monogram trick: both letters stay legible through the crossing).

VARIANT picks the live reading of the brief:
    "half" → 45°, halfway to perpendicular            [live]
    "perp" → 90°, fully perpendicular, baseline-aligned

Outputs (whole family, regenerated together):
  src/app/icon.svg                        vector favicon (white outline via clipPath)
  src/app/favicon.ico                     16/32/48
  src/app/apple-icon.png                  180  iOS home screen
  public/push-icon.png                    192  sw.js notification icon/badge + manifest
  public/maison-icon-512.png              512  manifest icon
  download/maison-icon-preview.png        live variant, 512
  download/maison-icon-alt-<other>.png    the other reading, for the eye

Run: python3 scripts/make-maison-icon.py
"""
import math
import os

from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.ttLib import TTFont
from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont

ROOT = "/home/z/my-project"
MEDIA = os.path.join(ROOT, ".next", "static", "media")
FONT_SUBSET = "2a65768255d6b625-s.p.d19752fb.woff2"  # roman latin subset, wght 400 default

CHARCOAL = (26, 26, 26, 255)       # #1A1A1A
ALABASTER = (249, 248, 246, 255)   # #F9F8F6
GOLD = (212, 175, 55, 255)         # #D4AF37
WHITE = (255, 255, 255, 255)       # pure white for the intersection outline

S = 512.0           # design box (SVG viewBox)
MASTER = 1024       # PNG supersample box
K = MASTER / S
H_TARGET = 300.0    # M glyph height in the 512 box (~59%)
W_MAX = 380.0
GAP = 38.0          # M bottom -> rule
RULE_H = 8.0
RULE_W_FRAC = 0.86
N_FRAC = 0.5        # N cap height = half the M's
BAND = 6.0          # white outline thickness, 512-space px

VARIANT = "half"    # "half" = 45° (live) | "perp" = 90° (fully perpendicular)
ROT = {"half": 45.0, "perp": 90.0}

# ---------------------------------------------------------------- font ----
src = os.path.join(MEDIA, FONT_SUBSET)
font = TTFont(src)
font.flavor = None
ttf_path = os.path.join(ROOT, "scripts", ".maison-playfair.ttf")
font.save(ttf_path)

cmap = font.getBestCmap()
glyphset = font.getGlyphSet()


def glyph(ch: str):
    """(svg path d, bounds (x0,y0,x1,y1)) for a character, font units."""
    gname = cmap[ord(ch)]
    spen = SVGPathPen(glyphset)
    glyphset[gname].draw(spen)
    bpen = BoundsPen(glyphset)
    glyphset[gname].draw(bpen)
    return spen.getCommands(), bpen.bounds


dM, bM = glyph("M")
dN, bN = glyph("N")
x0M, y0M, x1M, y1M = bM
x0N, y0N, x1N, y1N = bN
wM_u, hM_u = x1M - x0M, y1M - y0M
wN_u, hN_u = x1N - x0N, y1N - y0N

# ------------------------------------------------- M layout (512 space) ----
sM = H_TARGET / hM_u
if wM_u * sM > W_MAX:
    sM = W_MAX / wM_u
gwM, ghM = wM_u * sM, hM_u * sM
comp_h = ghM + GAP + RULE_H
topM = (S - comp_h) / 2
txM = (S - gwM) / 2 - x0M * sM
tyM = topM + sM * y1M
m_left = (S - gwM) / 2
m_baseline = topM + ghM                      # 383
rw = gwM * RULE_W_FRAC
rx, ry = (S - rw) / 2, m_baseline + GAP      # rule at y 421

# --------------------------------------------- N layout (512 space) ----
sN = (ghM * N_FRAC) / hN_u                   # half the M's cap height
gwN_u, ghN_u = wN_u * sN, hN_u * sN          # upright footprint


def n_placement(theta: float):
    """center (cx, cy) of the rotated N in 512-space."""
    if abs(theta - 90.0) < 1e-9:
        # baseline-aligned: rotated height = upright width
        return 385.0, m_baseline - gwN_u / 2
    return 390.0, 292.0


def n_transform_svg(theta: float, cx: float, cy: float) -> str:
    """SVG transform mapping the glyph center onto (cx, cy).
    SVG rotate() is clockwise in y-down space."""
    a = math.radians(theta)
    pcx, pcy = sN * (x0N + x1N) / 2, -sN * (y0N + y1N) / 2  # after scale, before rotate
    rcx = math.cos(a) * pcx - math.sin(a) * pcy
    rcy = math.sin(a) * pcx + math.cos(a) * pcy
    return (f"translate({cx - rcx:.2f} {cy - rcy:.2f}) "
            f"rotate({theta:g}) scale({sN:.6f} {-sN:.6f})")


# ------------------------------------------------------------ PIL build ----
def tight_glyph_layer(ch: str, target_h_px: float) -> Image.Image:
    """Render one glyph tightly cropped, RGBA, ink color = alabaster."""
    probe = ImageFont.truetype(ttf_path, 1000)
    pb = probe.getbbox(ch)
    F = int(round(1000.0 * target_h_px / (pb[3] - pb[1])))
    fnt = ImageFont.truetype(ttf_path, F)
    layer = Image.new("RGBA", (MASTER * 2, MASTER * 2), (0, 0, 0, 0))
    dr = ImageDraw.Draw(layer)
    dr.text((MASTER, MASTER), ch, font=fnt, fill=ALABASTER)
    return layer.crop(layer.getbbox())


def composite(theta: float, center: tuple) -> Image.Image:
    """Full mark at master scale."""
    cx, cy = center[0] * K, center[1] * K
    img = Image.new("RGBA", (MASTER, MASTER), CHARCOAL)

    # M ink + its canvas-space alpha
    m_layer = tight_glyph_layer("M", ghM * K)
    m_pos = (round(m_left * K), round(topM * K))
    img.paste(m_layer, m_pos, m_layer)
    m_alpha = Image.new("L", (MASTER, MASTER), 0)
    m_alpha.paste(m_layer.split()[3], m_pos)

    # gold rule
    dr = ImageDraw.Draw(img)
    dr.rectangle([rx * K, ry * K, (rx + rw) * K, (ry + RULE_H) * K], fill=GOLD)

    # N: tight layer -> rotate -> paste centered on (cx, cy)
    n_layer = tight_glyph_layer("N", ghN_u * K)
    resample = Image.NEAREST if theta % 90 == 0 else Image.BICUBIC
    n_rot = n_layer.rotate(-theta, expand=True, resample=resample)  # PIL CCW+, SVG CW+
    n_pos = (round(cx - n_rot.width / 2), round(cy - n_rot.height / 2))
    img.paste(n_rot, n_pos, n_rot)
    n_alpha = Image.new("L", (MASTER, MASTER), 0)
    n_alpha.paste(n_rot.split()[3], n_pos)

    # white outline: inner border band of the N, clipped to the M's ink
    band_px = int(round(BAND * K))
    eroded = n_alpha.filter(ImageFilter.MinFilter(2 * band_px + 1))
    band = ImageChops.subtract(n_alpha, eroded)
    over_m = ImageChops.multiply(band, m_alpha)
    white = Image.new("RGBA", (MASTER, MASTER), WHITE)
    white.putalpha(over_m)
    img.alpha_composite(white)
    return img


# ---------------------------------------------------------------- SVG ----
def build_svg(theta: float, center: tuple) -> str:
    tn = n_transform_svg(theta, *center)
    tM = f"translate({txM:.2f} {tyM:.2f}) scale({sM:.6f} {-sM:.6f})"
    sw = BAND / sN  # stroke in glyph units; the N transform scales it back to BAND px
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
  <!-- MAISON site mark — Playfair Display "M" crossed by an N angled {theta:g}deg
       (half the M's cap height); their intersection is outlined in white.
       Generated by scripts/make-maison-icon.py from the next/font cache;
       regenerate, do not hand-edit. -->
  <defs>
    <clipPath id="m-ink"><path d="{dM}" transform="{tM}"/></clipPath>
  </defs>
  <rect width="512" height="512" fill="#1A1A1A"/>
  <path d="{dM}" fill="#F9F8F6" transform="{tM}"/>
  <rect x="{rx:.2f}" y="{ry:.2f}" width="{rw:.2f}" height="{RULE_H:.0f}" fill="#D4AF37"/>
  <path d="{dN}" fill="#D4AF37" transform="{tn}"/>
  <g clip-path="url(#m-ink)">
    <path d="{dN}" fill="none" stroke="#FFFFFF" stroke-width="{sw:.1f}" transform="{tn}"/>
  </g>
</svg>
'''


# -------------------------------------------------------------- export ----
def export(img: Image.Image, svg: str, preview_name: str) -> None:
    with open(os.path.join(ROOT, "src", "app", "icon.svg"), "w") as fh:
        fh.write(svg)
    img.resize((512, 512), Image.LANCZOS).save(os.path.join(ROOT, preview_name))
    img.resize((512, 512), Image.LANCZOS).save(os.path.join(ROOT, "public", "maison-icon-512.png"))
    img.resize((192, 192), Image.LANCZOS).save(os.path.join(ROOT, "public", "push-icon.png"))
    img.resize((180, 180), Image.LANCZOS).save(os.path.join(ROOT, "src", "app", "apple-icon.png"))
    img.save(os.path.join(ROOT, "src", "app", "favicon.ico"), sizes=[(16, 16), (32, 32), (48, 48)])


theta = ROT[VARIANT]
center = n_placement(theta)
export(composite(theta, center), build_svg(theta, center), "download/maison-icon-preview.png")
print(f"live   : variant={VARIANT} theta={theta:g} center={center} "
      f"M {gwM:.0f}x{ghM:.0f}, rule y {ry:.0f} | N upright {gwN_u:.0f}x{ghN_u:.0f}")

other = "perp" if VARIANT == "half" else "half"
t2, c2 = ROT[other], n_placement(ROT[other])
alt_name = f"maison-icon-alt-{'perp-90' if other == 'perp' else 'half-45'}.png"
composite(t2, c2).resize((512, 512), Image.LANCZOS).save(os.path.join(ROOT, "download", alt_name))
print(f"alt    : variant={other} theta={t2:g} center={c2} -> download/{alt_name}")
