import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';

const OUT_DIR = '/home/z/my-project/public/editorial';

const IMAGES = [
  {
    name: 'hero.jpg',
    size: '864x1152',
    prompt:
      'High fashion editorial photograph, elegant woman in flowing oversized beige wool coat standing in minimalist gallery, warm alabaster plaster walls, soft diffused window light, Kinfolk magazine aesthetic, muted cream and taupe palette, subtle film grain, medium format film photography, serene asymmetric composition, lots of negative space, high quality, detailed',
  },
  {
    name: 'object-01.jpg',
    size: '864x1152',
    prompt:
      'Luxury still life photograph, handmade matte ceramic vessel on travertine stone plinth, single dried branch, warm alabaster background, soft long shadows, editorial magazine style, muted cream and taupe palette, soft diffused lighting, minimalist composition, high quality, detailed',
  },
  {
    name: 'object-02.jpg',
    size: '864x1152',
    prompt:
      'Luxury still life photograph, folded ivory cashmere sweater with draped silk scarf on pale limestone surface, warm alabaster wall behind, soft window light and gentle shadow, editorial fashion photography, muted neutral palette, minimalist serene composition, high quality, detailed',
  },
  {
    name: 'object-03.jpg',
    size: '864x1152',
    prompt:
      'Luxury still life macro photograph, delicate gold chain necklace and minimal gold ring resting on cream silk fabric with soft folds, warm alabaster background, soft diffused light, muted elegant editorial palette, shallow depth of field, high quality, detailed',
  },
  {
    name: 'story.jpg',
    size: '864x1152',
    prompt:
      'Minimalist architecture interior photograph, sunlit corridor with warm lime plaster walls, arched doorway, single wooden bench, dramatic soft light and shadow play, Kinfolk aesthetic, warm cream and taupe tones, editorial photography, film grain, high quality, detailed',
  },
  {
    name: 'avatar-1.jpg',
    size: '1024x1024',
    prompt:
      'Editorial portrait photograph of elegant woman in her fifties with silver hair, cream turtleneck, warm alabaster studio background, soft diffused light, muted neutral tones, Kinfolk magazine aesthetic, calm expression, high quality, detailed',
  },
  {
    name: 'avatar-2.jpg',
    size: '1024x1024',
    prompt:
      'Editorial portrait photograph of distinguished man in his forties with tailored charcoal coat, warm alabaster studio background, soft diffused light, muted neutral tones, Kinfolk magazine aesthetic, composed expression, high quality, detailed',
  },
  {
    name: 'avatar-3.jpg',
    size: '1024x1024',
    prompt:
      'Editorial portrait photograph of young woman with dark hair pulled back, wearing beige linen, warm alabaster studio background, soft diffused light, muted neutral tones, Kinfolk magazine aesthetic, serene expression, high quality, detailed',
  },
];

async function main() {
  if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });
  const zai = await ZAI.create();
  const results = [];

  for (const img of IMAGES) {
    const outPath = path.join(OUT_DIR, img.name);
    if (fs.existsSync(outPath) && fs.statSync(outPath).size > 50000) {
      console.log(`skip (exists): ${img.name}`);
      results.push({ name: img.name, ok: true, skipped: true });
      continue;
    }
    let ok = false;
    let lastErr = null;
    for (let attempt = 1; attempt <= 3 && !ok; attempt++) {
      try {
        const res = await zai.images.generations.create({
          prompt: img.prompt,
          size: img.size,
        });
        const b64 = res?.data?.[0]?.base64;
        if (!b64) throw new Error('empty base64');
        const buf = Buffer.from(b64, 'base64');
        fs.writeFileSync(outPath, buf);
        console.log(`ok: ${img.name} (${(buf.length / 1024).toFixed(0)} KB)`);
        ok = true;
      } catch (e) {
        lastErr = e;
        console.error(`attempt ${attempt} failed for ${img.name}: ${e.message}`);
        await new Promise((r) => setTimeout(r, 1500 * attempt));
      }
    }
    results.push({ name: img.name, ok, error: ok ? null : String(lastErr) });
  }

  const failed = results.filter((r) => !r.ok);
  console.log(`\nDone. ${results.length - failed.length}/${results.length} succeeded.`);
  if (failed.length) {
    console.error('FAILED:', failed.map((f) => f.name).join(', '));
    process.exit(1);
  }
}

main().catch((e) => {
  console.error('fatal:', e);
  process.exit(1);
});
