import { createHash } from 'node:crypto'
import { readFileSync } from 'node:fs'
import { join } from 'node:path'
import { PrismaClient } from '@prisma/client'
import { prismaDatabaseUrl } from '../src/lib/server/prisma-connection'

type JsonRow = Record<string, string | number | boolean | null>
type TableManifest = {
  count: number
  sha256: string
  dateFields: string[]
  columns: string[]
}
type Manifest = { tables: Record<string, TableManifest> }
type Delegate = {
  count(): Promise<number>
  findMany(args: { orderBy: { id: 'asc' } }): Promise<Record<string, unknown>[]>
  createMany(args: { data: Record<string, unknown>[] }): Promise<{ count: number }>
}

// Parents precede children so the database's own foreign keys remain enabled.
const specs = [
  { table: 'Topic', model: 'topic' },
  { table: 'Source', model: 'source' },
  { table: 'User', model: 'user' },
  { table: 'ContentItem', model: 'contentItem' },
  { table: 'AdminAuditLog', model: 'adminAuditLog' },
  { table: 'UserPreference', model: 'userPreference' },
  { table: 'Bookmark', model: 'bookmark' },
  { table: 'PushSubscription', model: 'pushSubscription' },
  { table: 'SourceHealthLog', model: 'sourceHealthLog' },
] as const

function normalized(value: unknown): unknown {
  if (value instanceof Date) return value.toISOString()
  if (Array.isArray(value)) return value.map(normalized)
  if (value && typeof value === 'object') {
    const record = value as Record<string, unknown>
    return Object.fromEntries(Object.keys(record).sort().map((key) => [key, normalized(record[key])]))
  }
  return value
}

function rowsDigest(rows: Record<string, unknown>[]): string {
  const hash = createHash('sha256')
  for (const row of rows) hash.update(`${JSON.stringify(normalized(row))}\n`, 'utf8')
  return hash.digest('hex')
}

function formatSafeError(error: unknown): string {
  const err = error as { code?: unknown; message?: unknown }
  const code = typeof err?.code === 'string' ? err.code : 'migration_error'
  const message = typeof err?.message === 'string' ? err.message : 'Unknown database error.'
  return `${code}: ${message.replace(/mysql:\/\/[^@\s]+@/gi, 'mysql://[redacted]@').slice(0, 400)}`
}

async function main() {
  const directory = process.argv[2]
  if (!directory) throw new Error('Missing private export directory.')
  const manifest = JSON.parse(readFileSync(join(directory, 'manifest.json'), 'utf8')) as Manifest
  const db = new PrismaClient({ datasources: { db: { url: prismaDatabaseUrl() } } })

  try {
    await db.$connect()
    const client = db as unknown as Record<string, Delegate>

    for (const spec of specs) {
      const expected = manifest.tables[spec.table]
      if (!expected) throw new Error(`Source manifest does not include ${spec.table}.`)
      const delegate = client[spec.model]
      if (!delegate) throw new Error(`Generated Prisma model ${spec.model} is unavailable.`)
      const path = join(directory, `${spec.table}.jsonl`)
      const text = readFileSync(path, 'utf8')
      const sourceRows = text.trim() ? text.trimEnd().split('\n').map((line) => JSON.parse(line) as JsonRow) : []
      if (sourceRows.length !== expected.count || rowsDigest(sourceRows) !== expected.sha256) {
        throw new Error(`Private source export for ${spec.table} failed its count/digest check.`)
      }

      const existingCount = await delegate.count()
      if (existingCount > 0) {
        const existingRows = await delegate.findMany({ orderBy: { id: 'asc' } })
        if (existingCount !== expected.count || rowsDigest(existingRows) !== expected.sha256) {
          throw new Error(`Target ${spec.table} has non-matching rows; no existing data will be overwritten.`)
        }
        console.log(`Preserved matching target table ${spec.table}: ${existingCount} rows (already imported).`)
        continue
      }

      if (sourceRows.length > 0) {
        const dateFields = new Set(expected.dateFields)
        const prepared = sourceRows.map((sourceRow) => {
          const row: Record<string, unknown> = { ...sourceRow }
          for (const field of dateFields) {
            const value = row[field]
            row[field] = typeof value === 'string' ? new Date(value) : value
          }
          return row
        })
        await db.$transaction(async (transaction) => {
          const transactionClient = transaction as unknown as Record<string, Delegate>
          const transactionDelegate = transactionClient[spec.model]
          for (let start = 0; start < prepared.length; start += 500) {
            const batch = prepared.slice(start, start + 500)
            const result = await transactionDelegate.createMany({ data: batch })
            if (result.count !== batch.length) throw new Error(`Incomplete insert batch for ${spec.table}.`)
          }
        }, { maxWait: 10_000, timeout: 120_000 })
      }

      const importedCount = await delegate.count()
      const importedRows = await delegate.findMany({ orderBy: { id: 'asc' } })
      if (importedCount !== expected.count || rowsDigest(importedRows) !== expected.sha256) {
        throw new Error(`Target ${spec.table} did not match the source count/digest after import.`)
      }
      console.log(`Imported and verified ${spec.table}: ${importedCount} rows; digest ${expected.sha256.slice(0, 16)}.`)
    }

    // Exercise the relations used by login, the feed, and saved items after the
    // table-level content checks; never print account identifiers or row data.
    const [adminCount, itemCount, bookmarkCount, preferenceCount] = await Promise.all([
      db.user.count({ where: { role: 'admin' } }),
      db.contentItem.count(),
      db.bookmark.count(),
      db.userPreference.count(),
    ])
    console.log(`Application read smoke check: ${itemCount} items, ${bookmarkCount} bookmarks, ${preferenceCount} preferences, ${adminCount} administrator accounts.`)
  } finally {
    await db.$disconnect()
  }
}

main().catch((error: unknown) => {
  console.error(`Managed MySQL import stopped without overwriting mismatched data: ${formatSafeError(error)}`)
  process.exitCode = 1
})
