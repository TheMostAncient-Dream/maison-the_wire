#!/usr/bin/env python3
"""Safely transfer the bundled SQLite snapshot into managed MySQL via Prisma.

The source is opened read-only. No credential is accepted on the command line or
written to disk. Export files are private temporary artifacts and are removed on
success or failure. The Prisma importer refuses to overwrite non-matching rows.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import sqlite3
import subprocess
import sys
import tempfile
import unicodedata
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / "db" / "custom.db"
TABLES: dict[str, tuple[list[str], set[str], set[str]]] = {
    "Topic": (["id", "slug", "name", "description", "sortOrder", "createdAt", "updatedAt"], {"createdAt", "updatedAt"}, set()),
    "Source": (["id", "slug", "name", "type", "feedUrl", "websiteUrl", "externalId", "country", "language", "topicSlugs", "logoUrl", "prominence", "fetchIntervalMin", "isActive", "lastFetchedAt", "lastSuccessAt", "lastError", "consecutiveFailures", "healthStatus", "itemsIngested", "createdAt", "updatedAt"], {"lastFetchedAt", "lastSuccessAt", "createdAt", "updatedAt"}, {"isActive"}),
    "ContentItem": (["id", "type", "title", "snippet", "sourceId", "author", "url", "thumbnailUrl", "durationSec", "language", "country", "topicSlugs", "publishedAt", "contentHash", "brief", "keyPoints", "briefAt", "fetchedAt", "createdAt"], {"publishedAt", "briefAt", "fetchedAt", "createdAt"}, set()),
    "User": (["id", "email", "name", "passwordHash", "role", "sessionVersion", "failedLogins", "lockedUntil", "notifySourceIds", "onboardingCompletedAt", "emailVerifiedAt", "verificationCodeHash", "verificationExpiresAt", "verificationSentAt", "createdAt", "updatedAt"], {"lockedUntil", "onboardingCompletedAt", "emailVerifiedAt", "verificationExpiresAt", "verificationSentAt", "createdAt", "updatedAt"}, set()),
    "AdminAuditLog": (["id", "actorUserId", "action", "targetId", "detail", "createdAt"], {"createdAt"}, set()),
    "UserPreference": (["id", "userId", "columns", "sourceSlugs", "youtubeChannelIds", "instagramHandles", "languages", "countries", "contentTypes", "itemsPerColumn", "refreshIntervalMin", "theme", "updatedAt"], {"updatedAt"}, set()),
    "Bookmark": (["id", "userId", "itemId", "createdAt"], {"createdAt"}, set()),
    "PushSubscription": (["id", "userId", "endpoint", "p256dh", "auth", "createdAt"], {"createdAt"}, set()),
    "SourceHealthLog": (["id", "sourceId", "status", "message", "itemCount", "durationMs", "createdAt"], {"createdAt"}, set()),
}
UNIQUE_KEYS: dict[str, list[tuple[str, ...]]] = {
    "Topic": [("id",), ("slug",)],
    "Source": [("id",), ("slug",)],
    "ContentItem": [("id",), ("sourceId", "contentHash")],
    "User": [("id",), ("email",)],
    "AdminAuditLog": [("id",)],
    "UserPreference": [("id",), ("userId",)],
    "Bookmark": [("id",), ("userId", "itemId")],
    "PushSubscription": [("id",), ("endpoint",)],
    "SourceHealthLog": [("id",)],
}


def canonical(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def utc_iso(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        stamp = dt.datetime.fromtimestamp(float(value) / 1000, tz=dt.timezone.utc)
    else:
        stamp = dt.datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=dt.timezone.utc)
        stamp = stamp.astimezone(dt.timezone.utc)
    return stamp.isoformat(timespec="milliseconds").replace("+00:00", "Z")


def mysql_ci_key(value: Any) -> str:
    text = unicodedata.normalize("NFD", str(value)).casefold().rstrip(" ")
    return "".join(char for char in text if unicodedata.category(char) != "Mn")


def check_unique_collisions(source: sqlite3.Connection) -> None:
    for table, keys in UNIQUE_KEYS.items():
        for columns in keys:
            seen: set[tuple[str, ...]] = set()
            selected = ", ".join(f'"{column}"' for column in columns)
            for row in source.execute(f'SELECT {selected} FROM "{table}"'):
                values = tuple(row)
                # MySQL permits multiple NULLs in a unique index.
                if any(value is None for value in values):
                    continue
                key = tuple(mysql_ci_key(value) for value in values)
                if key in seen:
                    raise RuntimeError(f"MySQL collation would merge distinct unique keys in {table}; migration stopped.")
                seen.add(key)


def main() -> int:
    if not SOURCE.is_file():
        raise RuntimeError("The supplied SQLite snapshot is missing from db/custom.db.")
    os.umask(0o077)
    uri = f"file:{SOURCE.as_posix()}?mode=ro"
    source = sqlite3.connect(uri, uri=True)
    source.row_factory = sqlite3.Row
    try:
        integrity = source.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity != "ok":
            raise RuntimeError("The SQLite source failed its integrity check; migration stopped.")
        foreign_key_error = source.execute("PRAGMA foreign_key_check").fetchone()
        if foreign_key_error is not None:
            raise RuntimeError("The SQLite source has a foreign-key violation; migration stopped.")
        check_unique_collisions(source)

        with tempfile.TemporaryDirectory(prefix="maison-sqlite-export-") as temporary:
            work = Path(temporary)
            manifest: dict[str, Any] = {"tables": {}}
            for table, (expected_columns, dates, booleans) in TABLES.items():
                actual_columns = [row[1] for row in source.execute(f'PRAGMA table_info("{table}")')]
                if len(actual_columns) != len(expected_columns) or set(actual_columns) != set(expected_columns):
                    raise RuntimeError(f"Source schema for {table} differs from the reviewed migration map; stopped.")

                output_path = work / f"{table}.jsonl"
                digest = hashlib.sha256()
                count = 0
                cursor = source.execute(f'SELECT * FROM "{table}" ORDER BY "id"')
                with output_path.open("w", encoding="utf-8", newline="\n") as output:
                    for raw in cursor:
                        row: dict[str, Any] = dict(raw)
                        for column in dates:
                            row[column] = utc_iso(row[column])
                        for column in booleans:
                            row[column] = None if row[column] is None else bool(row[column])
                        output.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
                        digest.update(canonical(row) + b"\n")
                        count += 1

                manifest["tables"][table] = {
                    "count": count,
                    "sha256": digest.hexdigest(),
                    "dateFields": sorted(dates),
                    "columns": actual_columns,
                }
                print(f"Exported {table}: {count} rows; source digest {digest.hexdigest()[:16]}")

            (work / "manifest.json").write_text(json.dumps(manifest, separators=(",", ":")), encoding="utf-8")
            command = ["npx", "tsx", "scripts/import-mysql-snapshot.ts", str(work)]
            result = subprocess.run(command, cwd=ROOT, check=False)
            if result.returncode:
                return result.returncode
        print("SQLite source was never modified; private temporary exports were removed.")
        return 0
    finally:
        source.close()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"Migration stopped safely: {error}", file=sys.stderr)
        raise SystemExit(1)
