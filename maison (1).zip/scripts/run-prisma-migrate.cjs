#!/usr/bin/env node
const { spawnSync } = require('node:child_process')
const path = require('node:path')

function prismaDatabaseUrl(raw) {
  if (!raw) throw new Error('DATABASE_URL is required.')
  let url
  try {
    url = new URL(raw)
  } catch {
    throw new Error('DATABASE_URL is not a valid connection URL.')
  }
  if (url.protocol !== 'mysql:') return raw

  const sslOptions = url.searchParams.getAll('ssl')
  if (sslOptions.length === 0) {
    if (process.env.NODE_ENV === 'production' && url.searchParams.get('sslaccept') !== 'strict') {
      throw new Error('Production MySQL must use strict TLS certificate verification.')
    }
    return raw
  }
  if (sslOptions.length !== 1 || url.searchParams.has('sslaccept')) {
    throw new Error('DATABASE_URL contains conflicting TLS options; connection refused.')
  }

  let settings
  try {
    settings = JSON.parse(sslOptions[0])
  } catch {
    throw new Error('DATABASE_URL contains an unsupported TLS option; connection refused.')
  }
  if (
    !settings ||
    typeof settings !== 'object' ||
    Array.isArray(settings) ||
    Object.keys(settings).length !== 1 ||
    settings.rejectUnauthorized !== true
  ) {
    throw new Error('MySQL TLS peer verification must remain enabled; connection refused.')
  }

  url.searchParams.delete('ssl')
  url.searchParams.set('sslaccept', 'strict')
  return url.toString()
}

let databaseUrl
try {
  databaseUrl = prismaDatabaseUrl(process.env.DATABASE_URL)
} catch (error) {
  console.error(`Prisma migration not started: ${error.message}`)
  process.exit(1)
}

const root = path.resolve(__dirname, '..')
const prisma = path.join(root, 'node_modules', '.bin', 'prisma')
const result = spawnSync(prisma, ['migrate', 'deploy'], {
  cwd: root,
  env: { ...process.env, DATABASE_URL: databaseUrl },
  stdio: 'inherit',
})
if (result.error) {
  console.error(`Prisma migration could not start: ${result.error.message}`)
  process.exit(1)
}
process.exit(result.status === null ? 1 : result.status)
