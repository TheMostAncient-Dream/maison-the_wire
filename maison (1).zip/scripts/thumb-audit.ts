/**
 * Audit thumbnail health across ContentItem:
 * - null thumbnails
 * - http:// (mixed content — browser blocks these on https pages; on localhost they load but may 403)
 * - per-domain counts to spot hotlink-protected hosts
 */
import { db } from "../src/lib/db";

async function main() {
  const total = await db.contentItem.count();
  const items = await db.contentItem.findMany({
    select: { thumbnailUrl: true, type: true },
  });
  const noThumb = items.filter((i) => !i.thumbnailUrl).length;
  const httpInsecure = items.filter((i) => i.thumbnailUrl?.startsWith("http://")).length;

  const byDomain = new Map<string, number>();
  for (const i of items) {
    if (!i.thumbnailUrl) continue;
    try {
      const u = new URL(i.thumbnailUrl);
      byDomain.set(u.hostname, (byDomain.get(u.hostname) ?? 0) + 1);
    } catch {
      const key = "INVALID_URL";
      byDomain.set(key, (byDomain.get(key) ?? 0) + 1);
    }
  }

  // sample URLs per domain (first 2)
  const samples = new Map<string, string[]>();
  for (const i of items) {
    if (!i.thumbnailUrl) continue;
    try {
      const h = new URL(i.thumbnailUrl).hostname;
      if (!samples.has(h)) samples.set(h, []);
      if ((samples.get(h)!.length ?? 0) < 2) samples.get(h)!.push(i.thumbnailUrl);
    } catch {
      /* ignore */
    }
  }

  console.log(JSON.stringify({ total, noThumb, httpInsecure }, null, 2));
  console.log("\n── per-domain ──");
  for (const [d, c] of [...byDomain.entries()].sort((a, b) => b[1] - a[1])) {
    console.log(`${String(c).padStart(5)}  ${d}`);
    for (const s of samples.get(d) ?? []) console.log(`        ${s}`);
  }
  await db.$disconnect();
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
