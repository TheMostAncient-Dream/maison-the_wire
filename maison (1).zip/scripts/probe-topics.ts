import { PrismaClient } from "@prisma/client";
const p = new PrismaClient();
async function main() {
  const topics: any = await (p as any).topic.findMany();
  console.log("=== TOPIC TABLE (" + topics.length + ") ===");
  for (const t of topics) console.log(JSON.stringify(t));
  const sources = await p.source.findMany({ select: { name: true, isActive: true, topicSlugs: true } });
  console.log("=== SOURCES with tech topics ===");
  const terms = ["react","javascript","vue","three","vgpu","gpu","node","python","typescript"];
  const hits = sources.filter(s => terms.some(t => s.name.toLowerCase().includes(t)) || (s.topicSlugs || "").toLowerCase().includes("react") || (s.topicSlugs || "").toLowerCase().includes("javascript") || (s.topicSlugs || "").toLowerCase().includes("vue"));
  for (const s of hits) console.log(JSON.stringify(s));
  console.log("TOTAL SOURCES:", sources.length);
  await p.$disconnect();
}
main();
