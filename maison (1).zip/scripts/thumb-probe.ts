/** Probe one sample image per domain with a browser UA (no referer) — like a browser <img> request. */
const samples: Record<string, string> = {
  "media.zenfs.com": "https://media.zenfs.com/en/last_word_on_sports_293/4f82b7325446bb879ee5891e297aff9a.jpg",
  "i.ytimg.com": "https://i.ytimg.com/vi/5msmj3UIrwc/hqdefault.jpg",
  "thehill.com": "https://thehill.com/wp-content/uploads/sites/2/2024/10/672348a06b8d75.87443039.jpeg?w=900",
  "helios-i.mashable.com": "https://helios-i.mashable.com/imagery/articles/06HCa1lwUXlpg1e9dvTsGbT/hero-image.jpg",
  "static.toiimg.com": "https://static.toiimg.com/photo/msid-134615742,imgsize-69692.cms",
  "nypost.com (double-encoded)": "https://nypost.com/wp-content%2Fuploads%2Fsites%2F2%2F2026%2F10%2Fjack_smith.jpg?quality%3D90%26strip%3Dall",
  "cdn.mos.cms.futurecdn.net": "https://cdn.mos.cms.futurecdn.net/SP3QFwyGMZ37pNCLrdzUVh-1920-80.jpg",
  "img.etimg.com": "https://img.etimg.com/photo/msid-134616031,imgsize-108366.cms",
  "cdn.i-scmp.com": "https://cdn.i-scmp.com/sites/default/files/styles/1280x720/public/d8/images/canvas/2026/10/01/d98f2c0f-9232-4732-84f7-011dffcbf99d_02875c4c.jpg?itok=mRvAAzLu&v=1790851011",
  "npr.brightspotcdn.com": "https://npr.brightspotcdn.com/dims3/default/strip/false/crop/5616x3744+0+0/resize/5616x3744!/?url=http%3A%2F%2Fnpr-brightspot.s3.amazonaws.com%2F78%2Fc7%2Fb698faa9412ba675ccc14a722726%2Fap26272666310914.jpg",
  "s.france24.com": "https://s.france24.com/media/display/3ae0a024-bd7e-11f1-b625-ddce071186a9/w:1024/p:16x9/Thumb-high-schools-01.jpg",
  "static.politico.com (getty)": "https://static.politico.com/45/24/1191bd754941b797e006a42322fb/https-delivery-gettyimages.com/downloads/2294606777",
  "media.thenextweb.com (.avif)": "https://media.thenextweb.com/2026/10/sam-altman-on-stage-openai-logo-devday-2026.avif",
  "i.cbc.ca": "https://i.cbc.ca/ais/61248be9-513f-4a93-910d-c8d8f3863b94,1790803107588/full/max/0/default.jpg?im=Crop%2Crect%3D%280%2C0%2C1920%2C1080%29%3B",
  "e3.365dm.com": "https://e3.365dm.com/26/10/1920x1080/skynews-glacier-switzerland_7365552.jpg?20261001100457",
  "www.engadget.com": "https://www.engadget.com/img/gallery/parasite-studio-neon-one-ups-a24-with-an-open-source-scp-foundation-movie/l-intro-1790851178.jpg",
  "platform.theverge.com (&#038;)": "https://platform.theverge.com/wp-content/uploads/sites/2/2026/10/huawei-ruiying-z10-camera.jpg?quality=90&#038;strip=all&#038;crop=0,0,100,100",
  "pagesix.com (double-encoded)": "https://pagesix.com/wp-content%2Fuploads%2Fsites%2F3%2F2026%2F10%2Flopez-72.jpg?quality%3D90%26strip%3Dall",
  "www.billboard.com (&#038;)": "https://www.billboard.com/wp-content/uploads/2026/06/Willard-Ahdritz-Rohan-Nesho-Jain-2026-press-AhdritzCapital-cr-Paul-Brissman-billboard-1800.jpg?w=237&#038;h=147&#038;crop=1",
  "media.npr.org (tracking px)": "https://media.npr.org/include/images/tracking/npr-rss-pixel.png?story=nx-s1-5983684",
  "a1.api.bbc.co.uk (beacon)": "https://a1.api.bbc.co.uk/hit.xiti/?s=646754",
};

const UA =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

async function probe(name: string, url: string) {
  try {
    const res = await fetch(url, {
      headers: { "User-Agent": UA, Accept: "image/avif,image/webp,image/*,*/*;q=0.8" },
      signal: AbortSignal.timeout(10_000),
      redirect: "follow",
    });
    const ct = res.headers.get("content-type") ?? "?";
    const len = res.headers.get("content-length");
    const okImage = res.ok && ct.startsWith("image/");
    console.log(`${okImage ? "OK  " : "FAIL"} ${res.status} ${ct.slice(0, 24).padEnd(24)} ${name}`);
  } catch (e) {
    console.log(`FAIL ERR ${(e as Error).message.slice(0, 40).padEnd(44)} ${name}`);
  }
}

await Promise.all(Object.entries(samples).map(([n, u]) => probe(n, u)));
