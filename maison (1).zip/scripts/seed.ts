/**
 * Optional seed for a fresh, isolated development database only.
 * Idempotent: safe to run repeatedly (upserts by slug/email).
 */
import { PrismaClient } from '@prisma/client'
import { scryptSync, randomBytes } from 'crypto'
import { TOPICS, rssSourcesWithLogos, YOUTUBE_CHANNELS, INSTAGRAM_ACCOUNTS, RSS_SOURCES } from '../src/lib/seed-data'

const db = new PrismaClient()

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex')
  const hash = scryptSync(password, salt, 64).toString('hex')
  return `${salt}:${hash}`
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(':')
  if (!salt || !hash) return false
  return scryptSync(password, salt, 64).toString('hex') === hash
}

async function main() {
  if (process.env.NODE_ENV === 'production') {
    throw new Error('Refusing to run the seed script in production.')
  }

  const existingRows = await Promise.all([
    db.topic.count(),
    db.source.count(),
    db.contentItem.count(),
    db.user.count(),
    db.adminAuditLog.count(),
    db.userPreference.count(),
    db.bookmark.count(),
    db.pushSubscription.count(),
    db.sourceHealthLog.count(),
  ])
  if (existingRows.some((count) => count > 0)) {
    throw new Error('Refusing to seed a non-empty database; this project may use the shared managed database.')
  }

  const adminEmail = process.env.ADMIN_EMAIL?.trim()
  const adminPassword = process.env.ADMIN_PASSWORD
  if (!adminEmail || !adminPassword || adminPassword.length < 16) {
    throw new Error('Set ADMIN_EMAIL and a unique ADMIN_PASSWORD of at least 16 characters before seeding.')
  }

  console.log('Seeding topics…')
  for (let i = 0; i < TOPICS.length; i++) {
    const t = TOPICS[i]
    await db.topic.upsert({
      where: { slug: t.slug },
      update: { name: t.name, description: t.description, sortOrder: i },
      create: { slug: t.slug, name: t.name, description: t.description, sortOrder: i },
    })
  }

  console.log('Seeding sources…')
  const all = [...rssSourcesWithLogos(), ...YOUTUBE_CHANNELS, ...INSTAGRAM_ACCOUNTS]
  for (const s of all) {
    const data = {
      slug: s.slug,
      name: s.name,
      type: s.type,
      feedUrl: s.feedUrl ?? null,
      websiteUrl: s.websiteUrl ?? null,
      externalId: s.externalId ?? null,
      country: s.country ?? null,
      language: s.language ?? 'en',
      topicSlugs: JSON.stringify(s.topicSlugs),
      logoUrl: s.logoUrl ?? null,
      prominence: s.prominence ?? 1,
      fetchIntervalMin: s.fetchIntervalMin ?? (s.type === 'rss' ? 10 : 30),
      isActive: true,
    }
    await db.source.upsert({ where: { slug: s.slug }, update: data, create: data })
  }
  // Remove sources that were retired from the registry (dead feeds, replaced outlets).
  const registrySlugs = new Set(all.map((s) => s.slug))
  const retired = [
    'independent', 'hindustantimes', 'gizmodo', 'espn', 'atlantic', 'space-com', 'livescience',
  ]
  for (const slug of retired) {
    if (!registrySlugs.has(slug)) await db.source.deleteMany({ where: { slug } })
  }
  console.log(`  → ${all.length} sources (${RSS_SOURCES.length} RSS, ${YOUTUBE_CHANNELS.length} YouTube, ${INSTAGRAM_ACCOUNTS.length} Instagram)`)

  console.log('Seeding users…')
  // Seeded accounts predate onboarding — treat them as already onboarded so
  // the post-signup flow never interrupts testing on these accounts.
  await db.user.upsert({
    where: { email: adminEmail },
    update: { role: 'admin', onboardingCompletedAt: new Date() },
    create: {
      email: adminEmail,
      name: 'Terminal Administrator',
      role: 'admin',
      passwordHash: hashPassword(adminPassword),
      preference: { create: {} },
      onboardingCompletedAt: new Date(),
    },
  })

  const demoEmail = process.env.DEMO_EMAIL?.trim()
  const demoPassword = process.env.DEMO_PASSWORD
  if (demoEmail || demoPassword) {
    if (!demoEmail || !demoPassword || demoPassword.length < 16) {
      throw new Error('For optional demo seeding, set both DEMO_EMAIL and a unique DEMO_PASSWORD of at least 16 characters.')
    }
    await db.user.upsert({
      where: { email: demoEmail },
      update: { onboardingCompletedAt: new Date() },
      create: {
        email: demoEmail,
        name: 'Demo Reader',
        role: 'user',
        passwordHash: hashPassword(demoPassword),
        preference: { create: {} },
        onboardingCompletedAt: new Date(),
      },
    })
  }
  console.log('  → configured administrator is ready')
  if (demoEmail) console.log('  → explicitly configured demo account is ready')

  console.log('Seed complete ✔')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(() => db.$disconnect())
