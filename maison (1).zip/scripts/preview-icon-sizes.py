#!/usr/bin/env python3
"""Tab-strip legibility probe: enlarge favicon.ico frames 6x for the eye."""
from PIL import Image

ico = Image.open("/home/z/my-project/src/app/favicon.ico")
frames = []
for size in (16, 32, 48):
    ico.size = (size, size)
    frames.append(ico.copy().convert("RGBA"))

S = 6
strip = Image.new("RGBA", (sum(f.width * S + 16 for f in frames) + 16, 48 * S + 32), (185, 183, 178, 255))
x = 16
for f in frames:
    big = f.resize((f.width * S, f.height * S), Image.NEAREST)
    strip.paste(big, (x, 16), big)
    x += f.width * S + 16
strip.save("/home/z/my-project/download/maison-icon-sizes.png")
print("sizes strip written")
