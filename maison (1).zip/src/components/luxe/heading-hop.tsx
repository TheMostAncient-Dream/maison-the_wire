"use client";

import { useEffect } from "react";

/**
 * First-hover hop — every serif display heading gives a small jump the
 * first time the reader's cursor finds it, and only the first time.
 *
 * One delegated listener at the document level (modals and portals are
 * covered for free); a WeakSet is the "first time" ledger, so the hop
 * never repeats on later hovers. The animation itself is gated in CSS
 * to hover-capable pointers and silenced for reduced-motion readers,
 * so touch taps and motion-sensitive setups stay perfectly still.
 */
export function HeadingHop() {
  useEffect(() => {
    const seen = new WeakSet<Element>();
    const onOver = (event: MouseEvent) => {
      const target = event.target as Element | null;
      if (!target?.closest) return;
      const heading = target.closest<HTMLElement>("h1, h2, h3");
      if (!heading || !heading.classList.contains("font-serif")) return;
      if (seen.has(heading)) return;
      seen.add(heading);
      heading.classList.add("heading-hop");
    };
    document.addEventListener("mouseover", onOver, { passive: true });
    return () => document.removeEventListener("mouseover", onOver);
  }, []);

  return null;
}
