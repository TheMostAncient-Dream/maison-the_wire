"use client";

import { cn } from "@/lib/utils";
import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import { Bookmark, Globe, LogOut, Moon, Settings2, ShieldCheck, Sun } from "lucide-react";
import { useSession } from "./session/session-provider";

const LINKS = [
  { label: "Front Page", href: "#front-page" },
  { label: "The Wire", href: "#wire" },
  { label: "Columns", href: "#columns" },
  { label: "Sources", href: "#sources" },
  { label: "Colophon", href: "#colophon" },
];

/**
 * Theme edition — the html.dark class is the single source of truth
 * (set pre-hydration in layout.tsx); a MutationObserver keeps React
 * honest when it flips.
 */
function subscribeToEdition(onChange: () => void) {
  const observer = new MutationObserver(onChange);
  observer.observe(document.documentElement, {
    attributes: true,
    attributeFilter: ["class"],
  });
  return () => observer.disconnect();
}

function useTheme() {
  const dark = useSyncExternalStore(
    subscribeToEdition,
    () => document.documentElement.classList.contains("dark"),
    () => false
  );
  const toggle = () => {
    const next = !document.documentElement.classList.contains("dark");
    document.documentElement.classList.toggle("dark", next);
    try {
      window.localStorage.setItem("maison-theme", next ? "dark" : "light");
    } catch {
      /* private mode */
    }
  };
  return { dark, toggle };
}

export function SiteNav() {
  const [open, setOpen] = useState(false);
  const { dark, toggle } = useTheme();
  const menuTriggerRef = useRef<HTMLButtonElement>(null);
  const menuDialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    menuDialogRef.current
      ?.querySelector<HTMLButtonElement>('[aria-label="Close menu"]')
      ?.focus();

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        setOpen(false);
        menuTriggerRef.current?.focus();
        return;
      }
      if (event.key !== "Tab" || !menuDialogRef.current) return;

      const focusable = Array.from(
        menuDialogRef.current.querySelectorAll<HTMLElement>(
          'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])'
        )
      );
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last?.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first?.focus();
      }
    };

    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [open]);

  const closeMenu = () => {
    setOpen(false);
    requestAnimationFrame(() => menuTriggerRef.current?.focus());
  };

  return (
    <>
      <header className="sticky top-0 z-40 border-b border-charcoal/10 bg-alabaster">
        <div className="mx-auto flex h-16 max-w-[1600px] items-center justify-between px-8 md:h-20 md:px-16">
          {/* Brand */}
          <a
            href="#top"
            className="font-serif text-xl tracking-[0.08em] text-charcoal"
          >
            MAISON
            <span className="ml-2 hidden align-super text-[9px] uppercase tracking-[0.3em] text-warm-grey sm:inline">
              Éd. 01
            </span>
          </a>

          {/* Desktop links */}
          <nav aria-label="Primary" className="hidden items-center gap-8 lg:flex xl:gap-10">
            {LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="link-underline text-xs uppercase tracking-[0.25em] text-warm-grey transition-colors duration-500 ease-luxe hover:text-gold-ink"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-5">
            {/* Edition (theme) toggle */}
            <button
              type="button"
              onClick={toggle}
              aria-label={dark ? "Switch to the day edition" : "Switch to the night edition"}
              className="flex h-9 w-9 items-center justify-center text-warm-grey transition-colors duration-500 ease-luxe hover:text-gold-ink focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-charcoal"
            >
              {dark ? (
                <Sun className="h-4 w-4" strokeWidth={1.5} aria-hidden />
              ) : (
                <Moon className="h-4 w-4" strokeWidth={1.5} aria-hidden />
              )}
            </button>

            <a
              href="#wire"
              className="hidden border border-charcoal px-6 py-3 text-xs uppercase tracking-[0.2em] text-charcoal transition-colors duration-500 ease-luxe hover:bg-charcoal hover:text-alabaster xl:inline-block"
            >
              Read the Wire
            </a>

            {/* Account — desktop */}
            <div className="hidden md:block">
              <AccountCorner />
            </div>

            {/* Mobile trigger — two architectural lines */}
            <button
              ref={menuTriggerRef}
              type="button"
              aria-label={open ? "Close menu" : "Open menu"}
              aria-expanded={open}
              aria-controls={open ? "maison-mobile-menu" : undefined}
              onClick={() => setOpen((v) => !v)}
              className="flex h-10 w-10 flex-col items-end justify-center gap-[7px] md:hidden"
            >
              <span
                className={cn(
                  "h-px w-6 bg-charcoal transition-transform duration-500 ease-luxe",
                  open && "translate-y-[4px] rotate-45"
                )}
              />
              <span
                className={cn(
                  "h-px w-6 bg-charcoal transition-transform duration-500 ease-luxe",
                  open && "-translate-y-[4px] -rotate-45"
                )}
              />
            </button>
          </div>
        </div>
      </header>

      {/* Full-screen charcoal menu overlay */}
      {open && (
        <div
          ref={menuDialogRef}
          id="maison-mobile-menu"
          className="overlay-in fixed inset-0 z-50 flex flex-col bg-charcoal text-alabaster md:hidden"
          role="dialog"
          aria-modal="true"
          aria-label="Menu"
        >
          <div className="flex h-16 items-center justify-between border-b border-alabaster/15 px-8">
            <span className="font-serif text-xl tracking-[0.08em]">MAISON</span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={toggle}
                aria-label={dark ? "Switch to the day edition" : "Switch to the night edition"}
                className="flex h-10 w-10 items-center justify-center text-alabaster/70 transition-colors duration-500 ease-luxe hover:text-gold"
              >
                {dark ? (
                  <Sun className="h-4 w-4" strokeWidth={1.5} aria-hidden />
                ) : (
                  <Moon className="h-4 w-4" strokeWidth={1.5} aria-hidden />
                )}
              </button>
              <button
                type="button"
                aria-label="Close menu"
                onClick={closeMenu}
                className="flex h-10 w-10 items-center justify-center"
              >
                <span className="relative block h-4 w-4">
                  <span className="absolute left-0 top-1/2 h-px w-4 rotate-45 bg-alabaster" />
                  <span className="absolute left-0 top-1/2 h-px w-4 -rotate-45 bg-alabaster" />
                </span>
              </button>
            </div>
          </div>
          <nav aria-label="Mobile" className="flex flex-1 flex-col justify-center gap-2 px-8">
            {LINKS.map((link, i) => (
              <a
                key={link.href}
                href={link.href}
                onClick={closeMenu}
                style={{ animationDelay: `${120 + i * 70}ms` }}
                className="menu-item-in group flex items-baseline gap-4 border-b border-alabaster/10 py-5"
              >
                <span className="text-[10px] tracking-[0.3em] text-gold">
                  0{i + 1}
                </span>
                <span className="font-serif text-4xl transition-colors duration-500 group-hover:text-gold">
                  {link.label}
                </span>
              </a>
            ))}
          </nav>
          <div className="px-8 pb-10">
            <MobileAccountRow onNavigate={() => setOpen(false)} />
            <p className="mt-8 text-[10px] uppercase tracking-[0.3em] text-alabaster/40">
              Paris — Tokyo — New York
            </p>
          </div>
        </div>
      )}
    </>
  );
}

/** Signed-in dropdown / guest entry — desktop corner of the nav. */
function AccountCorner() {
  const { user, openAccount, openSettings, signOut, signOutEverywhere, ready } = useSession();
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!menuOpen) return;
    const onDown = (e: MouseEvent) => {
      if (!menuRef.current?.contains(e.target as Node)) setMenuOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [menuOpen]);

  if (!ready) {
    return <span className="inline-block h-9 w-9 animate-pulse bg-taupe" aria-hidden />;
  }

  if (!user) {
    return (
      <button
        type="button"
        onClick={openAccount}
        className="text-xs uppercase tracking-[0.25em] text-warm-grey transition-colors duration-500 ease-luxe hover:text-gold-ink focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-charcoal"
      >
        Account
      </button>
    );
  }

  const initial = (user.name ?? user.email).match(/[a-z]/i)?.[0]?.toUpperCase() ?? "M";
  const isAdmin = user.role === "admin";

  return (
    <div className="relative" ref={menuRef}>
      <button
        type="button"
        onClick={() => setMenuOpen((v) => !v)}
        aria-expanded={menuOpen}
        aria-haspopup="menu"
        aria-label="Account menu"
        className="flex h-9 w-9 items-center justify-center border border-charcoal/40 font-serif text-sm text-charcoal transition-colors duration-500 ease-luxe hover:border-gold hover:text-gold-ink focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-charcoal"
      >
        {initial}
      </button>

      {menuOpen && (
        <div
          role="menu"
          className="overlay-in absolute right-0 top-full z-50 mt-3 w-64 border border-charcoal/15 bg-alabaster py-2 shadow-[0_16px_48px_rgba(0,0,0,0.14)]"
        >
          <p className="truncate border-b border-charcoal/10 px-5 pb-3 pt-2 text-xs text-warm-grey">
            {user.email}
          </p>
          <a
            role="menuitem"
            href="#saved"
            onClick={() => setMenuOpen(false)}
            className="flex items-center gap-3 px-5 py-3 text-[11px] uppercase tracking-[0.2em] text-warm-grey transition-colors duration-500 ease-luxe hover:text-gold-ink"
          >
            <Bookmark className="h-3.5 w-3.5" strokeWidth={1.5} aria-hidden />
            Saved
          </a>
          <button
            role="menuitem"
            type="button"
            onClick={() => {
              setMenuOpen(false);
              openSettings();
            }}
            className="flex w-full items-center gap-3 px-5 py-3 text-left text-[11px] uppercase tracking-[0.2em] text-warm-grey transition-colors duration-500 ease-luxe hover:text-gold-ink"
          >
            <Settings2 className="h-3.5 w-3.5" strokeWidth={1.5} aria-hidden />
            Settings
          </button>
          {isAdmin && (
            <a
              role="menuitem"
              href="#admin"
              onClick={() => setMenuOpen(false)}
              className="flex items-center gap-3 px-5 py-3 text-[11px] uppercase tracking-[0.2em] text-warm-grey transition-colors duration-500 ease-luxe hover:text-gold-ink"
            >
              <ShieldCheck className="h-3.5 w-3.5" strokeWidth={1.5} aria-hidden />
              Admin Console
            </a>
          )}
          <button
            role="menuitem"
            type="button"
            onClick={() => {
              setMenuOpen(false);
              void signOut();
            }}
            className="flex w-full items-center gap-3 border-t border-charcoal/10 px-5 py-3 text-left text-[11px] uppercase tracking-[0.2em] text-warm-grey transition-colors duration-500 ease-luxe hover:text-gold-ink"
          >
            <LogOut className="h-3.5 w-3.5" strokeWidth={1.5} aria-hidden />
            Sign out
          </button>
          <button
            role="menuitem"
            type="button"
            onClick={() => {
              setMenuOpen(false);
              void signOutEverywhere();
            }}
            className="flex w-full items-center gap-3 px-5 pb-1 pt-2 text-left text-[11px] uppercase tracking-[0.2em] text-warm-grey transition-colors duration-500 ease-luxe hover:text-gold-ink"
          >
            <Globe className="h-3.5 w-3.5" strokeWidth={1.5} aria-hidden />
            Sign out everywhere
          </button>
        </div>
      )}
    </div>
  );
}

/** Account row inside the mobile overlay. */
function MobileAccountRow({ onNavigate }: { onNavigate: () => void }) {
  const { user, openAccount, openSettings, signOut, signOutEverywhere, ready } = useSession();

  if (!ready) return null;

  if (!user) {
    return (
      <button
        type="button"
        onClick={() => {
          onNavigate();
          openAccount();
        }}
        className="flex w-full items-center justify-between border-t border-alabaster/10 pt-6 text-[11px] uppercase tracking-[0.25em] text-alabaster/70 transition-colors duration-500 ease-luxe hover:text-gold"
      >
        Account — Sign in
        <span aria-hidden className="h-px w-8 bg-gold" />
      </button>
    );
  }

  return (
    <div className="space-y-4 border-t border-alabaster/10 pt-6">
      <p className="truncate text-xs text-alabaster/60">{user.email}</p>
      <div className="flex flex-wrap gap-x-8 gap-y-3">
        <a
          href="#saved"
          onClick={onNavigate}
          className="text-[11px] uppercase tracking-[0.25em] text-alabaster/70 transition-colors duration-500 ease-luxe hover:text-gold"
        >
          Saved
        </a>
        <button
          type="button"
          onClick={() => {
            onNavigate();
            openSettings();
          }}
          className="text-[11px] uppercase tracking-[0.25em] text-alabaster/70 transition-colors duration-500 ease-luxe hover:text-gold"
        >
          Settings
        </button>
        {user.role === "admin" && (
          <a
            href="#admin"
            onClick={onNavigate}
            className="text-[11px] uppercase tracking-[0.25em] text-alabaster/70 transition-colors duration-500 ease-luxe hover:text-gold"
          >
            Admin
          </a>
        )}
        <button
          type="button"
          onClick={() => {
            onNavigate();
            void signOut();
          }}
          className="text-[11px] uppercase tracking-[0.25em] text-alabaster/70 transition-colors duration-500 ease-luxe hover:text-gold"
        >
          Sign out
        </button>
      </div>
    </div>
  );
}
