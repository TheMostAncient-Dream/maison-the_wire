"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import type { ItemDTO, PrefsDTO, SessionUser } from "@/lib/types";
import { AccountModal } from "./account-modal";
import { SettingsModal } from "./settings-modal";
import { OnboardingFlow } from "./onboarding-flow";
import { VerifyEmailFlow } from "./verify-email-flow";

/**
 * Session — the reader at the centre of MAISON. Holds the signed-in
 * user (from /api/auth/me), their server preferences, and the set of
 * bookmarked dispatches. Guests are first-class: preferences persist
 * to localStorage and migrate into /api/preferences on sign-in.
 * The account and settings modals are mounted here so any component
 * (nav, cards, saved view) can summon them.
 */

const LOCAL_PREFS_KEY = "maison-prefs";

export function getLocalPrefs(): Partial<PrefsDTO> | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(LOCAL_PREFS_KEY);
    if (!raw) return null;
    const parsed: unknown = JSON.parse(raw);
    if (typeof parsed !== "object" || parsed === null) return null;
    return parsed as Partial<PrefsDTO>;
  } catch {
    return null;
  }
}

function writeLocalPrefs(prefs: Partial<PrefsDTO> | null) {
  if (typeof window === "undefined") return;
  try {
    if (prefs === null) window.localStorage.removeItem(LOCAL_PREFS_KEY);
    else window.localStorage.setItem(LOCAL_PREFS_KEY, JSON.stringify(prefs));
  } catch {
    /* private mode — preferences simply won't persist */
  }
}

interface SessionState {
  user: SessionUser | null;
  /** True once the initial /api/auth/me round-trip has landed. */
  ready: boolean;
  /** Effective preferences — server for members, localStorage for guests. */
  prefs: PrefsDTO;
  /** Ids of the signed-in reader's bookmarked dispatches. */
  savedIds: Set<string>;
  /** Bumped on every bookmark change — views can refetch on it. */
  savedVersion: number;
  openAccount: () => void;
  openSettings: () => void;
  /** Summon the verify screen from Settings (or anywhere). */
  openVerify: () => void;
  refresh: () => Promise<void>;
  /** Persist preferences (server or localStorage) and announce the change. */
  applyPrefs: (partial: Partial<PrefsDTO>) => Promise<void>;
  /** Optimistic bookmark toggle; invites guests to sign in instead. */
  toggleSave: (item: ItemDTO) => Promise<void>;
  signOut: () => Promise<void>;
  /** Bump sessionVersion server-side, revoking every token for this account. */
  signOutEverywhere: () => Promise<void>;
}

const SessionContext = createContext<SessionState | null>(null);

export function useSession(): SessionState {
  const ctx = useContext(SessionContext);
  if (!ctx) throw new Error("useSession must be used within SessionProvider");
  return ctx;
}

const DEFAULTS: PrefsDTO = {
  columns: ["latest", "trending", "world", "business", "technology", "science", "sports", "entertainment"],
  sourceSlugs: [],
  youtubeChannelIds: [],
  instagramHandles: [],
  languages: [],
  countries: [],
  contentTypes: ["article", "video"],
  itemsPerColumn: 12,
  refreshIntervalMin: 5,
  theme: "system",
};

export function SessionProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [ready, setReady] = useState(false);
  const [serverPrefs, setServerPrefs] = useState<PrefsDTO | null>(null);
  const [localPrefs, setLocalPrefs] = useState<Partial<PrefsDTO>>({});
  const [savedIds, setSavedIds] = useState<Set<string>>(new Set());
  const [savedVersion, setSavedVersion] = useState(0);
  const [accountOpen, setAccountOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [verifyOpen, setVerifyOpen] = useState(false);
  /** Cleared once the reader finishes (or skips) the post-signup flow. */
  const [onboardingDone, setOnboardingDone] = useState(false);
  /** "Later" on the verify screen — remembered per reader, not forever nagged. */
  const [verifyDismissed, setVerifyDismissed] = useState(true);

  const verifyKey = (id: string) => `maison-verify-dismissed:${id}`;

  /* Read the dismissal when the reader (or their verified-ness) changes. */
  useEffect(() => {
    let cancelled = false;
    queueMicrotask(() => {
      if (cancelled) return;
      if (!user || user.emailVerified) {
        setVerifyDismissed(true);
        return;
      }
      try {
        setVerifyDismissed(window.localStorage.getItem(verifyKey(user.id)) === "1");
      } catch {
        setVerifyDismissed(true);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [user?.id, user?.emailVerified]);

  const effectivePrefs: PrefsDTO = useMemo(
    () => ({ ...DEFAULTS, ...(user ? (serverPrefs ?? {}) : localPrefs) }),
    [user, serverPrefs, localPrefs]
  );

  /*
   * Gates, in order: an unproven address stands in front of everything
   * (unless the reader said "later"), then the New Reader sequence.
   */
  const needsVerify = ready && !!user && !user.emailVerified;
  const showVerifyFlow = needsVerify && (!verifyDismissed || verifyOpen);
  const showOnboarding = ready && !!user && !user.onboarded && !onboardingDone;

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/auth/me");
      const data = (await res.json()) as { user: SessionUser | null; prefs: PrefsDTO | null };
      setUser(data.user);
      setServerPrefs(data.prefs);

      if (data.user) {
        // Migrate guest preferences into the account exactly once.
        const guest = getLocalPrefs();
        if (guest && Object.keys(guest).length > 0) {
          try {
            const put = await fetch("/api/preferences", {
              method: "PUT",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(guest),
            });
            if (put.ok) {
              const saved = (await put.json()) as { prefs: PrefsDTO };
              setServerPrefs(saved.prefs);
            }
          } catch {
            /* migration is best-effort — server prefs still apply */
          }
          writeLocalPrefs(null);
          setLocalPrefs({});
        }
        // Load the bookmark shelf for the gold marks.
        try {
          const bm = await fetch("/api/bookmarks");
          if (bm.ok) {
            const list = (await bm.json()) as { items: { id: string }[] };
            setSavedIds(new Set(list.items.map((i) => i.id)));
          }
        } catch {
          /* saved marks load lazily on the Saved view otherwise */
        }
      } else {
        setSavedIds(new Set());
      }
    } catch {
      setUser(null);
    } finally {
      setReady(true);
    }
  }, []);

  /* Initial session hydration. */
  useEffect(() => {
    let cancelled = false;
    queueMicrotask(() => {
      if (cancelled) return;
      setLocalPrefs(getLocalPrefs() ?? {});
      void refresh();
    });
    return () => {
      cancelled = true;
    };
  }, [refresh]);

  const applyPrefs = useCallback(
    async (partial: Partial<PrefsDTO>) => {
      if (user) {
        try {
          const res = await fetch("/api/preferences", {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(partial),
          });
          if (res.ok) {
            const data = (await res.json()) as { prefs: PrefsDTO };
            setServerPrefs(data.prefs);
          }
        } catch {
          /* keep the optimistic local view; next refresh reconciles */
        }
      } else {
        const merged = { ...localPrefs, ...partial };
        setLocalPrefs(merged);
        writeLocalPrefs(merged);
      }
      window.dispatchEvent(new CustomEvent("maison:prefs-changed"));
    },
    [user, localPrefs]
  );

  const toggleSave = useCallback(
    async (item: ItemDTO) => {
      if (!user) {
        setAccountOpen(true);
        return;
      }
      // Optimistic flip — the gold mark answers instantly.
      let removed = false;
      setSavedIds((prev) => {
        const next = new Set(prev);
        if (next.has(item.id)) {
          next.delete(item.id);
          removed = true;
        } else {
          next.add(item.id);
        }
        return next;
      });
      setSavedVersion((v) => v + 1);
      try {
        const res = await fetch("/api/bookmarks", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ itemId: item.id }),
        });
        if (!res.ok) throw new Error("bookmark failed");
        const data = (await res.json()) as { saved: boolean };
        // Reconcile with the server's truth (protects against races).
        setSavedIds((prev) => {
          const next = new Set(prev);
          if (data.saved) next.add(item.id);
          else next.delete(item.id);
          return next;
        });
      } catch {
        // Roll back silently — the wire is impatient, not broken.
        setSavedIds((prev) => {
          const next = new Set(prev);
          if (removed) next.add(item.id);
          else next.delete(item.id);
          return next;
        });
        setSavedVersion((v) => v + 1);
      }
    },
    [user]
  );

  const signOut = useCallback(async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } catch {
      /* clearing locally regardless */
    }
    setUser(null);
    setServerPrefs(null);
    setSavedIds(new Set());
    setSavedVersion((v) => v + 1);
  }, []);

  const signOutEverywhere = useCallback(async () => {
    try {
      await fetch("/api/auth/logout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ everywhere: true }),
      });
    } catch {
      /* clearing locally regardless */
    }
    setUser(null);
    setServerPrefs(null);
    setSavedIds(new Set());
    setSavedVersion((v) => v + 1);
  }, []);

  const openAccount = useCallback(() => {
    setSettingsOpen(false);
    setAccountOpen(true);
  }, []);

  const openSettings = useCallback(() => {
    setAccountOpen(false);
    setSettingsOpen(true);
  }, []);

  const openVerify = useCallback(() => {
    setAccountOpen(false);
    setSettingsOpen(false);
    setVerifyOpen(true);
  }, []);

  const dismissVerify = useCallback(() => {
    setVerifyOpen(false);
    setVerifyDismissed(true);
    try {
      if (user) window.localStorage.setItem(verifyKey(user.id), "1");
    } catch {
      /* private mode — the dismissal just lives for this visit */
    }
  }, [user]);

  const state: SessionState = {
    user,
    ready,
    prefs: effectivePrefs,
    savedIds,
    savedVersion,
    openAccount,
    openSettings,
    openVerify,
    refresh,
    applyPrefs,
    toggleSave,
    signOut,
    signOutEverywhere,
  };

  return (
    <SessionContext.Provider value={state}>
      {children}
      {showVerifyFlow && (
        <VerifyEmailFlow
          onComplete={async () => {
            setVerifyOpen(false);
            setVerifyDismissed(true);
            await refresh();
          }}
          onSkip={dismissVerify}
        />
      )}
      {!showVerifyFlow && showOnboarding && (
        <OnboardingFlow
          onComplete={async () => {
            setOnboardingDone(true);
            await refresh();
            // Land the new reader at the front page, as any first visit would.
            document
              .getElementById("front-page")
              ?.scrollIntoView({ behavior: "smooth", block: "start" });
          }}
        />
      )}
      {accountOpen && (
        <AccountModal
          onClose={() => setAccountOpen(false)}
          onSignedIn={async () => {
            setAccountOpen(false);
            await refresh();
          }}
        />
      )}
      {settingsOpen && <SettingsModal onClose={() => setSettingsOpen(false)} />}
    </SessionContext.Provider>
  );
}

/** Shape of the Saved shelf endpoint — items plus their save timestamp. */
export interface SavedItemDTO extends ItemDTO {
  savedAt: string;
}
