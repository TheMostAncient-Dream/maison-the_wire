"use client";

import { useEffect, useRef, type ReactNode } from "react";
import { X } from "lucide-react";

/**
 * Shared modal shell — the same paper-panel DNA as the dispatch modal:
 * alabaster panel, hairline border, layered shadow, sticky overline
 * header, backdrop-click + Esc to close, body scroll lock, focus to X.
 */
export function ModalShell({
  label,
  onClose,
  children,
  maxWidth = "max-w-md",
}: {
  label: string;
  onClose: () => void;
  children: ReactNode;
  maxWidth?: string;
}) {
  const closeRef = useRef<HTMLButtonElement>(null);

  /* Scroll lock, initial focus, Esc-to-close */
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center p-4 md:p-8"
      role="dialog"
      aria-modal="true"
      aria-label={label}
    >
      <div
        className="overlay-in absolute inset-0 bg-black/45 backdrop-blur-[2px]"
        onClick={onClose}
        aria-hidden
      />

      <div
        className={`rounded-panel news-panel relative flex max-h-[86vh] w-full ${maxWidth} flex-col overflow-hidden border border-charcoal/15 bg-alabaster shadow-[0_24px_64px_rgba(0,0,0,0.18)]`}
      >
        <div className="flex items-center justify-between border-b border-charcoal/10 px-6 py-4 md:px-8">
          <span className="text-[10px] uppercase tracking-[0.3em] text-warm-grey">
            {label}
          </span>
          <button
            ref={closeRef}
            type="button"
            onClick={onClose}
            aria-label={`Close ${label}`}
            className="flex h-9 w-9 items-center justify-center text-warm-grey transition-colors duration-500 ease-luxe hover:text-gold-ink focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-charcoal"
          >
            <X className="h-4 w-4" strokeWidth={1.5} aria-hidden />
          </button>
        </div>

        <div className="luxe-scroll overflow-y-auto px-6 py-8 md:px-8">{children}</div>
      </div>
    </div>
  );
}
