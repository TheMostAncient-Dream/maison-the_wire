"use client";

import { useEffect, useState } from "react";
import { Check } from "lucide-react";
import type { TopicDTO } from "@/lib/types";
import { cn } from "@/lib/utils";
import { subscribeToPush, type SubscribeOutcome } from "@/lib/push-client";
import { useSession } from "./session-provider";
import { SourceNotifyList } from "./source-notify-list";

/**
 * The New Reader sequence — a full-viewport step after first registration
 * (never after login, never for accounts that predate it). Three steps:
 * choose desks, choose alerting outlets, confirm. Paper-panel DNA, full
 * viewport instead of a dialog, so it reads as a dedicated page turn.
 *
 * Every step persists as it goes — topic choices write to the same
 * preference store Settings uses, alert choices to the same
 * notifySourceIds store the Settings Notifications section edits — so a
 * visitor who wanders off mid-flow returns to their selections, and the
 * flow resumes where they left it.
 */

const STEP_KEY = "maison-onboarding-step";

const PSEUDO = [
  { slug: "latest", name: "Latest" },
  { slug: "trending", name: "Trending" },
];

type Step = 1 | 2 | 3;

export function OnboardingFlow({ onComplete }: { onComplete: () => Promise<void> }) {
  const { prefs, applyPrefs } = useSession();

  /*
   * Resume where the reader left off — read synchronously at mount so the
   * flow opens on the saved step without a flicker (no effect-setState).
   */
  const [step, setStep] = useState<Step>(() => {
    if (typeof window === "undefined") return 1;
    try {
      const raw = window.localStorage.getItem(STEP_KEY);
      const n = raw ? Number(JSON.parse(raw)) : 1;
      return n === 2 || n === 3 ? (n as Step) : 1;
    } catch {
      return 1;
    }
  });

  // Step 1 state
  const [universe, setUniverse] = useState<{ slug: string; name: string }[]>(PSEUDO);
  const [topics, setTopics] = useState<string[]>([]);

  // Step 2 state
  const [desks, setDesks] = useState<Set<string>>(new Set());
  const [confirming, setConfirming] = useState(false);
  const [outcome, setOutcome] = useState<SubscribeOutcome | null>(null);
  const [vapidKey, setVapidKey] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  /* Prefill what earlier steps already saved, and fetch the push key. */
  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/notifications");
        if (res.ok) {
          const data = (await res.json()) as {
            notifySourceIds: string[];
            vapidPublicKey: string | null;
          };
          setVapidKey(data.vapidPublicKey);
          if (step > 1) setDesks(new Set(data.notifySourceIds));
        }
      } catch {
        /* alert choice stays empty — skippable anyway */
      }
      if (step > 1) setTopics(prefs.columns);
    })();
  }, []);

  /* The topic universe — the exact list Settings offers. */
  useEffect(() => {
    fetch("/api/topics")
      .then((r) => r.json())
      .then((list: TopicDTO[]) => setUniverse([...PSEUDO, ...list.map((t) => ({ slug: t.slug, name: t.name }))]))
      .catch(() => {});
  }, []);

  const saveStep = (s: Step) => {
    try {
      window.localStorage.setItem(STEP_KEY, JSON.stringify(s));
    } catch {
      /* private mode — resume just falls back to step 1 */
    }
  };

  const toggleTopic = (slug: string) =>
    setTopics((prev) => (prev.includes(slug) ? prev.filter((s) => s !== slug) : [...prev, slug]));

  const continueTopics = async () => {
    if (topics.length === 0 || busy) return;
    setBusy(true);
    // Same preference store Settings writes — selections appear in
    // Columns/Settings immediately afterward.
    await applyPrefs({ columns: topics });
    saveStep(2);
    setConfirming(false);
    setBusy(false);
    setStep(2);
  };

  const toggleDesk = (id: string) =>
    setDesks((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  /** Persist the alert choice server-side — the one source of truth. */
  const persistDesks = async () => {
    const res = await fetch("/api/notifications", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ notifySourceIds: [...desks] }),
    });
    if (res.ok) {
      const data = (await res.json()) as { notifySourceIds: string[] };
      setDesks(new Set(data.notifySourceIds));
    }
  };

  const allowAlerts = async () => {
    if (busy || !vapidKey) return;
    setBusy(true);
    setOutcome(null);
    await persistDesks();
    const result = await subscribeToPush(vapidKey);
    setOutcome(result);
    setBusy(false);
    saveStep(3);
    setStep(3);
  };

  const skipAlerts = async () => {
    if (busy) return;
    setBusy(true);
    await persistDesks();
    setBusy(false);
    saveStep(3);
    setStep(3);
  };

  const finish = async () => {
    setBusy(true);
    await fetch("/api/notifications", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ completeOnboarding: true }),
    });
    try {
      window.localStorage.removeItem(STEP_KEY);
    } catch {
      /* nothing to clear */
    }
    await onComplete();
  };

  /** Explicit skip from any step — never lose what earlier steps saved. */
  const skipEverything = async () => {
    if (busy) return;
    setBusy(true);
    const body: Record<string, unknown> = { completeOnboarding: true };
    if (step >= 2) body.notifySourceIds = [...desks];
    await fetch("/api/notifications", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }).catch(() => {});
    try {
      window.localStorage.removeItem(STEP_KEY);
    } catch {
      /* nothing to clear */
    }
    await onComplete();
  };

  const stepLabel = ["", "I — The desks you follow", "II — The desks that alert you", "III — Set"][step];

  return (
    <div
      className="fixed inset-0 z-[80] overflow-y-auto bg-alabaster text-charcoal luxe-scroll"
      role="dialog"
      aria-modal="true"
      aria-label="Welcome to Maison — new reader"
    >
      {/* Masthead strip */}
      <div className="border-b border-charcoal/10">
        <div className="mx-auto flex max-w-2xl items-center justify-between px-6 py-5 md:px-8">
          <span className="text-[10px] uppercase tracking-[0.35em] text-warm-grey">
            Maison — a new reader
          </span>
          <button
            type="button"
            onClick={skipEverything}
            className="border-b border-charcoal/15 pb-0.5 text-[10px] uppercase tracking-[0.25em] text-warm-grey transition-colors duration-500 ease-luxe hover:border-gold hover:text-charcoal"
          >
            Skip for now
          </button>
        </div>
      </div>

      <div className="mx-auto max-w-2xl px-6 pb-24 pt-10 md:px-8 md:pt-16">
        <p className="text-[10px] uppercase tracking-[0.3em] text-gold-ink">{stepLabel}</p>

        {step === 1 && (
          <div className="overlay-in">
            <h1 className="mt-6 font-serif text-5xl leading-[1.02] md:text-6xl">
              What do you want
              <br />
              to <em className="italic">follow?</em>
            </h1>
            <p className="mt-5 max-w-md text-sm leading-relaxed text-warm-grey">
              Choose the desks that front your edition. These become your columns —
              and you can rearrange them any time in Settings.
            </p>

            <div className="mt-10 flex flex-wrap gap-2.5">
              {universe.map((u) => {
                const on = topics.includes(u.slug);
                return (
                  <button
                    key={u.slug}
                    type="button"
                    aria-pressed={on}
                    onClick={() => toggleTopic(u.slug)}
                    className={cn(
                      "border px-4 py-2.5 text-[11px] uppercase tracking-[0.2em] transition-all duration-500 ease-luxe focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-charcoal",
                      on
                        ? "border-gold bg-gold/10 text-charcoal"
                        : "border-charcoal/20 text-warm-grey hover:border-charcoal/50 hover:text-charcoal"
                    )}
                  >
                    {u.name}
                  </button>
                );
              })}
            </div>

            <div className="mt-12 flex items-center gap-5">
              <button
                type="button"
                onClick={continueTopics}
                disabled={topics.length === 0 || busy}
                className="group relative h-12 overflow-hidden bg-charcoal px-10 text-xs font-medium uppercase tracking-[0.25em] text-alabaster transition-all duration-500 ease-luxe hover:shadow-[0_8px_24px_rgba(0,0,0,0.25)] disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-charcoal"
              >
                <span
                  aria-hidden
                  className="absolute inset-0 -translate-x-[101%] bg-gold transition-transform duration-500 ease-luxe group-hover:translate-x-0"
                />
                <span className="relative z-10">{busy ? "Setting type…" : "Continue"}</span>
              </button>
              <span className="text-[11px] italic text-warm-grey">
                {topics.length === 0
                  ? "Choose at least one desk to continue."
                  : `${topics.length} chosen — nothing is pre-checked; the page is yours to set.`}
              </span>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="overlay-in">
            <h1 className="mt-6 font-serif text-5xl leading-[1.02] md:text-6xl">
              Which outlets
              <br />
              should <em className="italic">alert you?</em>
            </h1>
            <p className="mt-5 max-w-md text-sm leading-relaxed text-warm-grey">
              Tick the desks you want a quiet alert from when they break a story.
              This is entirely optional — skip freely.
            </p>

            <div className="mt-10">
              <SourceNotifyList selectedIds={desks} onToggle={toggleDesk} />
            </div>

            {!confirming ? (
              <div className="mt-10 flex flex-wrap items-center gap-6">
                <button
                  type="button"
                  onClick={() => (desks.size > 0 ? setConfirming(true) : skipAlerts())}
                  disabled={busy}
                  className="group relative h-12 overflow-hidden bg-charcoal px-10 text-xs font-medium uppercase tracking-[0.25em] text-alabaster transition-all duration-500 ease-luxe hover:shadow-[0_8px_24px_rgba(0,0,0,0.25)] disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-charcoal"
                >
                  <span
                    aria-hidden
                    className="absolute inset-0 -translate-x-[101%] bg-gold transition-transform duration-500 ease-luxe group-hover:translate-x-0"
                  />
                  <span className="relative z-10">
                    {desks.size > 0 ? "Continue" : "Skip alerts"}
                  </span>
                </button>
                <button
                  type="button"
                  onClick={skipAlerts}
                  className="border-b border-charcoal/15 pb-0.5 text-[11px] uppercase tracking-[0.2em] text-warm-grey transition-colors duration-500 ease-luxe hover:border-gold hover:text-charcoal"
                >
                  Skip for now — I&rsquo;ll choose later
                </button>
              </div>
            ) : (
              <div className="mt-10 border-l-2 border-gold pl-5">
                <p className="text-sm italic leading-relaxed text-charcoal">
                  A quiet alert when these desks break something — nothing else.
                </p>
                <div className="mt-4 flex flex-wrap items-center gap-5">
                  <button
                    type="button"
                    onClick={allowAlerts}
                    disabled={busy}
                    className="group relative h-12 overflow-hidden bg-charcoal px-10 text-xs font-medium uppercase tracking-[0.25em] text-alabaster transition-all duration-500 ease-luxe hover:shadow-[0_8px_24px_rgba(0,0,0,0.25)] disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-charcoal"
                  >
                    <span
                      aria-hidden
                      className="absolute inset-0 -translate-x-[101%] bg-gold transition-transform duration-500 ease-luxe group-hover:translate-x-0"
                    />
                    <span className="relative z-10">{busy ? "Asking…" : "Allow quiet alerts"}</span>
                  </button>
                  <button
                    type="button"
                    onClick={skipAlerts}
                    disabled={busy}
                    className="border-b border-charcoal/15 pb-0.5 text-[11px] uppercase tracking-[0.2em] text-warm-grey transition-colors duration-500 ease-luxe hover:border-gold hover:text-charcoal"
                  >
                    Actually, no alerts
                  </button>
                </div>
                <p className="mt-3 text-[11px] italic text-warm-grey">
                  Your browser will ask for permission next — that is the only ask.
                </p>
              </div>
            )}
          </div>
        )}

        {step === 3 && (
          <div className="overlay-in">
            <h1 className="mt-6 font-serif text-5xl leading-[1.02] md:text-6xl">
              You&rsquo;re <em className="italic">set.</em>
            </h1>
            <div className="mt-8 space-y-3 border-t border-charcoal/15 pt-8 text-sm leading-relaxed text-warm-grey">
              <p className="flex items-baseline gap-3">
                <span aria-hidden className="font-serif text-lg text-gold-ink">·</span>
                {topics.length} desk{topics.length === 1 ? "" : "es"} fronting your edition
              </p>
              <p className="flex items-baseline gap-3">
                <span aria-hidden className="font-serif text-lg text-gold-ink">·</span>
                {desks.size === 0
                  ? "No quiet alerts yet — choose outlets any time in Settings"
                  : `${desks.size} outlet${desks.size === 1 ? "" : "s"} on quiet alerts`}
              </p>
              {outcome && outcome.ok && (
                <p className="flex items-baseline gap-3 text-charcoal">
                  <Check className="h-3.5 w-3.5 shrink-0 self-center text-gold-ink" strokeWidth={2} aria-hidden />
                  Quiet alerts are on — the next dispatch from those desks arrives softly.
                </p>
              )}
              {outcome && !outcome.ok && outcome.reason === "denied" && (
                <p className="flex items-baseline gap-3">
                  <span aria-hidden className="font-serif text-lg text-gold-ink">·</span>
                  Alerts stayed quiet — your browser declined; re-enable them later from Settings.
                </p>
              )}
              {outcome && !outcome.ok && outcome.reason !== "denied" && (
                <p className="flex items-baseline gap-3">
                  <span aria-hidden className="font-serif text-lg text-gold-ink">·</span>
                  Alerts stayed quiet — enable them later from Settings.
                </p>
              )}
            </div>

            <button
              type="button"
              onClick={finish}
              disabled={busy}
              className="group relative mt-12 h-12 overflow-hidden bg-charcoal px-10 text-xs font-medium uppercase tracking-[0.25em] text-alabaster transition-all duration-500 ease-luxe hover:shadow-[0_8px_24px_rgba(0,0,0,0.25)] disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-charcoal"
            >
              <span
                aria-hidden
                className="absolute inset-0 -translate-x-[101%] bg-gold transition-transform duration-500 ease-luxe group-hover:translate-x-0"
              />
              <span className="relative z-10">{busy ? "Opening…" : "Enter the paper"}</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
