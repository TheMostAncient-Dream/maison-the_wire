"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowDown, ArrowUp, GripVertical, X } from "lucide-react";
import type { PrefsDTO, TopicDTO } from "@/lib/types";
import { cn } from "@/lib/utils";
import { useSession } from "./session-provider";
import { ModalShell } from "./modal-shell";
import { NotificationsSection } from "./notifications-settings";

/**
 * Settings — shape your edition. Which topics appear as columns, in what
 * order (pointer drag, or the arrows on touch), how deep each column
 * runs, and whether films sit beside the written word. Guests persist
 * to localStorage; members straight into /api/preferences — the split
 * the provider already owns.
 */

interface ColumnOption {
  slug: string;
  name: string;
}

const PSEUDO: ColumnOption[] = [
  { slug: "latest", name: "Latest" },
  { slug: "trending", name: "Trending" },
];

const LIMITS = [6, 9, 12, 18, 24];

export function SettingsModal({ onClose }: { onClose: () => void }) {
  const { prefs, applyPrefs, user, openVerify } = useSession();
  const [universe, setUniverse] = useState<ColumnOption[]>(PSEUDO);
  const [columns, setColumns] = useState<string[]>(prefs.columns);
  const [itemsPerColumn, setItemsPerColumn] = useState(prefs.itemsPerColumn);
  const [types, setTypes] = useState<string[]>(prefs.contentTypes);
  const [saving, setSaving] = useState(false);
  const dragIndex = useRef<number | null>(null);

  useEffect(() => {
    fetch("/api/topics")
      .then((r) => r.json())
      .then((list: TopicDTO[]) => {
        setUniverse([...PSEUDO, ...list.map((t) => ({ slug: t.slug, name: t.name }))]);
      })
      .catch(() => {});
  }, []);

  const label = (slug: string) =>
    universe.find((u) => u.slug === slug)?.name ??
    slug.charAt(0).toUpperCase() + slug.slice(1);

  const available = universe.filter((u) => !columns.includes(u.slug));

  const addColumn = (slug: string) => setColumns((c) => [...c, slug]);
  const removeColumn = (slug: string) =>
    setColumns((c) => c.filter((s) => s !== slug));

  const move = (from: number, to: number) => {
    setColumns((c) => {
      if (to < 0 || to >= c.length) return c;
      const next = [...c];
      const [item] = next.splice(from, 1);
      next.splice(to, 0, item);
      return next;
    });
  };

  const toggleType = (t: string) =>
    setTypes((prev) =>
      prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]
    );

  const save = async () => {
    setSaving(true);
    await applyPrefs({
      columns: columns.length > 0 ? columns : ["latest"],
      itemsPerColumn,
      contentTypes: types.length > 0 ? (types as PrefsDTO["contentTypes"]) : ["article", "video"],
    });
    setSaving(false);
    onClose();
  };

  return (
    <ModalShell label="Maison — Settings" onClose={onClose} maxWidth="max-w-lg">
      <h2 className="font-serif text-3xl leading-tight text-charcoal">
        Set your edition.
      </h2>
      <p className="mt-3 text-sm leading-relaxed text-warm-grey">
        Choose the desks that front your page, arrange them as you please,
        and decide how deep each column runs.
      </p>

      {/* Column order */}
      <h3 className="mt-9 text-[10px] uppercase tracking-[0.25em] text-warm-grey">
        Your columns — drag to reorder
      </h3>
      <ul className="mt-3 border-t border-charcoal/10">
        {columns.map((slug, i) => (
          <li
            key={slug}
            draggable
            onDragStart={() => {
              dragIndex.current = i;
            }}
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              if (dragIndex.current !== null && dragIndex.current !== i) {
                move(dragIndex.current, i);
              }
              dragIndex.current = null;
            }}
            className="flex items-center gap-3 border-b border-charcoal/10 py-2.5"
          >
            <GripVertical
              className="h-3.5 w-3.5 shrink-0 cursor-grab text-warm-grey/50"
              strokeWidth={1.5}
              aria-hidden
            />
            <span className="flex-1 text-sm text-charcoal">{label(slug)}</span>
            <button
              type="button"
              aria-label={`Move ${label(slug)} earlier`}
              onClick={() => move(i, i - 1)}
              disabled={i === 0}
              className="p-1 text-warm-grey transition-colors duration-500 ease-luxe hover:text-gold-ink disabled:opacity-30"
            >
              <ArrowUp className="h-3.5 w-3.5" strokeWidth={1.5} aria-hidden />
            </button>
            <button
              type="button"
              aria-label={`Move ${label(slug)} later`}
              onClick={() => move(i, i + 1)}
              disabled={i === columns.length - 1}
              className="p-1 text-warm-grey transition-colors duration-500 ease-luxe hover:text-gold-ink disabled:opacity-30"
            >
              <ArrowDown className="h-3.5 w-3.5" strokeWidth={1.5} aria-hidden />
            </button>
            <button
              type="button"
              aria-label={`Remove ${label(slug)} column`}
              onClick={() => removeColumn(slug)}
              className="p-1 text-warm-grey transition-colors duration-500 ease-luxe hover:text-gold-ink"
            >
              <X className="h-3.5 w-3.5" strokeWidth={1.5} aria-hidden />
            </button>
          </li>
        ))}
        {columns.length === 0 && (
          <li className="border-b border-charcoal/10 py-4 text-sm italic text-warm-grey">
            No columns chosen — add a desk below.
          </li>
        )}
      </ul>

      {/* Available desks */}
      <h3 className="mt-8 text-[10px] uppercase tracking-[0.25em] text-warm-grey">
        Add a desk
      </h3>
      <div className="mt-3 flex flex-wrap gap-x-5 gap-y-2.5">
        {available.map((u) => (
          <button
            key={u.slug}
            type="button"
            onClick={() => addColumn(u.slug)}
            className="border-b border-charcoal/15 pb-1 text-xs uppercase tracking-[0.2em] text-warm-grey transition-colors duration-500 ease-luxe hover:border-gold hover:text-charcoal"
          >
            + {u.name}
          </button>
        ))}
        {available.length === 0 && (
          <p className="text-sm italic text-warm-grey">
            Every desk is already on your page.
          </p>
        )}
      </div>

      {/* Depth + content */}
      <div className="mt-9 grid grid-cols-1 gap-8 border-t border-charcoal/10 pt-7 sm:grid-cols-2">
        <div>
          <h3 className="text-[10px] uppercase tracking-[0.25em] text-warm-grey">
            Items per column
          </h3>
          <div className="mt-3 flex flex-wrap gap-x-5 gap-y-2">
            {LIMITS.map((n) => (
              <button
                key={n}
                type="button"
                aria-pressed={itemsPerColumn === n}
                onClick={() => setItemsPerColumn(n)}
                className={cn(
                  "border-b pb-1 text-xs uppercase tracking-[0.2em] transition-colors duration-500 ease-luxe",
                  itemsPerColumn === n
                    ? "border-gold text-charcoal"
                    : "border-transparent text-warm-grey hover:text-charcoal"
                )}
              >
                {n}
              </button>
            ))}
          </div>
        </div>
        <div>
          <h3 className="text-[10px] uppercase tracking-[0.25em] text-warm-grey">
            Content in columns
          </h3>
          <div className="mt-3 flex flex-wrap gap-x-5 gap-y-2">
            {[
              { value: "article", label: "Articles" },
              { value: "video", label: "Films" },
            ].map((t) => (
              <button
                key={t.value}
                type="button"
                aria-pressed={types.includes(t.value)}
                onClick={() => toggleType(t.value)}
                className={cn(
                  "border-b pb-1 text-xs uppercase tracking-[0.2em] transition-colors duration-500 ease-luxe",
                  types.includes(t.value)
                    ? "border-gold text-charcoal"
                    : "border-transparent text-warm-grey hover:text-charcoal"
                )}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* The post — a door back to verification for skipped addresses */}
      {user && !user.emailVerified && (
        <div className="mt-9 border border-gold/40 bg-gold/5 p-4">
          <p className="text-[10px] uppercase tracking-[0.25em] text-gold-ink">The post</p>
          <p className="mt-1.5 text-sm leading-relaxed text-charcoal">
            {user.email} isn&rsquo;t proven yet — quiet alerts wait on a verified address.
          </p>
          <button
            type="button"
            onClick={() => {
              onClose();
              openVerify();
            }}
            className="mt-2.5 border-b border-charcoal/20 pb-0.5 text-[11px] uppercase tracking-[0.2em] text-warm-grey transition-colors duration-500 ease-luxe hover:border-gold hover:text-charcoal"
          >
            Verify now
          </button>
        </div>
      )}

      {/* Notifications — same notifySourceIds store onboarding wrote */}
      <NotificationsSection />

      <button
        type="button"
        onClick={save}
        disabled={saving}
        className="group relative mt-10 h-12 w-full overflow-hidden bg-charcoal text-xs font-medium uppercase tracking-[0.25em] text-alabaster transition-all duration-500 ease-luxe hover:shadow-[0_8px_24px_rgba(0,0,0,0.25)] disabled:pointer-events-none disabled:opacity-50 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-charcoal focus-visible:ring-offset-2 focus-visible:ring-offset-alabaster"
      >
        <span
          aria-hidden
          className="absolute inset-0 -translate-x-[101%] bg-gold transition-transform duration-500 ease-luxe group-hover:translate-x-0"
        />
        <span className="relative z-10">
          {saving ? "Setting type…" : "Save the edition"}
        </span>
      </button>
    </ModalShell>
  );
}
