"use client";

import { useEffect, useMemo, useState } from "react";
import { Check } from "lucide-react";
import type { SourceDTO } from "@/lib/types";
import { cn } from "@/lib/utils";

/**
 * The alerting registry — sources grouped by primary desk, each with a
 * quiet per-source toggle. Shared by onboarding Step 2 and the Settings
 * Notifications section so both read/write the exact same choice.
 * Instagram accounts are deliberately absent: they never ingest content,
 * so they could never alert — offering them would be a fake toggle.
 */

function monogramOf(name: string): string {
  return (name.replace(/^@/, "").match(/[a-z]/i)?.[0] ?? "M").toUpperCase();
}

interface Group {
  key: string;
  label: string;
  sources: SourceDTO[];
}

export function SourceNotifyList({
  selectedIds,
  onToggle,
  scrollClass = "max-h-[46vh]",
}: {
  selectedIds: Set<string>;
  /** Called with the source id — the value both stores persist. */
  onToggle: (sourceId: string) => void;
  scrollClass?: string;
}) {
  const [sources, setSources] = useState<SourceDTO[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/sources")
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error("registry"))))
      .then((data: SourceDTO[]) => {
        if (!cancelled) {
          setSources(data);
          setLoaded(true);
        }
      })
      .catch(() => {
        if (!cancelled) setLoaded(true);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const groups = useMemo<Group[]>(() => {
    const alertable = sources.filter((s) => s.isActive && s.type !== "instagram");
    const byTopic = new Map<string, SourceDTO[]>();
    for (const s of alertable) {
      const key = s.topicSlugs[0] ?? "world";
      const list = byTopic.get(key) ?? [];
      list.push(s);
      byTopic.set(key, list);
    }
    return [...byTopic.entries()]
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([key, list]) => ({
        key,
        label: key.charAt(0).toUpperCase() + key.slice(1),
        sources: list.sort((a, b) => a.name.localeCompare(b.name)),
      }));
  }, [sources]);

  if (!loaded) {
    return (
      <p className="py-8 text-center text-sm italic text-warm-grey">
        Reading the registry…
      </p>
    );
  }

  return (
    <div className={cn("luxe-scroll overflow-y-auto pr-1", scrollClass)}>
      <div className="space-y-8">
        {groups.map((group) => (
          <div key={group.key}>
            <div className="flex items-center gap-4">
              <h4 className="text-[10px] font-medium uppercase tracking-[0.3em] text-warm-grey">
                {group.label}
              </h4>
              <span aria-hidden className="h-px flex-1 bg-charcoal/10" />
            </div>
            <ul className="mt-3 border-t border-charcoal/10">
              {group.sources.map((s) => {
                const on = selectedIds.has(s.id);
                return (
                  <li key={s.id} className="border-b border-charcoal/10">
                    <button
                      type="button"
                      onClick={() => onToggle(s.id)}
                      aria-pressed={on}
                      className="group flex w-full items-center gap-3 py-2.5 text-left transition-colors duration-500 ease-luxe focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-charcoal"
                    >
                      <span
                        aria-hidden
                        className="rounded-media flex h-9 w-9 shrink-0 select-none items-center justify-center border border-charcoal/10 bg-taupe/60 font-serif text-lg text-charcoal/25 transition-colors duration-700 ease-luxe group-hover:text-charcoal/40"
                      >
                        {monogramOf(s.name)}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span
                          className={cn(
                            "block truncate text-sm transition-colors duration-500 ease-luxe",
                            on ? "text-charcoal" : "text-charcoal/80 group-hover:text-charcoal"
                          )}
                        >
                          {s.name}
                        </span>
                        <span className="mt-0.5 block truncate text-[10px] uppercase tracking-[0.2em] text-warm-grey/70">
                          {s.topicSlugs.slice(0, 2).join(" · ")}
                          {s.country ? ` · ${s.country}` : ""}
                        </span>
                      </span>
                      <span
                        aria-hidden
                        className={cn(
                          "flex h-5 w-5 shrink-0 items-center justify-center border transition-colors duration-500 ease-luxe",
                          on
                            ? "border-charcoal bg-charcoal text-alabaster"
                            : "border-charcoal/30 bg-transparent text-transparent group-hover:border-gold"
                        )}
                      >
                        <Check className="h-3 w-3" strokeWidth={2} />
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
