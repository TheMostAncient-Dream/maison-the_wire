"use client";

import { useCallback, useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import {
  hasLocalSubscription,
  permissionState,
  pushSupported,
  subscribeToPush,
  unsubscribeFromPush,
} from "@/lib/push-client";
import { useSession } from "./session-provider";
import { SourceNotifyList } from "./source-notify-list";

/**
 * The Notifications section of Settings — the same notifySourceIds store
 * the onboarding flow wrote, editable for life. Also the place to
 * (re)request browser push permission later: granted→on, default→ask,
 * denied→honest instructions instead of a silent failure.
 */

interface NotifyState {
  notifySourceIds: string[];
  onboarded: boolean;
  pushSupported: boolean;
  vapidPublicKey: string | null;
}

export function NotificationsSection() {
  const { user } = useSession();
  const [state, setState] = useState<NotifyState | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [subscribed, setSubscribed] = useState(false);
  const [perm, setPerm] = useState<NotificationPermission | "unsupported">("default");
  const [busy, setBusy] = useState(false);
  const supported = pushSupported();

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("/api/notifications");
        if (!res.ok) throw new Error("unavailable");
        const data = (await res.json()) as NotifyState;
        if (!cancelled) {
          setState(data);
          setSelected(new Set(data.notifySourceIds));
        }
      } catch {
        if (!cancelled) setState(null);
      }
      if (!cancelled) {
        setSubscribed(await hasLocalSubscription());
        setPerm(permissionState());
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [user]);

  /** Toggle a desk — optimistic, reconciled against the server reply. */
  const toggleDesk = useCallback(
    async (id: string) => {
      const next = new Set(selected);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      setSelected(next);
      try {
        const res = await fetch("/api/notifications", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ notifySourceIds: [...next] }),
        });
        if (res.ok) {
          const data = (await res.json()) as NotifyState;
          setSelected(new Set(data.notifySourceIds));
        }
      } catch {
        /* local view stands until the section reloads */
      }
    },
    [selected]
  );

  const enableAlerts = async () => {
    if (busy || !state?.vapidPublicKey) return;
    setBusy(true);
    const result = await subscribeToPush(state.vapidPublicKey);
    if (result.ok) setSubscribed(true);
    if (result.ok === false && result.reason === "denied") setPerm("denied");
    setBusy(false);
  };

  const disableAlerts = async () => {
    if (busy) return;
    setBusy(true);
    await unsubscribeFromPush();
    setSubscribed(false);
    setBusy(false);
  };

  if (!user) {
    return (
      <div className="mt-9 border-t border-charcoal/10 pt-7">
        <h3 className="text-[10px] uppercase tracking-[0.25em] text-warm-grey">Notifications</h3>
        <p className="mt-3 text-sm italic leading-relaxed text-warm-grey">
          Sign in, and the desks you choose can reach you quietly when they break a story.
        </p>
      </div>
    );
  }

  return (
    <div className="mt-9 border-t border-charcoal/10 pt-7">
      <div className="flex items-baseline justify-between">
        <h3 className="text-[10px] uppercase tracking-[0.25em] text-warm-grey">Notifications</h3>
        <span className="text-[10px] italic text-warm-grey/70">applies immediately</span>
      </div>
      <p className="mt-3 text-sm leading-relaxed text-warm-grey">
        A quiet alert when your desks break something — nothing else.
      </p>

      {/* Push permission / subscription state */}
      <div className="mt-4">
        {!supported || (state && !state.pushSupported) ? (
          <p className="text-sm italic leading-relaxed text-warm-grey">
            Quiet alerts aren&rsquo;t available in this browser — the paper itself is unchanged.
          </p>
        ) : subscribed && perm === "granted" ? (
          <div className="flex items-center justify-between gap-4">
            <p className="text-sm text-charcoal">Quiet alerts are on.</p>
            <button
              type="button"
              onClick={disableAlerts}
              disabled={busy}
              className="border-b border-charcoal/15 pb-0.5 text-[11px] uppercase tracking-[0.2em] text-warm-grey transition-colors duration-500 ease-luxe hover:border-gold hover:text-charcoal"
            >
              Turn off
            </button>
          </div>
        ) : perm === "denied" ? (
          <p className="text-sm italic leading-relaxed text-warm-grey">
            Your browser is blocking alerts for this site. Re-enable them in the site settings
            (the bell or lock icon beside the address bar), then return here — no need to ask again.
          </p>
        ) : (
          <div className="flex items-center justify-between gap-4">
            <p className="text-sm text-warm-grey">Quiet alerts are off.</p>
            <button
              type="button"
              onClick={enableAlerts}
              disabled={busy || !state?.vapidPublicKey}
              className="border-b border-charcoal/30 pb-0.5 text-[11px] uppercase tracking-[0.2em] text-charcoal transition-colors duration-500 ease-luxe hover:border-gold disabled:opacity-40"
            >
              {busy ? "Asking…" : "Enable quiet alerts"}
            </button>
          </div>
        )}
      </div>

      {/* The alerting desks — same store onboarding wrote */}
      {state && (
        <div className="mt-6">
          <SourceNotifyList
            selectedIds={selected}
            onToggle={toggleDesk}
            scrollClass="max-h-[32vh]"
          />
          {selected.size === 0 && (
            <p className="mt-3 text-[11px] italic text-warm-grey">
              No desks chosen yet — tick any outlet above.
            </p>
          )}
          <p
            className={cn(
              "mt-3 text-[10px] uppercase tracking-[0.2em]",
              selected.size > 0 ? "text-warm-grey" : "text-warm-grey/60"
            )}
          >
            {selected.size} outlet{selected.size === 1 ? "" : "s"} will alert you
          </p>
        </div>
      )}
    </div>
  );
}
