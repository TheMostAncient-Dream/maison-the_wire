"use client";

import { useState } from "react";
import { ModalShell } from "./modal-shell";

/**
 * Account — two quiet tab-switchable forms (sign in / register) posting
 * to the existing auth APIs. Errors are set inline as quiet gold text;
 * success confirms the session via /api/auth/me through the provider.
 */

type Mode = "signin" | "register";

export function AccountModal({
  onClose,
  onSignedIn,
}: {
  onClose: () => void;
  onSignedIn: () => Promise<void> | void;
}) {
  const [mode, setMode] = useState<Mode>("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const switchMode = (m: Mode) => {
    setMode(m);
    setError(null);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy) return;
    setError(null);

    if (mode === "register") {
      if (password.length < 8) {
        setError("Password must be at least 8 characters.");
        return;
      }
      if (password !== confirm) {
        setError("The passwords don't match.");
        return;
      }
    }

    setBusy(true);
    try {
      const res = await fetch(mode === "signin" ? "/api/auth/login" : "/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(
          mode === "signin" ? { email, password } : { email, password, name: name || undefined }
        ),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) {
        setError(data.error ?? "Something interrupted the press — try again.");
        return;
      }
      await onSignedIn();
    } catch {
      setError("Something interrupted the press — try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <ModalShell label="Maison — Account" onClose={onClose}>
      {/* Mode switch */}
      <div className="flex items-baseline gap-8 border-b border-charcoal/10 pb-5">
        {(["signin", "register"] as Mode[]).map((m) => (
          <button
            key={m}
            type="button"
            onClick={() => switchMode(m)}
            aria-pressed={mode === m}
            className={`border-b pb-1.5 text-[11px] uppercase tracking-[0.25em] transition-colors duration-500 ease-luxe ${
              mode === m
                ? "border-gold text-charcoal"
                : "border-transparent text-warm-grey hover:text-charcoal"
            }`}
          >
            {m === "signin" ? "Sign in" : "Register"}
          </button>
        ))}
      </div>

      <h2 className="mt-7 font-serif text-3xl leading-tight text-charcoal">
        {mode === "signin" ? "Return to your desk." : "Take a seat at the desk."}
      </h2>
      <p className="mt-3 text-sm leading-relaxed text-warm-grey">
        {mode === "signin"
          ? "Your saved dispatches, columns and preferences are exactly where you left them."
          : "A free subscription keeps your saved stories and column layout across every device."}
      </p>

      <form onSubmit={submit} className="mt-8 space-y-6">
        {mode === "register" && (
          <Field label="Name — optional">
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              autoComplete="name"
              placeholder="Evelyn Waugh"
              className="h-12 w-full border-b border-charcoal/30 bg-transparent font-serif text-base text-charcoal placeholder:text-warm-grey/40 focus:border-gold focus:outline-none transition-colors duration-500 ease-luxe"
            />
          </Field>
        )}

        <Field label="Email">
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="email"
            placeholder="you@example.com"
            className="h-12 w-full border-b border-charcoal/30 bg-transparent font-serif text-base text-charcoal placeholder:text-warm-grey/40 focus:border-gold focus:outline-none transition-colors duration-500 ease-luxe"
          />
        </Field>

        <Field label="Password">
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete={mode === "signin" ? "current-password" : "new-password"}
            placeholder="••••••••"
            className="h-12 w-full border-b border-charcoal/30 bg-transparent font-serif text-base text-charcoal placeholder:text-warm-grey/40 focus:border-gold focus:outline-none transition-colors duration-500 ease-luxe"
          />
        </Field>

        {mode === "register" && (
          <Field label="Confirm password">
            <input
              type="password"
              required
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              autoComplete="new-password"
              placeholder="••••••••"
              className="h-12 w-full border-b border-charcoal/30 bg-transparent font-serif text-base text-charcoal placeholder:text-warm-grey/40 focus:border-gold focus:outline-none transition-colors duration-500 ease-luxe"
            />
          </Field>
        )}

        {error && (
          <p role="alert" className="text-xs italic leading-relaxed text-gold-ink">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={busy}
          className="group relative h-12 w-full overflow-hidden bg-charcoal text-xs font-medium uppercase tracking-[0.25em] text-alabaster transition-all duration-500 ease-luxe hover:shadow-[0_8px_24px_rgba(0,0,0,0.25)] disabled:pointer-events-none disabled:opacity-50 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-charcoal focus-visible:ring-offset-2 focus-visible:ring-offset-alabaster"
        >
          <span
            aria-hidden
            className="absolute inset-0 -translate-x-[101%] bg-gold transition-transform duration-500 ease-luxe group-hover:translate-x-0"
          />
          <span className="relative z-10">
            {busy
              ? "Setting type…"
              : mode === "signin"
                ? "Sign in"
                : "Create the subscription"}
          </span>
        </button>
      </form>
    </ModalShell>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-[10px] uppercase tracking-[0.25em] text-warm-grey">{label}</span>
      {children}
    </label>
  );
}
