"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Check } from "lucide-react";
import { useSession } from "./session-provider";
import { cn } from "@/lib/utils";

/**
 * The Verify screen — the reader proves the address with the six-digit
 * code the post delivered. Full-viewport paper, same DNA as the New
 * Reader sequence: it stands in front of onboarding for fresh
 * registrations and can be summoned later from Settings.
 *
 * The clock is the point: the code dies in minutes (ticking mm:ss), and
 * another may be sent only after the cooldown counts down. The post is
 * honest about its transport — until a mail desk is attached, the letter
 * is set into the server log, and in dev the code shows here as the
 * "demo post".
 */

interface Status {
  verified: boolean;
  expiresAt: number | null;
  resendAfter: number;
  devCode?: string;
}

function fmt(ms: number): string {
  const s = Math.max(0, Math.ceil(ms / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

export function VerifyEmailFlow({
  onComplete,
  onSkip,
}: {
  onComplete: () => Promise<void> | void;
  onSkip: () => void;
}) {
  const { user } = useSession();
  const [status, setStatus] = useState<Status | null>(null);
  const [code, setCode] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [verified, setVerified] = useState(false);
  const [now, setNow] = useState(() => Date.now());
  const inputRef = useRef<HTMLInputElement>(null);
  const doneRef = useRef(false);
  const turnRef = useRef<number | null>(null);

  /* The turn of the paper gets read before the next page arrives. */
  useEffect(
    () => () => {
      if (turnRef.current) window.clearTimeout(turnRef.current);
    },
    []
  );

  const succeed = useCallback(() => {
    if (doneRef.current) return;
    doneRef.current = true;
    setVerified(true);
    turnRef.current = window.setTimeout(() => void onComplete(), 2400);
  }, [onComplete]);

  /* The clock — one interval drives the expiry and cooldown tickers. */
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(t);
  }, []);

  /* Status on mount; an address proven elsewhere closes the screen. */
  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/auth/verification");
        if (!res.ok) return;
        const data = (await res.json()) as Status;
        if (data.verified) {
          succeed();
          return;
        }
        setStatus(data);
        if (!data.expiresAt || data.expiresAt <= Date.now()) {
          // nothing pending or already dead — put the cursor in the resend
        } else {
          inputRef.current?.focus();
        }
      } catch {
        /* status stays null — the buttons still render */
      }
    })();
  }, []);

  const pending = status?.expiresAt != null && status.expiresAt > now;
  const resendReady = !!status && now >= status.resendAfter && status.resendAfter > 0;
  const neverSent = !!status && status.resendAfter === 0 && !pending;

  const verify = useCallback(
    async (e?: React.FormEvent) => {
      e?.preventDefault();
      if (busy || code.trim().length !== 6) return;
      setBusy(true);
      setError(null);
      try {
        const res = await fetch("/api/auth/verify", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ code: code.trim() }),
        });
        const data = (await res.json().catch(() => ({}))) as { ok?: boolean; error?: string };
        if (res.ok && data.ok) {
          succeed();
          return;
        }
        setError(data.error ?? "Something interrupted the post — try again.");
      } catch {
        setError("Something interrupted the post — try again.");
      } finally {
        setBusy(false);
      }
    },
    [busy, code, onComplete]
  );

  const resend = useCallback(async () => {
    if (busy || !resendReady && !neverSent) return;
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/auth/resend", { method: "POST" });
      const data = (await res.json().catch(() => ({}))) as Status & {
        ok?: boolean;
        error?: string;
        retryAfterMs?: number;
      };
      if (res.ok && data.ok) {
        setStatus({
          verified: false,
          expiresAt: data.expiresAt ?? null,
          resendAfter: data.resendAfter ?? 0,
          devCode: data.devCode,
        });
        setCode("");
        inputRef.current?.focus();
      } else if (res.status === 429 && data.retryAfterMs) {
        const wait = data.retryAfterMs;
        setStatus((s) => (s ? { ...s, resendAfter: Date.now() + wait } : s));
        setError(data.error ?? null);
      } else {
        setError(data.error ?? "The post refused the letter — try again.");
      }
    } catch {
      setError("The post refused the letter — try again.");
    } finally {
      setBusy(false);
    }
  }, [busy, resendReady, neverSent]);

  /* —— success turn of the paper —— */
  if (verified) {
    return (
      <div
        className="fixed inset-0 z-[80] overflow-y-auto bg-alabaster text-charcoal luxe-scroll"
        role="dialog"
        aria-modal="true"
        aria-label="Address verified"
      >
        <div className="mx-auto max-w-2xl px-6 pb-24 pt-16 md:px-8 md:pt-24">
          <p className="text-[10px] uppercase tracking-[0.3em] text-gold-ink">The post</p>
          <div className="overlay-in">
            <h1 className="mt-6 font-serif text-5xl leading-[1.02] md:text-6xl">
              The address is
              <br />
              <em className="italic">yours.</em>
            </h1>
            <p className="mt-6 flex items-baseline gap-3 text-sm leading-relaxed text-warm-grey">
              <Check className="h-4 w-4 shrink-0 self-center text-gold-ink" strokeWidth={2} aria-hidden />
              {user?.email} now speaks for this subscription — desk alerts can find you.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className="fixed inset-0 z-[80] overflow-y-auto bg-alabaster text-charcoal luxe-scroll"
      role="dialog"
      aria-modal="true"
      aria-label="Verify your email address"
    >
      {/* Masthead strip */}
      <div className="border-b border-charcoal/10">
        <div className="mx-auto flex max-w-2xl items-center justify-between px-6 py-5 md:px-8">
          <span className="text-[10px] uppercase tracking-[0.35em] text-warm-grey">
            Maison — the post
          </span>
          <button
            type="button"
            onClick={onSkip}
            className="border-b border-charcoal/15 pb-0.5 text-[10px] uppercase tracking-[0.25em] text-warm-grey transition-colors duration-500 ease-luxe hover:border-gold hover:text-charcoal"
          >
            I&rsquo;ll verify later
          </button>
        </div>
      </div>

      <div className="mx-auto max-w-2xl px-6 pb-24 pt-10 md:px-8 md:pt-16">
        <p className="text-[10px] uppercase tracking-[0.3em] text-gold-ink">
          One code — fifteen minutes
        </p>
        <div className="overlay-in">
          <h1 className="mt-6 font-serif text-5xl leading-[1.02] md:text-6xl">
            A letter is on
            <br />
            its way to <em className="italic">your post.</em>
          </h1>
          <p className="mt-5 max-w-md text-sm leading-relaxed text-warm-grey">
            Six digits are on their way to <span className="text-charcoal">{user?.email}</span>.
            Enter them before the code expires and the address is yours for good.
          </p>

          {/* The demo post — honest about the transport until a mail desk exists */}
          {status?.devCode && pending && (
            <div className="mt-8 border border-gold/40 bg-gold/5 px-5 py-4">
              <p className="text-[10px] uppercase tracking-[0.25em] text-gold-ink">Demo post</p>
              <p className="mt-1.5 text-xs leading-relaxed text-warm-grey">
                No mail desk is attached to this press yet — the letter is set into the
                server log, and shown here in dev:
              </p>
              <p className="mt-2 font-serif text-3xl tracking-[0.45em] text-charcoal">
                {status.devCode}
              </p>
            </div>
          )}

          <form onSubmit={verify} className="mt-10">
            <label htmlFor="verify-code" className="text-[10px] uppercase tracking-[0.25em] text-warm-grey">
              The six digits
            </label>
            <input
              id="verify-code"
              ref={inputRef}
              type="text"
              inputMode="numeric"
              autoComplete="one-time-code"
              maxLength={6}
              value={code}
              onChange={(e) => {
                setCode(e.target.value.replace(/\D/g, "").slice(0, 6));
                setError(null);
              }}
              placeholder="······"
              disabled={!pending || busy}
              className="mt-3 block h-16 w-full max-w-xs border-b-2 border-charcoal/30 bg-transparent text-center font-serif text-3xl tracking-[0.6em] text-charcoal placeholder:text-warm-grey/30 focus:border-gold focus:outline-none transition-colors duration-500 ease-luxe disabled:opacity-40"
            />

            {/* The clock */}
            <div className="mt-4 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-warm-grey">
              {status?.expiresAt != null && (
                <span
                  className={cn(
                    "tabular-nums",
                    pending ? "text-warm-grey" : "text-gold-ink"
                  )}
                >
                  {pending
                    ? `The code expires in ${fmt(status.expiresAt - now)}`
                    : "The code has expired."}
                </span>
              )}
              <button
                type="button"
                onClick={resend}
                disabled={busy || (!resendReady && !neverSent)}
                className="border-b border-charcoal/15 pb-0.5 uppercase tracking-[0.2em] transition-colors duration-500 ease-luxe hover:border-gold hover:text-charcoal disabled:pointer-events-none disabled:opacity-40"
              >
                {neverSent
                  ? "Send the code"
                  : resendReady
                    ? "Send another code"
                    : status && status.resendAfter > now
                      ? `Send another in ${fmt(status.resendAfter - now)}`
                      : "Send another code"}
              </button>
            </div>

            {error && (
              <p role="alert" className="mt-5 text-xs italic leading-relaxed text-gold-ink">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={busy || code.length !== 6 || !pending}
              className="group relative mt-10 h-12 overflow-hidden bg-charcoal px-10 text-xs font-medium uppercase tracking-[0.25em] text-alabaster transition-all duration-500 ease-luxe hover:shadow-[0_8px_24px_rgba(0,0,0,0.25)] disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-charcoal"
            >
              <span
                aria-hidden
                className="absolute inset-0 -translate-x-[101%] bg-gold transition-transform duration-500 ease-luxe group-hover:translate-x-0"
              />
              <span className="relative z-10">{busy ? "Checking…" : "Prove the address"}</span>
            </button>
            <p className="mt-4 text-[11px] italic text-warm-grey">
              Skipped for now? Desk alerts wait on a verified address — everything else
              works, and Settings keeps a door to this page.
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}
