"use client";

import { useEffect } from "react";

/**
 * Every third editorial rule breaks formation — and how it breaks is
 * fully random, re-drawn on every load. The engine walks all [data-rule]
 * elements in document order once after hydration, then watches the DOM
 * for rules that mount later (Load More, saved shelves, source rows).
 *
 * Bends — the rule's straight run is redrawn as a curve, one of four,
 * parameters drawn fresh each time. The curve is an SVG path overlaid on
 * the rule's exact geometry, so hairlines bend as hairlines and the 4px
 * gold lead rule bends as a brush stroke:
 *   bow    a single arc, apex off-centre, up or down
 *   s      a cubic S-curve, two opposing swells
 *   wave   a double swell, mirrored around a random midpoint
 *   flick  a straight run that swishes up or down near one end
 *
 * Applied imperatively after paint (never during render), so SSR markup
 * stays clean and React never fights the mutation.
 */
export function RuleRandomizer() {
  useEffect(() => {
    let counted = 0;
    let queued = false;

    const rand = (min: number, max: number) => min + Math.random() * (max - min);
    const pick = <T,>(arr: readonly T[]): T =>
      arr[Math.floor(Math.random() * arr.length)];
    const coin = (p: number) => Math.random() < p;

    const SVG_NS = "http://www.w3.org/2000/svg";
    const BENDS = ["bow", "s", "wave", "flick"] as const;

    /* viewBox is 0 0 100 12; the rule's straight run lives at y = 6. */
    function bendPath(kind: (typeof BENDS)[number], amp: number) {
      const up = coin(0.5) ? -1 : 1;
      const y = (6 + up * amp).toFixed(2);
      switch (kind) {
        case "bow":
          return `M 0 6 Q ${rand(28, 72).toFixed(2)} ${y} 100 6`;
        case "s":
          return `M 0 6 C ${rand(18, 40).toFixed(2)} ${y} ${rand(60, 82).toFixed(2)} ${(6 - up * amp).toFixed(2)} 100 6`;
        case "wave": {
          const mid = rand(40, 60);
          return `M 0 6 Q ${(mid / 2).toFixed(2)} ${y} ${mid.toFixed(2)} 6 T 100 6`;
        }
        case "flick": {
          const at = rand(58, 78);
          return `M 0 6 L ${at.toFixed(2)} 6 Q ${((at + 100) / 2).toFixed(2)} 6 100 ${(6 + up * amp * 1.4).toFixed(2)}`;
        }
      }
    }

    function applyFate(el: HTMLElement) {
      const color = getComputedStyle(el).backgroundColor;
      if (!color || color === "transparent" || color.includes("rgba(0, 0, 0, 0)")) {
        return; /* nothing to bend with — leave the rule straight */
      }
      const box = el.getBoundingClientRect();
      if (box.width < 80) return; /* too short to bend gracefully */
      const amp = rand(2.5, 5.5) * (box.width < 250 ? 0.6 : 1);

      el.style.position = "relative";
      el.style.backgroundColor = "transparent";

      const svg = document.createElementNS(SVG_NS, "svg");
      svg.setAttribute("viewBox", "0 0 100 12");
      svg.setAttribute("preserveAspectRatio", "none");
      svg.setAttribute("aria-hidden", "true");
      svg.style.cssText = `position:absolute;left:0;top:${(-(12 - box.height) / 2).toFixed(2)}px;width:100%;height:12px;overflow:visible;pointer-events:none`;

      const path = document.createElementNS(SVG_NS, "path");
      path.setAttribute("d", bendPath(pick(BENDS), amp));
      path.setAttribute("fill", "none");
      path.setAttribute("vector-effect", "non-scaling-stroke");
      path.style.stroke = color;
      path.style.strokeWidth = `${box.height}px`;

      /* The bend fades in, like type being locked into the chase.
         (A stroke-dasharray draw-in breaks under non-scaling-stroke —
         Chromium dashes scaled paths unreliably — so: opacity.) */
      const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
      if (!reduce) {
        svg.style.opacity = "0";
        svg.style.transition = "opacity 1100ms cubic-bezier(0.25, 0.46, 0.45, 0.94)";
      }
      svg.appendChild(path);
      el.appendChild(svg);

      if (!reduce) {
        requestAnimationFrame(() =>
          requestAnimationFrame(() => {
            svg.style.opacity = "1";
          })
        );
      }
    }

    function scan() {
      const nodes = document.querySelectorAll<HTMLElement>(
        '[data-rule]:not([data-rule-fated])'
      );
      nodes.forEach((el) => {
        /* Only rules that are actually laid out join the count. */
        if (el.getClientRects().length === 0) return;
        counted += 1;
        el.setAttribute("data-rule-fated", "");
        if (counted % 3 === 0) applyFate(el);
      });
    }

    function schedule() {
      if (queued) return;
      queued = true;
      requestAnimationFrame(() => {
        queued = false;
        scan();
      });
    }

    scan();
    const mo = new MutationObserver(schedule);
    mo.observe(document.documentElement, { childList: true, subtree: true });

    return () => mo.disconnect();
  }, []);

  return null;
}
