"use client";

import { useCallback, useEffect, useState } from "react";
import { RefreshCw } from "lucide-react";
import { Overline } from "@/components/luxe/atoms";
import { Rule } from "@/components/luxe/rule";
import { useSession } from "@/components/luxe/session/session-provider";
import { timeAgo } from "@/components/luxe/feed/utils";
import type { TopicDTO } from "@/lib/types";
import { cn } from "@/lib/utils";

/**
 * Admin Console — a plain back-office bench behind #admin, gated on the
 * session's role. The section does not exist for the public at all: it
 * renders nothing until the session resolves to an administrator, so
 * readers never see (or scroll past) the press room. Inside, sources
 * can be silenced or re-fetched by hand, the week's ingestion is
 * charted, the topic taxonomy and the readership are listed.
 * Deliberately dense; the editorial ink is left at the door.
 */

interface AdminSource {
  id: string;
  slug: string;
  name: string;
  type: string;
  country: string | null;
  language: string;
  isActive: boolean;
  healthStatus: string;
  lastFetchedAt: string | null;
  lastSuccessAt: string | null;
  lastError: string | null;
  consecutiveFailures: number;
  itemsCount: number;
}

interface AdminStats {
  totalItems: number;
  items24h: number;
  users: number;
  bookmarks: number;
  itemsIngested7d: number;
  perDay: { date: string; count: number }[];
  topTopics: { slug: string; count: number }[];
  ingesting: boolean;
  lastRunAt: string | null;
}

interface AdminUser {
  id: string;
  email: string;
  name: string | null;
  role: string;
  createdAt: string;
  bookmarks: number;
}

interface AdminAuditEntry {
  id: string;
  actor: string;
  action: string;
  targetId: string | null;
  detail: string | null;
  createdAt: string;
}

export function AdminConsole() {
  const { user, ready } = useSession();
  const [sources, setSources] = useState<AdminSource[]>([]);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [topics, setTopics] = useState<TopicDTO[]>([]);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [audit, setAudit] = useState<AdminAuditEntry[]>([]);
  const [state, setState] = useState<"idle" | "loading" | "denied" | "error">("idle");
  const [refetching, setRefetching] = useState<string | null>(null);
  const [note, setNote] = useState<string | null>(null);

  const isAdmin = user?.role === "admin";

  const load = useCallback(async () => {
    if (!isAdmin) return;
    setState("loading");
    try {
      const [s, st, t, u, a] = await Promise.all([
        fetch("/api/admin/sources").then((r) => (r.ok ? r.json() : Promise.reject())),
        fetch("/api/admin/stats").then((r) => (r.ok ? r.json() : Promise.reject())),
        fetch("/api/admin/topics").then((r) => (r.ok ? r.json() : Promise.reject())),
        fetch("/api/admin/users").then((r) => (r.ok ? r.json() : Promise.reject())),
        fetch("/api/admin/audit").then((r) => (r.ok ? r.json() : Promise.reject())),
      ]);
      setSources(s as AdminSource[]);
      setStats(st as AdminStats);
      setTopics(t as TopicDTO[]);
      setUsers(u as AdminUser[]);
      setAudit(a as AdminAuditEntry[]);
      setState("idle");
    } catch {
      setState("error");
    }
  }, [isAdmin]);

  useEffect(() => {
    if (!ready || !isAdmin) return;
    let cancelled = false;
    queueMicrotask(() => {
      if (!cancelled) void load();
    });
    return () => {
      cancelled = true;
    };
  }, [ready, isAdmin, load]);

  const toggleActive = async (src: AdminSource) => {
    setNote(null);
    await fetch("/api/admin/sources", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: src.id, isActive: !src.isActive }),
    });
    setSources((prev) =>
      prev.map((s) => (s.id === src.id ? { ...s, isActive: !s.isActive } : s))
    );
  };

  const refetch = async (src: AdminSource) => {
    setRefetching(src.id);
    setNote(null);
    try {
      const res = await fetch("/api/admin/ingest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sourceId: src.id }),
      });
      const data = (await res.json()) as { ingested?: number; newItems?: number; error?: string };
      setNote(
        res.ok
          ? `${src.name}: ${data.ingested ?? 0} fetched, ${data.newItems ?? 0} new.`
          : (data.error ?? "Refetch failed.")
      );
      await load();
    } catch {
      setNote("Refetch failed.");
    } finally {
      setRefetching(null);
    }
  };

  /* The press room stays invisible until an administrator is holding
     the keys — no locked-door notice, no Editors-only placard, no
     section in the page at all. */
  if (!ready || !user || !isAdmin) {
    return null;
  }

  return (
    <SectionShell>
      {state === "loading" ? (
        <p className="py-16 text-sm text-warm-grey">Pulling the ledgers…</p>
      ) : state === "error" ? (
        <div className="py-16 text-center">
          <p className="font-serif text-3xl italic text-charcoal">The ledgers won&apos;t open.</p>
          <button
            type="button"
            onClick={() => void load()}
            className="mt-6 text-xs uppercase tracking-[0.25em] text-warm-grey underline-offset-8 hover:text-gold-ink hover:underline"
          >
            Try again
          </button>
        </div>
      ) : (
        <div className="space-y-14">
          {/* Stats */}
          <div className="grid grid-cols-2 gap-px bg-charcoal/10 md:grid-cols-5">
            <Stat label="Items" value={stats?.totalItems} />
            <Stat label="24 hours" value={stats?.items24h} />
            <Stat label="7-day intake" value={stats?.itemsIngested7d} />
            <Stat label="Readers" value={stats?.users} />
            <Stat label="Bookmarks" value={stats?.bookmarks} />
          </div>

          {/* 7-day ingestion sparkline */}
          <div>
            <h3 className="text-[10px] uppercase tracking-[0.3em] text-warm-grey">
              Ingestion — last 7 days
            </h3>
            <div className="mt-4 flex items-end gap-2" aria-hidden>
              {(stats?.perDay ?? []).map((d) => {
                const max = Math.max(...(stats?.perDay ?? [{ count: 1 }]).map((x) => x.count), 1);
                return (
                  <div key={d.date} className="flex flex-1 flex-col items-center gap-2">
                    <span className="text-[10px] tabular-nums text-warm-grey">{d.count.toLocaleString("en-US")}</span>
                    <div
                      className="w-full max-w-14 bg-gold/80"
                      style={{ height: `${Math.max(4, (d.count / max) * 96)}px` }}
                    />
                    <span className="text-[9px] uppercase tracking-wider text-warm-grey/60">
                      {d.date.slice(5)}
                    </span>
                  </div>
                );
              })}
              {(stats?.perDay?.length ?? 0) === 0 && (
                <p className="text-sm italic text-warm-grey">No intake recorded this week.</p>
              )}
            </div>
          </div>

          {/* Sources table */}
          <div>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h3 className="text-[10px] uppercase tracking-[0.3em] text-warm-grey">
                Source registry — {sources.length}
              </h3>
              {note && <p className="text-xs italic text-gold-ink">{note}</p>}
            </div>
            <div className="mt-4 overflow-x-auto">
              <table className="w-full min-w-[720px] text-left text-xs">
                <thead>
                  <tr className="border-b border-charcoal/15 bg-taupe/40 text-[9px] uppercase tracking-[0.2em] text-warm-grey">
                    <th className="px-4 py-3 font-medium">Source</th>
                    <th className="px-4 py-3 font-medium">Type</th>
                    <th className="px-4 py-3 font-medium">Health</th>
                    <th className="px-4 py-3 font-medium">Items</th>
                    <th className="px-4 py-3 font-medium">Last success</th>
                    <th className="px-4 py-3 font-medium">Active</th>
                    <th className="px-4 py-3 font-medium text-right">Refetch</th>
                  </tr>
                </thead>
                <tbody>
                  {sources.map((s) => (
                    <tr key={s.id} className="border-b border-charcoal/10 last:border-b-0 hover:bg-taupe/25">
                      <td className="max-w-56 truncate px-4 py-2.5 font-medium text-charcoal">
                        <span title={s.lastError ?? undefined} className={cn(s.lastError && "cursor-help")}>
                          {s.name}
                        </span>
                      </td>
                      <td className="px-4 py-2.5 uppercase text-warm-grey">{s.type}</td>
                      <td className="px-4 py-2.5">
                        <span
                          className={cn(
                            "uppercase tracking-wider",
                            s.healthStatus === "error" && "text-gold-ink",
                            s.healthStatus === "degraded" && "text-gold-ink",
                            s.healthStatus === "healthy" && "text-warm-grey"
                          )}
                        >
                          {s.consecutiveFailures > 0 ? `${s.healthStatus} (×${s.consecutiveFailures})` : s.healthStatus}
                        </span>
                      </td>
                      <td className="px-4 py-2.5 tabular-nums text-warm-grey">{s.itemsCount.toLocaleString("en-US")}</td>
                      <td className="px-4 py-2.5 text-warm-grey">
                        {s.lastSuccessAt ? timeAgo(s.lastSuccessAt) : "—"}
                      </td>
                      <td className="px-4 py-2.5">
                        <button
                          type="button"
                          role="switch"
                          aria-checked={s.isActive}
                          aria-label={`${s.isActive ? "Disable" : "Enable"} ${s.name}`}
                          onClick={() => void toggleActive(s)}
                          className={cn(
                            "relative h-5 w-10 border transition-colors duration-500 ease-luxe",
                            s.isActive ? "border-gold bg-gold/20" : "border-charcoal/30 bg-transparent"
                          )}
                        >
                          <span
                            className={cn(
                              "absolute top-1/2 h-3 w-3 -translate-y-1/2 transition-all duration-500 ease-luxe",
                              s.isActive ? "left-[22px] bg-gold" : "left-[3px] bg-charcoal/40"
                            )}
                          />
                        </button>
                      </td>
                      <td className="px-4 py-2.5 text-right">
                        <button
                          type="button"
                          onClick={() => void refetch(s)}
                          disabled={refetching !== null}
                          className="inline-flex items-center gap-1.5 px-2 py-1 uppercase tracking-wider text-warm-grey transition-colors duration-500 ease-luxe hover:text-gold-ink disabled:opacity-40"
                        >
                          <RefreshCw
                            className={cn("h-3 w-3", refetching === s.id && "animate-spin")}
                            strokeWidth={1.5}
                            aria-hidden
                          />
                          {refetching === s.id ? "Fetching…" : "Now"}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Topics + users */}
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-2">
            <div>
              <h3 className="text-[10px] uppercase tracking-[0.3em] text-warm-grey">
                Topic taxonomy — {topics.length}
              </h3>
              <ul className="mt-4 divide-y divide-charcoal/10 text-xs">
                {topics.map((t) => (
                  <li key={t.id} className="flex items-center justify-between gap-4 px-4 py-2.5">
                    <span className="font-medium text-charcoal">{t.name}</span>
                    <span className="text-warm-grey">
                      {t.slug} · #{t.sortOrder}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-[10px] uppercase tracking-[0.3em] text-warm-grey">
                Readers — {users.length}
              </h3>
              <ul className="mt-4 divide-y divide-charcoal/10 text-xs">
                {users.map((u) => (
                  <li key={u.id} className="flex items-center justify-between gap-4 px-4 py-2.5">
                    <span className="min-w-0">
                      <span className="block truncate font-medium text-charcoal">{u.email}</span>
                      <span className="text-warm-grey">
                        {u.role} · joined {timeAgo(u.createdAt)}
                      </span>
                    </span>
                    <span className="shrink-0 tabular-nums text-warm-grey">
                      {u.bookmarks} saved
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Audit trail — who did what, most recent first */}
          <div>
            <h3 className="text-[10px] uppercase tracking-[0.3em] text-warm-grey">
              Audit trail — last {audit.length} actions
            </h3>
            <div className="mt-4 overflow-x-auto">
              <table className="w-full min-w-[640px] text-left text-xs">
                <thead>
                  <tr className="border-b border-charcoal/15 bg-taupe/40 text-[9px] uppercase tracking-[0.2em] text-warm-grey">
                    <th className="px-4 py-2.5 font-medium">When</th>
                    <th className="px-4 py-2.5 font-medium">Editor</th>
                    <th className="px-4 py-2.5 font-medium">Action</th>
                    <th className="px-4 py-2.5 font-medium">Detail</th>
                  </tr>
                </thead>
                <tbody>
                  {audit.map((e) => (
                    <tr key={e.id} className="border-b border-charcoal/10 last:border-b-0 hover:bg-taupe/25">
                      <td className="whitespace-nowrap px-4 py-2 tabular-nums text-warm-grey">
                        {new Date(e.createdAt).toLocaleString("en-GB", {
                          day: "2-digit",
                          month: "short",
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </td>
                      <td className="whitespace-nowrap px-4 py-2 text-warm-grey">{e.actor}</td>
                      <td className="whitespace-nowrap px-4 py-2 uppercase tracking-wider text-charcoal">
                        {e.action}
                      </td>
                      <td className="max-w-96 truncate px-4 py-2 text-warm-grey" title={e.detail ?? undefined}>
                        {e.detail ?? "—"}
                      </td>
                    </tr>
                  ))}
                  {audit.length === 0 && (
                    <tr>
                      <td colSpan={4} className="px-4 py-3 text-sm italic text-warm-grey">
                        Nothing recorded yet — the ledger fills as the editors work.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </SectionShell>
  );
}

function SectionShell({ children }: { children: React.ReactNode }) {
  return (
    <section id="admin" className="relative scroll-mt-24 bg-taupe/30 py-24 md:py-32">
      <div className="mx-auto max-w-[1600px] px-8 md:px-16">
        <Overline>Press Room</Overline>
        <h2 className="mt-6 font-serif text-4xl leading-[0.95] text-charcoal md:text-6xl">
          Admin console.
        </h2>
        <Rule className="mt-12 h-px bg-charcoal/15" />
        <div className="pt-10">{children}</div>
      </div>
    </section>
  );
}

function Stat({ label, value }: { label: string; value: number | undefined }) {
  return (
    <div className="bg-alabaster px-5 py-6">
      <p className="text-[9px] uppercase tracking-[0.25em] text-warm-grey">{label}</p>
      <p className="mt-2 font-serif text-3xl tabular-nums text-charcoal">
        {value === undefined ? "—" : value.toLocaleString("en-US")}
      </p>
    </div>
  );
}
