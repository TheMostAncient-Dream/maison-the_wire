import { Em, Overline } from "@/components/luxe/atoms";
import { Reveal } from "@/components/luxe/reveal";
import { Rule } from "@/components/luxe/rule";
import { getFeatured } from "@/lib/server/content";
import type { StoryClusterDTO } from "@/lib/types";
import { Play } from "lucide-react";
import { ItemTrigger } from "@/components/luxe/feed/news-modal";
import { SmartThumb } from "@/components/luxe/feed/smart-thumb";
import { timeAgo, uniqueSources } from "@/components/luxe/feed/utils";

/**
 * The front page — server-rendered lead story (top trending cluster),
 * two secondary clusters, and the latest dispatches list.
 */
export async function FrontPage() {
  let featured: StoryClusterDTO[] = [];
  let latest: Awaited<ReturnType<typeof getFeatured>>["latest"] = [];
  try {
    const res = await getFeatured(3);
    featured = res.featured;
    latest = res.latest;
  } catch {
    /* Empty state below handles the rest. */
  }

  const lead = featured[0];
  const leadItem = lead?.items[0];
  const secondary = featured.slice(1, 3);

  return (
    <section id="front-page" className="scroll-mt-24 py-20 md:py-28">
      <div className="mx-auto max-w-[1600px] px-8 md:px-16">
        <Reveal>
          <div className="flex items-end justify-between gap-6">
            <div>
              {/* Kicker hangs into the margin; the italic line steps right —
                  the left edge stops being one straight wall. */}
              <Overline className="-ml-3 md:-ml-5">Front Page</Overline>
              <h2 className="mt-6 font-serif text-4xl leading-[0.95] text-charcoal md:text-6xl">
                Today&rsquo;s
                <br />
                <span className="inline-block pl-[0.5em]">
                  <Em>essentials.</Em>
                </span>
              </h2>
            </div>
            <span className="hidden pb-1 text-[10px] uppercase tracking-[0.3em] text-warm-grey md:block">
              Clustered by story
            </span>
          </div>
          <Rule className="mt-8 h-px bg-charcoal/15" />
        </Reveal>

        {lead && leadItem && (
          <Reveal>
            {/* The lead rule runs ahead of the story — every so often,
                it refuses to run straight. */}
            <Rule className="mt-14 h-1 bg-gold" />
            <article className="group grid grid-cols-12 gap-y-10 pt-10 lg:gap-x-12">
              <ItemTrigger
                item={leadItem}
                ariaLabel={`Details: ${lead.title}`}
                className="col-span-12 block w-full overflow-hidden text-left lg:col-span-7"
              >
                <div className="relative aspect-[16/10] overflow-hidden bg-taupe shadow-[0_8px_32px_rgba(0,0,0,0.12)] transition-shadow duration-700 ease-luxe group-hover:shadow-[0_12px_40px_rgba(0,0,0,0.16)]">
                  {leadItem.thumbnailUrl && (
                    <SmartThumb
                      src={leadItem.thumbnailUrl}
                      loading="eager"
                      fetchPriority="high"
                      className="h-full w-full object-cover grayscale transition-all duration-[1600ms] ease-luxe group-hover:scale-[1.04] group-hover:grayscale-0"
                    />
                  )}
                  {leadItem.type === "video" && (
                    <span className="absolute bottom-4 left-4 inline-flex items-center gap-2 bg-charcoal/85 px-3 py-1.5 text-[10px] uppercase tracking-[0.2em] text-alabaster">
                      <Play className="h-3 w-3" strokeWidth={1.5} aria-hidden />
                      Film
                    </span>
                  )}
                </div>
              </ItemTrigger>

              <div className="col-span-12 flex flex-col justify-center lg:col-span-5">
                <span className="text-[10px] font-medium uppercase tracking-[0.25em] text-warm-grey transition-colors duration-500 ease-luxe group-hover:text-gold-ink">
                  {uniqueSources(lead.items)}
                  {lead.items.length > 1 && ` — ${lead.items.length} reports`}
                </span>
                <h3 className="mt-5 font-serif text-3xl leading-[1.05] text-charcoal md:text-5xl">
                  <ItemTrigger
                    item={leadItem}
                    className="text-left transition-colors duration-500 ease-luxe hover:text-gold-ink"
                  >
                    {lead.title}
                  </ItemTrigger>
                </h3>
                {leadItem.snippet && (
                  <p className="mt-6 line-clamp-4 max-w-md text-base leading-relaxed text-warm-grey">
                    {leadItem.snippet}
                  </p>
                )}
                <div className="mt-8 flex items-center gap-5 text-[10px] uppercase tracking-[0.25em] text-warm-grey/70">
                  <span>{leadItem.type === "video" ? "Film" : "Article"}</span>
                  <span aria-hidden className="h-px w-8 bg-gold" />
                  <time dateTime={lead.publishedAt}>{timeAgo(lead.publishedAt)}</time>
                </div>
              </div>
            </article>
          </Reveal>
        )}

        {secondary.length > 0 && (
          <div className="mt-16 grid grid-cols-1 gap-x-8 gap-y-16 md:grid-cols-2">
            {secondary.map((c, i) => {
              const rep = c.items[0];
              return (
                <Reveal key={c.id}>
                  {/* The pair hangs at different heights — no shared baseline */}
                  <Rule className="h-px bg-charcoal/60" />
                  <article
                    className={`group pt-8 transition-colors duration-700 ease-luxe hover:bg-taupe/25 ${
                      i === 1 ? "md:mt-16" : ""
                    }`}
                  >
                    {rep.thumbnailUrl && (
                      <ItemTrigger
                        item={rep}
                        ariaLabel={`Details: ${c.title}`}
                        className="block w-full overflow-hidden text-left"
                      >
                        <div className="relative aspect-[3/2] overflow-hidden bg-taupe shadow-[0_2px_8px_rgba(0,0,0,0.02)] transition-shadow duration-700 ease-luxe group-hover:shadow-[0_8px_24px_rgba(0,0,0,0.06)]">
                          <SmartThumb
                            src={rep.thumbnailUrl ?? ""}
                            className="h-full w-full object-cover grayscale transition-all duration-[1600ms] ease-luxe group-hover:scale-[1.04] group-hover:grayscale-0"
                          />
                        </div>
                      </ItemTrigger>
                    )}
                    <div className="mt-6 flex items-baseline justify-between gap-4">
                      <span className="text-[10px] font-medium uppercase tracking-[0.25em] text-warm-grey transition-colors duration-500 ease-luxe group-hover:text-gold-ink">
                        {uniqueSources(c.items)}
                      </span>
                      <span className="whitespace-nowrap text-[10px] uppercase tracking-[0.2em] text-warm-grey/60">
                        {timeAgo(c.publishedAt)}
                      </span>
                    </div>
                    <h3 className="mt-3 font-serif text-2xl leading-snug text-charcoal">
                      <ItemTrigger
                        item={rep}
                        className="text-left transition-colors duration-500 ease-luxe hover:text-gold-ink"
                      >
                        {c.title}
                      </ItemTrigger>
                    </h3>
                    {c.items.length > 1 && (
                      <p className="mt-3 text-[10px] uppercase tracking-[0.25em] text-warm-grey/70">
                        +{c.items.length - 1} related report
                        {c.items.length > 2 ? "s" : ""}
                      </p>
                    )}
                  </article>
                </Reveal>
              );
            })}
          </div>
        )}

        {/* Latest dispatches — the unfiltered ticker */}
        {latest.length > 0 && (
          <>
            <Rule className="mt-24 h-px bg-charcoal/15" />
            <div className="grid grid-cols-12 gap-y-10 pt-14 lg:gap-x-12">
            <div className="col-span-12 lg:col-span-4">
              <Overline>Latest Dispatches</Overline>
              <h3 className="mt-6 font-serif text-3xl leading-tight text-charcoal md:text-4xl">
                Straight off <Em>the wire.</Em>
              </h3>
              <p className="mt-6 max-w-xs text-sm leading-relaxed text-warm-grey">
                The most recent items across every desk — unfiltered,
                unranked, exactly as they arrived.
              </p>
            </div>
            {/* The list starts below its heading — stepped, not top-aligned */}
            <ol className="col-span-12 lg:col-span-8 lg:mt-14">
              {latest.map((item, i) => (
                <li
                  key={item.id}
                  className="group flex items-baseline gap-6 border-b border-charcoal/10 py-5 transition-colors duration-700 ease-luxe hover:bg-taupe/25 md:px-4"
                >
                  <span className="w-8 font-serif text-sm text-warm-grey/60">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <div className="flex-1">
                    <ItemTrigger
                      item={item}
                      className="block text-left font-serif text-lg leading-snug text-charcoal transition-colors duration-500 ease-luxe hover:text-gold-ink md:text-xl"
                    >
                      {item.title}
                    </ItemTrigger>
                    <span className="mt-1 block text-[10px] uppercase tracking-[0.25em] text-warm-grey/70">
                      {item.source.name}
                    </span>
                  </div>
                  <time dateTime={item.publishedAt} className="whitespace-nowrap text-[10px] uppercase tracking-[0.2em] text-warm-grey/60">
                    {timeAgo(item.publishedAt)}
                  </time>
                </li>
              ))}
            </ol>
            </div>
          </>
        )}
      </div>
    </section>
  );
}
