import { Rule } from "@/components/luxe/rule";

const COLUMNS = [
  {
    title: "Sections",
    links: [
      { label: "Front Page", href: "#front-page" },
      { label: "The Wire", href: "#wire" },
      { label: "Latest Dispatches", href: "#front-page" },
    ],
  },
  {
    title: "Reading",
    links: [
      { label: "Newest First", href: "#wire" },
      { label: "Trending", href: "#wire" },
      { label: "By Source", href: "#wire" },
    ],
  },
  {
    title: "Colophon",
    links: [
      { label: "Playfair Display", href: "#colophon" },
      { label: "Inter", href: "#colophon" },
      { label: "Éd. 01 — Autumn", href: "#colophon" },
    ],
  },
];

export function SiteFooter() {
  return (
    <footer id="colophon" className="mt-auto scroll-mt-24">
      <Rule className="h-px bg-charcoal/15" />
      <div className="mx-auto max-w-[1600px] px-8 pb-10 pt-16 md:px-16 md:pt-24">
        <div className="grid grid-cols-12 gap-y-12">
          {/* Brand statement */}
          <div className="col-span-12 lg:col-span-5">
            <p className="font-serif text-2xl tracking-[0.08em] text-charcoal">
              MAISON
            </p>
            <p className="mt-6 max-w-xs text-sm leading-relaxed text-warm-grey">
              An editorial wire for the discerning reader — every source,
              every story, set in type the moment it arrives.
            </p>
          </div>

          {/* Link columns */}
          {COLUMNS.map((col) => (
            <nav
              key={col.title}
              aria-label={col.title}
              className="col-span-6 sm:col-span-4 lg:col-span-2 lg:col-start-auto"
            >
              <h3 className="text-[10px] uppercase tracking-[0.3em] text-charcoal">
                {col.title}
              </h3>
              <ul className="mt-6 space-y-4">
                {col.links.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      className="text-xs uppercase tracking-[0.2em] text-warm-grey transition-colors duration-500 ease-luxe hover:text-gold-ink"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </nav>
          ))}
        </div>

        {/* Micro-text bottom row */}
        <div className="mt-16 flex flex-col gap-4 border-t border-charcoal/10 pt-8 text-[10px] uppercase tracking-[0.25em] text-warm-grey md:mt-24 md:flex-row md:items-center md:justify-between">
          <span>© 2026 Maison — The Live Wire</span>
          <span>Updated continuously</span>
          <span>Set in Playfair Display &amp; Inter</span>
        </div>
      </div>
    </footer>
  );
}
