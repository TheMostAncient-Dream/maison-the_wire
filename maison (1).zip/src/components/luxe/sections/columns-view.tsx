"use client";

import { useCallback, useEffect, useState } from "react";
import { Em, Overline } from "@/components/luxe/atoms";
import { Rule } from "@/components/luxe/rule";
import type { ItemDTO, TopicDTO } from "@/lib/types";
import { useSession } from "@/components/luxe/session/session-provider";
import { ItemCard } from "@/components/luxe/feed/item-card";

/**
 * The Gallery — the reader's chosen desks, side by side like the plates
 * of a broadsheet: independently scrollable columns on the desk-width
 * screen, full-width sections stacked on a narrow one. Shaped by the
 * Settings panel; guests and members are fed by the same /api/columns.
 */

interface ColumnFeed {
  slug: string;
  items: ItemDTO[];
}

const PSEUDO_LABELS: Record<string, string> = {
  latest: "Latest",
  trending: "Trending",
};

export function ColumnsView() {
  const { user, ready, prefs, openSettings } = useSession();
  const [feeds, setFeeds] = useState<ColumnFeed[]>([]);
  const [names, setNames] = useState<Record<string, string>>(PSEUDO_LABELS);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [reload, setReload] = useState(0);

  const prefsKey = [
    user ? "member" : "guest",
    prefs.columns.join(","),
    prefs.itemsPerColumn,
    prefs.contentTypes.join(","),
  ].join("|");

  useEffect(() => {
    fetch("/api/topics")
      .then((r) => r.json())
      .then((list: TopicDTO[]) =>
        setNames((prev) => {
          const next = { ...prev };
          for (const t of list) next[t.slug] = t.name;
          return next;
        })
      )
      .catch(() => {});
  }, []);

  useEffect(() => {
    const onChanged = () => setReload((v) => v + 1);
    window.addEventListener("maison:prefs-changed", onChanged);
    return () => window.removeEventListener("maison:prefs-changed", onChanged);
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    setError(false);
    try {
      const params = new URLSearchParams({ limit: String(prefs.itemsPerColumn) });
      if (!user) {
        if (prefs.columns.length) params.set("columns", prefs.columns.join(","));
        if (prefs.contentTypes.length) params.set("types", prefs.contentTypes.join(","));
      }
      const res = await fetch(`/api/columns?${params.toString()}`);
      if (!res.ok) throw new Error("columns unavailable");
      const data = (await res.json()) as { columns: ColumnFeed[] };
      setFeeds(data.columns);
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  }, [prefsKey]);

  useEffect(() => {
    if (!ready) return;
    let cancelled = false;
    queueMicrotask(() => {
      if (!cancelled) void load();
    });
    return () => {
      cancelled = true;
    };
  }, [ready, load, reload]);

  const label = (slug: string) =>
    names[slug] ?? slug.charAt(0).toUpperCase() + slug.slice(1);

  return (
    <section id="columns" className="relative scroll-mt-24 py-24 md:py-32">
      <div className="mx-auto max-w-[1600px] px-8 md:px-16">
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <div>
            <Overline className="-ml-3 md:-ml-5">The Gallery</Overline>
            <h2 className="mt-6 font-serif text-5xl leading-[0.95] text-charcoal md:text-7xl">
              Your desks,
              <br />
              <span className="inline-block pl-[0.5em]">
                <Em>side by side.</Em>
              </span>
            </h2>
          </div>
          <p className="max-w-sm text-base leading-relaxed text-warm-grey md:pb-2 md:text-right">
            Each column runs on its own — scroll one desk without losing your
            place at the others. Rearrange them in Settings.
          </p>
        </div>

        <Rule className="mt-14 h-px bg-charcoal/15" />
        <div className="pt-10">
          {loading ? (
            <SkeletonColumns />
          ) : error ? (
            <div className="flex flex-col items-center py-20 text-center">
              <p className="font-serif text-4xl italic text-charcoal">
                The gallery lost its light.
              </p>
              <p className="mt-4 max-w-sm text-sm leading-relaxed text-warm-grey">
                Something interrupted the hanging — try again in a moment.
              </p>
              <button
                type="button"
                onClick={() => void load()}
                className="mt-8 text-xs uppercase tracking-[0.25em] text-warm-grey underline-offset-8 transition-colors duration-500 ease-luxe hover:text-gold-ink hover:underline"
              >
                Hang it again
              </button>
            </div>
          ) : feeds.every((f) => f.items.length === 0) ? (
            <div className="flex flex-col items-center py-20 text-center">
              <p className="font-serif text-4xl italic text-charcoal">
                An empty gallery.
              </p>
              <p className="mt-4 max-w-md text-sm leading-relaxed text-warm-grey">
                No desks are showing anything — choose a few in Settings and
                the columns will fill.
              </p>
              <button
                type="button"
                onClick={openSettings}
                className="mt-8 border border-charcoal px-8 py-3.5 text-xs uppercase tracking-[0.25em] text-charcoal transition-colors duration-500 ease-luxe hover:bg-charcoal hover:text-alabaster focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-charcoal"
              >
                Open Settings
              </button>
            </div>
          ) : (
            /* Even columns hang lower — broadsheet plates at their own heights */
            <div className="no-scrollbar -mx-8 flex flex-col gap-12 px-8 md:-mx-16 md:flex-row md:gap-10 md:overflow-x-auto md:px-16 xl:grid xl:grid-cols-4 xl:overflow-visible xl:[&>*:nth-child(even)]:mt-14">
              {feeds.map((feed) => (
                <Column
                  key={feed.slug}
                  slug={feed.slug}
                  label={label(feed.slug)}
                  items={feed.items}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

function Column({
  slug,
  label,
  items,
}: {
  slug: string;
  label: string;
  items: ItemDTO[];
}) {
  return (
    <section
      aria-label={`${label} column`}
      className="w-full md:w-[340px] md:shrink-0 xl:w-auto"
    >
      <Rule className="h-px bg-charcoal/60" />
      <div className="pt-5 flex items-baseline justify-between gap-4">
        <h3 className="font-serif text-2xl italic text-charcoal">{label}</h3>
        <span className="text-[10px] uppercase tracking-[0.25em] text-warm-grey">
          {items.length} {items.length === 1 ? "piece" : "pieces"}
        </span>
      </div>

      {items.length === 0 ? (
        <p className="py-10 text-sm italic leading-relaxed text-warm-grey">
          Nothing on this desk yet — the presses are still turning.
        </p>
      ) : (
        <div
          className="mt-6 grid grid-cols-2 gap-x-6 gap-y-10 md:grid-cols-1 md:gap-y-10 xl:max-h-[68vh] xl:overflow-y-auto"
          data-column={slug}
        >
          {items.map((item, i) => (
            <ItemCard
              key={item.id}
              item={item}
              featured={i === 0}
              delay={(i % 2) * 110}
            />
          ))}
        </div>
      )}
    </section>
  );
}

function SkeletonColumns() {
  return (
    <div aria-hidden className="flex flex-col gap-12 md:flex-row md:gap-10 md:overflow-hidden xl:grid xl:grid-cols-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} className="w-full border-t border-charcoal/60 pt-5 md:w-[340px] md:shrink-0 xl:w-auto">
          <div className="h-7 w-1/2 animate-pulse bg-taupe/70" />
          <div className="mt-6 grid grid-cols-2 gap-x-6 gap-y-6 md:grid-cols-1">
            {Array.from({ length: 3 }).map((_, j) => (
              <div key={j}>
                <div className="aspect-[3/4] w-full animate-pulse bg-taupe/50" />
                <div className="mt-4 h-4 w-full animate-pulse bg-taupe/70" />
                <div className="mt-2 h-4 w-2/3 animate-pulse bg-taupe/70" />
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
