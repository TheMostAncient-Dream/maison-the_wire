"use client";

import { useCallback, useEffect, useState } from "react";
import { Em, Overline } from "@/components/luxe/atoms";
import { Rule } from "@/components/luxe/rule";
import type { ItemDTO } from "@/lib/types";
import { useSession, type SavedItemDTO } from "@/components/luxe/session/session-provider";
import { ItemCard } from "@/components/luxe/feed/item-card";

/**
 * The Shelf — the reader's bookmarked dispatches in the same grid as
 * The Wire, fed by /api/bookmarks. Refetches whenever the saved marks
 * change so un/saving from the shelf itself stays honest. Guests are
 * welcomed with an invitation rather than an error.
 */
export function SavedView() {
  const { user, ready, savedVersion, openAccount } = useSession();
  const [items, setItems] = useState<ItemDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const load = useCallback(async () => {
    if (!user) {
      setItems([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(false);
    try {
      const res = await fetch("/api/bookmarks");
      if (!res.ok) throw new Error("shelf unavailable");
      const data = (await res.json()) as { items: SavedItemDTO[] };
      setItems(data.items);
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    let cancelled = false;
    queueMicrotask(() => {
      if (!cancelled) void load();
    });
    return () => {
      cancelled = true;
    };
  }, [load, savedVersion]);

  return (
    <section id="saved" className="relative scroll-mt-24 py-24 md:py-32">
      <div className="mx-auto max-w-[1600px] px-8 md:px-16">
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <div>
            <Overline>The Shelf</Overline>
            <h2 className="mt-6 font-serif text-5xl leading-[0.95] text-charcoal md:text-7xl">
              Saved
              <br />
              <Em>dispatches.</Em>
            </h2>
          </div>
          <p className="max-w-sm text-base leading-relaxed text-warm-grey md:pb-2 md:text-right">
            {user
              ? `${items.length.toLocaleString("en-US")} ${items.length === 1 ? "story" : "stories"} kept for later reading — yours alone, on every device.`
              : "The gold mark on any dispatch adds it here."}
          </p>
        </div>

        <Rule className="mt-14 h-px bg-charcoal/15" />
        <div>
          {!ready || loading ? (
            <div
              aria-hidden
              className="mt-14 grid grid-cols-1 gap-x-8 gap-y-16 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
            >
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="border-t border-charcoal/15 pt-6">
                  <div className="aspect-[3/4] w-full animate-pulse bg-taupe/50" />
                  <div className="mt-6 h-2.5 w-1/3 animate-pulse bg-taupe/70" />
                  <div className="mt-4 h-5 w-full animate-pulse bg-taupe/70" />
                </div>
              ))}
            </div>
          ) : !user ? (
            <div className="flex flex-col items-center py-24 text-center">
              <p className="font-serif text-4xl italic text-charcoal">
                Keep what catches your eye.
              </p>
              <p className="mt-4 max-w-md text-sm leading-relaxed text-warm-grey">
                Saved dispatches live with your subscription. Sign in — or take
                a moment to register — and the gold mark on any story will
                carry it here.
              </p>
              <button
                type="button"
                onClick={openAccount}
                className="mt-8 border border-charcoal px-8 py-3.5 text-xs uppercase tracking-[0.25em] text-charcoal transition-colors duration-500 ease-luxe hover:bg-charcoal hover:text-alabaster focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-charcoal"
              >
                Sign in to your desk
              </button>
            </div>
          ) : error ? (
            <div className="flex flex-col items-center py-24 text-center">
              <p className="font-serif text-4xl italic text-charcoal">
                The shelf is out of reach.
              </p>
              <p className="mt-4 max-w-sm text-sm leading-relaxed text-warm-grey">
                Something interrupted the delivery — try again in a moment.
              </p>
              <button
                type="button"
                onClick={() => void load()}
                className="mt-8 text-xs uppercase tracking-[0.25em] text-warm-grey underline-offset-8 transition-colors duration-500 ease-luxe hover:text-gold-ink hover:underline"
              >
                Try the shelf again
              </button>
            </div>
          ) : items.length === 0 ? (
            <div className="flex flex-col items-center py-24 text-center">
              <p className="font-serif text-4xl italic text-charcoal">
                The shelf is empty.
              </p>
              <p className="mt-4 max-w-md text-sm leading-relaxed text-warm-grey">
                Nothing saved yet — the gold mark on any dispatch adds it here.
              </p>
            </div>
          ) : (
            <div className="mt-14 grid grid-cols-1 gap-x-8 gap-y-16 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {items.map((item) => (
                <ItemCard key={item.id} item={item} />
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
