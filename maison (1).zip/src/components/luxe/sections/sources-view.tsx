"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { ArrowUpRight } from "lucide-react";
import { Em, Overline } from "@/components/luxe/atoms";
import { Rule } from "@/components/luxe/rule";
import type { SourceDTO } from "@/lib/types";
import { cn } from "@/lib/utils";

/**
 * The Registry — every active source in the wire, set as a clean
 * editorial directory grouped by desk. Clicking a source aims The Wire
 * at that publisher alone. The curated Instagram accounts appear in
 * their own honest section — labelled link-out cards, never scraped
 * content, never mixed into the wire.
 */

const HEALTH: Record<string, { label: string; className: string }> = {
  healthy: { label: "Active", className: "border-charcoal/25 text-warm-grey" },
  degraded: { label: "Degraded", className: "border-gold/60 text-gold-ink" },
  error: { label: "Error", className: "bg-charcoal text-alabaster border-charcoal" },
  unknown: { label: "New", className: "border-charcoal/25 text-warm-grey" },
};

interface Group {
  key: string;
  label: string;
  sources: SourceDTO[];
}

export function SourcesView() {
  const [sources, setSources] = useState<SourceDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    setError(false);
    fetch("/api/sources")
      .then((r) => {
        if (!r.ok) throw new Error("registry unavailable");
        return r.json();
      })
      .then((data: SourceDTO[]) => setSources(data))
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  }, []);

  /* First paint of the directory — the skeleton is already up. */
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("/api/sources");
        if (!res.ok) throw new Error("registry unavailable");
        const data = (await res.json()) as SourceDTO[];
        if (!cancelled) setSources(data);
      } catch {
        if (!cancelled) setError(true);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const groups = useMemo<Group[]>(() => {
    const active = sources.filter((s) => s.isActive && s.type !== "instagram");
    const byTopic = new Map<string, SourceDTO[]>();
    for (const s of active.filter((x) => x.type === "rss")) {
      const key = s.topicSlugs[0] ?? "world";
      const list = byTopic.get(key) ?? [];
      list.push(s);
      byTopic.set(key, list);
    }
    const topicGroups: Group[] = [...byTopic.entries()]
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([key, list]) => ({
        key,
        label: key.charAt(0).toUpperCase() + key.slice(1),
        sources: list.sort((a, b) => a.name.localeCompare(b.name)),
      }));

    const wires = active.filter((s) => s.type === "youtube");
    const youtubeGroup: Group[] = wires.length
      ? [
          {
            key: "film-desks",
            label: "Film Desks — YouTube",
            sources: wires.sort((a, b) => a.name.localeCompare(b.name)),
          },
        ]
      : [];

    const instagram = sources.filter((s) => s.type === "instagram");
    const instagramGroup: Group[] = instagram.length
      ? [{ key: "instagram", label: "Instagram — Opens Externally", sources: instagram }]
      : [];

    return [...youtubeGroup, ...topicGroups, ...instagramGroup];
  }, [sources]);

  return (
    <section id="sources" className="relative scroll-mt-24 py-24 md:py-32">
      <div className="mx-auto max-w-[1600px] px-8 md:px-16">
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <div>
            <Overline>The Registry</Overline>
            <h2 className="mt-6 font-serif text-5xl leading-[0.95] text-charcoal md:text-7xl">
              Where the wire
              <br />
              <Em>comes from.</Em>
            </h2>
          </div>
          <p className="max-w-sm text-base leading-relaxed text-warm-grey md:pb-2 md:text-right">
            {loading
              ? "Reading the registry…"
              : `${sources.filter((s) => s.isActive && s.type !== "instagram").length} active sources, monitored continuously. Click one to read The Wire from that desk alone.`}
          </p>
        </div>

        <Rule className="mt-14 h-px bg-charcoal/15" />
        <div className="pt-10">
          {loading ? (
            <div aria-hidden className="grid grid-cols-2 gap-x-8 gap-y-10 md:grid-cols-3 xl:grid-cols-4">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="border-t border-charcoal/30 pt-5">
                  <div className="flex items-center gap-4">
                    <div className="h-12 w-12 animate-pulse bg-taupe/70" />
                    <div className="h-4 w-2/3 animate-pulse bg-taupe/70" />
                  </div>
                  <div className="mt-4 h-3 w-1/2 animate-pulse bg-taupe/50" />
                </div>
              ))}
            </div>
          ) : error ? (
            <div className="flex flex-col items-center py-20 text-center">
              <p className="font-serif text-4xl italic text-charcoal">
                The registry is out of reach.
              </p>
              <button
                type="button"
                onClick={load}
                className="mt-8 text-xs uppercase tracking-[0.25em] text-warm-grey underline-offset-8 transition-colors duration-500 ease-luxe hover:text-gold-ink hover:underline"
              >
                Open it again
              </button>
            </div>
          ) : (
            <div className="space-y-16">
              {groups.map((group) => (
                <div key={group.key}>
                  <div className="flex items-center gap-5">
                    <h3 className="text-[10px] font-medium uppercase tracking-[0.3em] text-warm-grey">
                      {group.label}
                    </h3>
                    <span aria-hidden className="h-px flex-1 bg-charcoal/10" />
                    <span className="text-[10px] uppercase tracking-[0.25em] text-warm-grey/60">
                      {group.sources.length}
                    </span>
                  </div>

                  <div
                    className={cn(
                      "mt-8 grid gap-x-8 gap-y-10",
                      group.key === "instagram"
                        ? "grid-cols-2 md:grid-cols-3 xl:grid-cols-4"
                        : "grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4"
                    )}
                  >
                    {group.sources.map((s) =>
                      group.key === "instagram" ? (
                        <InstagramCard key={s.id} source={s} />
                      ) : (
                        <SourceCard key={s.id} source={s} />
                      )
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

function monogramOf(name: string): string {
  return (name.replace(/^@/, "").match(/[a-z]/i)?.[0] ?? "M").toUpperCase();
}

function HealthBadge({ status }: { status: string }) {
  const badge = HEALTH[status] ?? HEALTH.unknown;
  return (
    <span
      className={cn(
        "border px-2 py-0.5 text-[9px] uppercase tracking-[0.2em]",
        badge.className
      )}
    >
      {badge.label}
    </span>
  );
}

/** A content source — click aims The Wire at this publisher. */
function SourceCard({ source }: { source: SourceDTO }) {
  const aim = () => {
    window.dispatchEvent(
      new CustomEvent("maison:source-filter", {
        detail: { slug: source.slug, name: source.name },
      })
    );
    document.getElementById("wire")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <button
      type="button"
      onClick={aim}
      className="group pt-5 text-left transition-colors duration-700 ease-luxe hover:bg-taupe/25 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-charcoal"
      aria-label={`Read The Wire from ${source.name} only`}
    >
      <Rule className="h-px bg-charcoal/30" />
      <div className="flex items-start gap-4">
        <span
          aria-hidden
          className="rounded-media flex h-12 w-12 shrink-0 select-none items-center justify-center border border-charcoal/10 bg-taupe/60 font-serif text-2xl text-charcoal/25 transition-colors duration-700 ease-luxe group-hover:text-charcoal/40"
        >
          {monogramOf(source.name)}
        </span>
        <span className="min-w-0">
          <span className="block truncate text-sm font-medium text-charcoal transition-colors duration-500 ease-luxe group-hover:text-gold-ink">
            {source.name}
          </span>
          <span className="mt-1.5 inline-block">
            <HealthBadge status={source.healthStatus} />
          </span>
        </span>
      </div>
      <div className="mt-4 flex flex-wrap items-center gap-x-3 gap-y-1 text-[10px] uppercase tracking-[0.2em] text-warm-grey/70">
        {source.topicSlugs.slice(0, 2).map((t) => (
          <span key={t}>{t}</span>
        ))}
        {source.country && (
          <>
            <span aria-hidden className="h-px w-3 bg-charcoal/30" />
            <span>{source.country}</span>
          </>
        )}
        <span aria-hidden className="h-px w-3 bg-charcoal/30" />
        <span>{source.language.toUpperCase()}</span>
      </div>
    </button>
  );
}

/**
 * The honest Instagram card — a clearly-labelled link out to
 * instagram.com. Nothing is embedded, scraped or invented.
 */
function InstagramCard({ source }: { source: SourceDTO }) {
  return (
    <a
      href={source.websiteUrl ?? `https://www.instagram.com/${source.externalId}/`}
      target="_blank"
      rel="noopener noreferrer"
      className="group pt-5 transition-colors duration-700 ease-luxe hover:bg-taupe/25 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-charcoal"
    >
      <Rule className="h-px bg-charcoal/30" />
      <div className="flex items-start gap-4">
        <span
          aria-hidden
          className="rounded-media flex h-12 w-12 shrink-0 select-none items-center justify-center border border-charcoal/10 bg-taupe/60 font-serif text-2xl text-charcoal/25 transition-colors duration-700 ease-luxe group-hover:text-charcoal/40"
        >
          {monogramOf(source.name)}
        </span>
        <span className="min-w-0">
          <span className="flex items-center gap-1.5 text-sm font-medium text-charcoal transition-colors duration-500 ease-luxe group-hover:text-gold-ink">
            <span className="truncate">{source.name}</span>
            <ArrowUpRight className="h-3 w-3 shrink-0" strokeWidth={1.5} aria-hidden />
          </span>
          <span className="mt-1.5 inline-block border border-gold/60 px-2 py-0.5 text-[9px] uppercase tracking-[0.2em] text-gold-ink">
            Instagram — opens externally
          </span>
        </span>
      </div>
    </a>
  );
}
