import { Rule } from "@/components/luxe/rule";
import { getStatus } from "@/lib/server/content";

/**
 * Newspaper masthead — centred serif brand flanked by the date and
 * edition, with a live wire-status line beneath. Server-rendered.
 */
export async function Masthead() {
  let totalItems = 0;
  let items24h = 0;
  let activeSources = 0;
  try {
    const status = await getStatus();
    totalItems = status.totalItems;
    items24h = status.items24h;
    activeSources = status.activeSources;
  } catch {
    /* Zeros render quietly if the wire is down. */
  }

  const dateStr = new Intl.DateTimeFormat("en-GB", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date());

  return (
    <header>
      <div className="mx-auto max-w-[1600px] px-8 pb-10 pt-12 md:px-16 md:pb-14 md:pt-16">
        <div className="grid grid-cols-12 items-end gap-y-6">
          <div className="mast-in col-span-12 hidden flex-col gap-3 text-[10px] uppercase tracking-[0.3em] text-warm-grey md:col-span-3 md:flex">
            <span>{dateStr}</span>
            <span className="flex items-center gap-2">
              <span
                aria-hidden
                className="h-1.5 w-1.5 rotate-45 animate-pulse bg-gold"
              />
              Live — {items24h.toLocaleString("en-US")} in 24h
            </span>
          </div>

          <div className="col-span-12 text-center md:col-span-6">
            <p
              style={{ animationDelay: "90ms" }}
              className="mast-in font-serif text-5xl tracking-[0.06em] text-charcoal md:text-7xl"
            >
              MAISON
            </p>
            <p
              style={{ animationDelay: "220ms" }}
              className="mast-in mt-4 text-[10px] uppercase tracking-[0.35em] text-warm-grey"
            >
              The whole wire, beautifully set
            </p>
          </div>

          <div
            style={{ animationDelay: "300ms" }}
            className="mast-in col-span-12 hidden flex-col items-end gap-3 text-[10px] uppercase tracking-[0.3em] text-warm-grey md:col-span-3 md:flex"
          >
            <span>Éd. 01 — Autumn</span>
            <span>{activeSources} sources on the wire</span>
          </div>
        </div>

        {/* Compact live line for mobile */}
        <div
          style={{ animationDelay: "220ms" }}
          className="mast-in mt-6 flex items-center justify-center gap-3 text-[10px] uppercase tracking-[0.25em] text-warm-grey md:hidden"
        >
          <span aria-hidden className="h-1.5 w-1.5 rotate-45 animate-pulse bg-gold" />
          <span>
            {totalItems.toLocaleString("en-US")} dispatches · {activeSources} sources · live
          </span>
        </div>
      </div>
      <Rule className="h-px bg-charcoal/15" />
    </header>
  );
}
