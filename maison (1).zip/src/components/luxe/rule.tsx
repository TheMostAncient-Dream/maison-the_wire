import { cn } from "@/lib/utils";

/**
 * An editorial rule — the horizontal lines that structure the page
 * (section dividers, card tops, the gold lead rule). Rendered as a
 * standalone element instead of a border so the RuleRandomizer can
 * give every third one a life of its own.
 *
 * Colour / thickness / spacing come in via className, exactly like the
 * border utilities it replaces:
 *   border-t border-charcoal/60  →  <Rule className="h-px bg-charcoal/60" />
 *   border-t-4 border-t-gold     →  <Rule className="h-1 bg-gold" />
 */
export function Rule({
  className,
  label,
}: {
  className?: string;
  /** Accessible name for the section this rule opens (rarely needed — rules are decorative). */
  label?: string;
}) {
  return (
    <span
      aria-hidden={!label}
      aria-label={label}
      data-rule=""
      className={cn("block", className)}
    />
  );
}
