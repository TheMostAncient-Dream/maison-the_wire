"use client";

import { AnimatePresence, MotionConfig, motion, useReducedMotion } from "framer-motion";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { ArrowUpRight, Bookmark, Check, Link2, X } from "lucide-react";
import type { ItemDTO, StoryBriefDTO } from "@/lib/types";
import { cn } from "@/lib/utils";
import { useSession } from "@/components/luxe/session/session-provider";
import { LuxeButton } from "@/components/luxe/luxe-button";
import { SmartThumb } from "./smart-thumb";
import { VideoStage } from "./video-stage";
import { formatDuration } from "./utils";

/**
 * Dispatch modal — click any story and a small paper panel rises to the
 * centre of the page with every detail; click outside, press Esc, or hit
 * Close and it dissolves. Context is available to any client component
 * beneath the provider; `ItemTrigger` is the clickable wrapper.
 */

interface NewsModalState {
  item: ItemDTO | null;
  open: (item: ItemDTO) => void;
  close: () => void;
}

const NewsModalContext = createContext<NewsModalState | null>(null);

/* House easing — the same curve the CSS system calls ease-luxe. */
const EASE: [number, number, number, number] = [0.25, 0.46, 0.45, 0.94];

/* The paper rises into place; on the way out it settles back down and
   dissolves instead of vanishing. prefers-reduced-motion is honoured by
   the MotionConfig below (transforms are dropped, fades remain). */
const backdropVariants = {
  enter: { opacity: 0 },
  shown: {
    opacity: 1,
    transition: { duration: 0.4, ease: EASE },
  },
  exit: {
    opacity: 0,
    transition: { duration: 0.26, ease: EASE },
  },
};
const panelVariants = {
  enter: { opacity: 0, y: 24, scale: 0.99 },
  shown: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { duration: 0.55, ease: EASE },
  },
  exit: {
    opacity: 0,
    y: 14,
    scale: 0.985,
    transition: { duration: 0.28, ease: EASE },
  },
};

/* prefers-reduced-motion: the paper only fades — no travel at all.
   (Explicit rather than relying on MotionConfig alone, so the reduced
   path is deterministic.) */
const reducedPanelVariants = {
  enter: { opacity: 0 },
  shown: {
    opacity: 1,
    transition: { duration: 0.4, ease: EASE },
  },
  exit: {
    opacity: 0,
    transition: { duration: 0.24, ease: EASE },
  },
};

export function useNewsModal(): NewsModalState {
  const ctx = useContext(NewsModalContext);
  if (!ctx) throw new Error("useNewsModal must be used within NewsModalProvider");
  return ctx;
}

export function NewsModalProvider({ children }: { children: ReactNode }) {
  const [item, setItem] = useState<ItemDTO | null>(null);
  const open = useCallback((i: ItemDTO) => setItem(i), []);
  const close = useCallback(() => setItem(null), []);

  /*
   * Notification deep link — a browser notification click lands here two
   * ways: warm (the worker focuses this window and posts the item id) or
   * cold (a fresh tab opens at /?item=<id>). Either way the dispatch
   * modal lifts the story straight onto the desk.
   */
  useEffect(() => {
    const openById = async (id: string) => {
      try {
        const res = await fetch(`/api/item/${id}`);
        if (!res.ok) return;
        const data = (await res.json()) as { item?: ItemDTO };
        if (data.item) open(data.item);
      } catch {
        /* the story is on the front page regardless */
      }
    };

    const params = new URLSearchParams(window.location.search);
    const deepLinkId = params.get("item");
    if (deepLinkId) {
      window.history.replaceState({}, "", window.location.pathname);
      void openById(deepLinkId);
    }

    const onMessage = (e: MessageEvent) => {
      if (
        e.data &&
        typeof e.data === "object" &&
        (e.data as { type?: unknown }).type === "maison:open-item" &&
        typeof (e.data as { itemId?: unknown }).itemId === "string"
      ) {
        void openById((e.data as { itemId: string }).itemId);
      }
    };
    navigator.serviceWorker?.addEventListener("message", onMessage);
    return () => navigator.serviceWorker?.removeEventListener("message", onMessage);
  }, [open]);

  return (
    <NewsModalContext.Provider value={{ item, open, close }}>
      <MotionConfig reducedMotion="user">
        {children}
        <AnimatePresence>
          {item && <NewsModal key="dispatch" item={item} onClose={close} />}
        </AnimatePresence>
      </MotionConfig>
    </NewsModalContext.Provider>
  );
}

/** Click-to-open wrapper — renders a button that lifts the item into the modal. */
export function ItemTrigger({
  item,
  className,
  children,
  ariaLabel,
}: {
  item: ItemDTO;
  className?: string;
  children: ReactNode;
  ariaLabel?: string;
}) {
  const { open } = useNewsModal();
  return (
    <button
      type="button"
      onClick={() => open(item)}
      className={className}
      aria-label={ariaLabel}
      aria-haspopup="dialog"
    >
      {children}
    </button>
  );
}

function NewsModal({ item, onClose }: { item: ItemDTO; onClose: () => void }) {
  const closeRef = useRef<HTMLButtonElement>(null);
  const [imgOk, setImgOk] = useState(true);
  const hasImage = Boolean(item.thumbnailUrl) && imgOk;
  const reduce = useReducedMotion();

  /* Re-arm the image state when a different dispatch is opened
     (React's adjust-state-during-render pattern — no effect needed). */
  const [prevItemId, setPrevItemId] = useState(item.id);
  if (prevItemId !== item.id) {
    setPrevItemId(item.id);
    setImgOk(true);
  }

  /* Scroll lock, initial focus, Esc-to-close */
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  const published = new Date(item.publishedAt).toLocaleString("en-GB", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
  const typeLabel =
    item.type === "video"
      ? `Film${item.durationSec ? ` — ${formatDuration(item.durationSec)}` : ""}`
      : item.type === "instagram"
        ? "Instagram"
        : "Article";

  let sourceHost = "";
  if (item.source.websiteUrl) {
    try {
      sourceHost = new URL(item.source.websiteUrl).hostname.replace(/^www\./, "");
    } catch {
      sourceHost = item.source.websiteUrl;
    }
  }

  return (
    <motion.div
      className="fixed inset-0 z-[60] flex items-center justify-center p-4 md:p-8"
      role="dialog"
      aria-modal="true"
      aria-label={item.title}
      initial="enter"
      animate="shown"
      exit="exit"
    >
      {/* Backdrop — click outside to dismiss (true black veil dims in both editions) */}
      <motion.div
        variants={backdropVariants}
        className="absolute inset-0 bg-black/45 backdrop-blur-[2px]"
        onClick={onClose}
        aria-hidden
      />

      {/* Paper panel */}
      <motion.div
        variants={reduce ? reducedPanelVariants : panelVariants}
        className="rounded-panel relative flex max-h-[86vh] w-full max-w-2xl flex-col overflow-hidden border border-charcoal/15 bg-alabaster shadow-[0_24px_64px_rgba(0,0,0,0.18)]"
      >
        {/* Sticky header */}
        <div className="flex items-center justify-between border-b border-charcoal/10 px-6 py-4 md:px-8">
          <span className="text-[10px] uppercase tracking-[0.3em] text-warm-grey">
            Maison — Dispatch
          </span>
          <button
            ref={closeRef}
            type="button"
            onClick={onClose}
            aria-label="Close details"
            className="flex h-9 w-9 items-center justify-center text-warm-grey transition-colors duration-500 ease-luxe hover:text-gold-ink focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-charcoal"
          >
            <X className="h-4 w-4" strokeWidth={1.5} aria-hidden />
          </button>
        </div>

        {/* Scrollable body */}
        <div className="luxe-scroll overflow-y-auto px-6 py-8 md:px-10">
          {item.type === "video" ? (
            /* Films play inline — still with a gold play glyph first, the
               nocookie iframe mounts only on click (unmounts on close). */
            <VideoStage item={item} />
          ) : (
            hasImage && (
              <div className="rounded-media group relative mb-8 aspect-[16/9] overflow-hidden bg-taupe shadow-[0_8px_32px_rgba(0,0,0,0.12)]">
                <SmartThumb
                  src={item.thumbnailUrl ?? ""}
                  onDead={() => setImgOk(false)}
                  className="h-full w-full object-cover grayscale transition-all duration-[1600ms] ease-luxe group-hover:scale-[1.03] group-hover:grayscale-0"
                />
              </div>
            )
          )}

          {/* Kicker */}
          <div className="flex flex-wrap items-baseline justify-between gap-3">
            <span className="text-[10px] font-medium uppercase tracking-[0.25em] text-warm-grey">
              {item.source.name}
            </span>
            <span className="text-[10px] uppercase tracking-[0.2em] text-warm-grey/60">
              {typeLabel}
            </span>
          </div>

          <h2 className="mt-4 font-serif text-3xl leading-[1.1] text-charcoal md:text-4xl">
            {item.title}
          </h2>

          <span aria-hidden className="mt-6 block h-px w-12 bg-gold" />

          {/* The Brief — distilled gist + key details, falls back to the raw
              wire snippet while composing or when distillation is unavailable */}
          <BriefSection key={item.id} item={item} />

          {/* Specs — editorial details table */}
          <dl className="mt-8 grid grid-cols-2 gap-x-8 gap-y-6 border-t border-charcoal/15 pt-6 md:grid-cols-3">
            <Spec label="Published" value={published} />
            {item.author && <Spec label="Author" value={item.author} />}
            <Spec label="Edition" value={typeLabel} />
            <Spec label="Language" value={item.language.toUpperCase()} />
            {item.country && <Spec label="Country" value={item.country.toUpperCase()} />}
            {sourceHost && (
              <div className="col-span-2 md:col-span-1">
                <dt className="text-[10px] uppercase tracking-[0.25em] text-warm-grey">
                  Source
                </dt>
                <dd className="mt-1">
                  <a
                    href={item.source.websiteUrl ?? "#"}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-sm font-medium text-charcoal underline-offset-4 transition-colors duration-500 ease-luxe hover:text-gold-ink hover:underline"
                  >
                    {sourceHost}
                    <ArrowUpRight className="h-3 w-3" strokeWidth={1.5} aria-hidden />
                  </a>
                </dd>
              </div>
            )}
          </dl>

          {item.topicSlugs.length > 0 && (
            <div className="mt-8 flex flex-wrap gap-x-6 gap-y-3 border-t border-charcoal/15 pt-6">
              {item.topicSlugs.map((t) => (
                <span
                  key={t}
                  className="border-b border-charcoal/15 pb-1 text-[10px] uppercase tracking-[0.25em] text-warm-grey"
                >
                  {t}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Footer actions — for films the primary action is the inline player;
            the external link stays as a quiet attribution escape-hatch. */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-t border-charcoal/10 px-6 py-5 md:px-8">
          {item.type === "video" ? (
            <a
              href={item.url}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-[10px] uppercase tracking-[0.25em] text-warm-grey underline-offset-4 transition-colors duration-500 ease-luxe hover:text-gold-ink hover:underline"
            >
              Watch at Source — YouTube
              <ArrowUpRight className="h-3 w-3" strokeWidth={1.5} aria-hidden />
            </a>
          ) : (
            <LuxeButton href={item.url} target="_blank" rel="noopener noreferrer" size="sm">
              Read at Source
            </LuxeButton>
          )}
          <div className="flex items-center gap-7">
            <CopyLink item={item} />
            <SaveToggle item={item} />
            <button
              type="button"
              onClick={onClose}
              className="text-xs uppercase tracking-[0.25em] text-warm-grey underline-offset-8 transition-colors duration-500 ease-luxe hover:text-gold-ink hover:underline"
            >
              Close
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

/**
 * Copy the dispatch's canonical deep link — the ?item=<id> URL, since the
 * address bar itself gets cleaned the moment the modal opens. Clipboard
 * API first, textarea fallback beneath; the label itself confirms, so
 * the feedback is honest even when the clipboard is denied.
 */
function CopyLink({ item }: { item: ItemDTO }) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    const url = `${window.location.origin}/?item=${item.id}`;
    try {
      await navigator.clipboard.writeText(url);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = url;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  return (
    <button
      type="button"
      onClick={() => void copy()}
      className={cn(
        "inline-flex items-center gap-2 text-xs uppercase tracking-[0.25em] transition-colors duration-500 ease-luxe hover:text-gold-ink",
        copied ? "text-gold-ink" : "text-warm-grey"
      )}
    >
      {copied ? (
        <Check className="h-3.5 w-3.5" strokeWidth={1.5} aria-hidden />
      ) : (
        <Link2 className="h-3.5 w-3.5" strokeWidth={1.5} aria-hidden />
      )}
      <span aria-live="polite">{copied ? "Copied" : "Copy link"}</span>
    </button>
  );
}

/** Save / unsave the open dispatch — gold mark, optimistic through the session. */
function SaveToggle({ item }: { item: ItemDTO }) {
  const { savedIds, toggleSave } = useSession();
  const saved = savedIds.has(item.id);
  return (
    <button
      type="button"
      aria-pressed={saved}
      onClick={() => void toggleSave(item)}
      className={cn(
        "inline-flex items-center gap-2 text-xs uppercase tracking-[0.25em] transition-colors duration-500 ease-luxe hover:text-gold-ink",
        saved ? "text-gold-ink" : "text-warm-grey"
      )}
    >
      <Bookmark
        className="h-3.5 w-3.5"
        strokeWidth={1.5}
        fill={saved ? "currentColor" : "none"}
        aria-hidden
      />
      {saved ? "Saved" : "Save dispatch"}
    </button>
  );
}

/**
 * The Brief — fetches the AI-distilled gist for this dispatch and renders it
 * with the important details. Until it arrives (or if it never does) the raw
 * wire snippet keeps the panel substantive. Remounted per item via `key`.
 */
function BriefSection({ item }: { item: ItemDTO }) {
  const [data, setData] = useState<StoryBriefDTO | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let cancelled = false;
    fetch(`/api/brief?id=${encodeURIComponent(item.id)}`, {
      signal: AbortSignal.timeout(45_000),
    })
      .then((res) => (res.ok ? res.json() : Promise.reject(new Error(String(res.status)))))
      .then((json: StoryBriefDTO) => {
        if (cancelled) return;
        if (json?.brief) setData(json);
        else setFailed(true);
      })
      .catch(() => {
        if (!cancelled) setFailed(true);
      });
    return () => {
      cancelled = true;
    };
  }, [item.id]);

  if (data) {
    return (
      <div className="brief-in mt-6" aria-live="polite">
        <div className="flex items-center gap-3">
          <span aria-hidden className="h-px w-6 bg-gold" />
          <span className="text-[10px] font-medium uppercase tracking-[0.25em] text-charcoal">
            The Brief
          </span>
        </div>

        <p className="drop-cap mt-5 text-[15px] leading-relaxed text-charcoal">
          {data.brief}
        </p>

        {data.keyPoints.length > 0 && (
          <div className="mt-7">
            <span className="text-[10px] uppercase tracking-[0.25em] text-warm-grey">
              Key Details
            </span>
            <ul className="mt-2 border-t border-charcoal/10">
              {data.keyPoints.map((point, i) => (
                <li
                  key={i}
                  className="flex items-start gap-4 border-b border-charcoal/10 py-3.5 last:border-b-0"
                >
                  <span aria-hidden className="mt-[9px] h-px w-4 shrink-0 bg-gold" />
                  <p className="text-sm leading-relaxed text-warm-grey">{point}</p>
                </li>
              ))}
            </ul>
          </div>
        )}

        <p className="mt-5 text-[10px] uppercase tracking-[0.2em] text-warm-grey/50">
          Distilled from the full story — read at source for complete context
        </p>
      </div>
    );
  }

  return (
    <div className="mt-6">
      {item.snippet && (
        <p className="drop-cap text-base leading-relaxed text-warm-grey">
          {item.snippet}
        </p>
      )}
      {!failed && (
        <div className="mt-7" aria-live="polite" aria-label="Composing the brief">
          <div className="flex items-center gap-2.5">
            <span aria-hidden className="brief-pulse inline-block h-1 w-1 bg-gold" />
            <span className="text-[10px] uppercase tracking-[0.25em] text-warm-grey/70">
              Composing the brief
            </span>
          </div>
          <div className="mt-4 space-y-3">
            <div className="h-2 w-11/12 animate-pulse bg-taupe" />
            <div className="h-2 w-full animate-pulse bg-taupe" />
            <div className="h-2 w-4/5 animate-pulse bg-taupe" />
          </div>
        </div>
      )}
    </div>
  );
}

function Spec({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-[10px] uppercase tracking-[0.25em] text-warm-grey">{label}</dt>
      <dd className="mt-1 text-sm font-medium text-charcoal">{value}</dd>
    </div>
  );
}
