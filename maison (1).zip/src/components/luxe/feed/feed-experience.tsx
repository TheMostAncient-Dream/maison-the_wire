"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { RefreshCw, Search } from "lucide-react";
import { Em, Overline, VerticalLabel } from "@/components/luxe/atoms";
import { LuxeButton } from "@/components/luxe/luxe-button";
import type { ItemDTO, StatusDTO, TopicDTO } from "@/lib/types";
import { cn } from "@/lib/utils";
import { ItemCard } from "./item-card";
import { timeAgo } from "./utils";

const PAGE_SIZE = 18;

type Sort = "newest" | "trending" | "source";
const SORTS: { value: Sort; label: string }[] = [
  { value: "newest", label: "Newest" },
  { value: "trending", label: "Trending" },
  { value: "source", label: "By Source" },
];
const TYPES = [
  { value: "", label: "All" },
  { value: "article", label: "Articles" },
  { value: "video", label: "Films" },
];
const WINDOWS = [
  { value: "", label: "Any time" },
  { value: "1", label: "24 hours" },
  { value: "7", label: "7 days" },
  { value: "30", label: "30 days" },
];
const COUNTRIES = ["US", "UK", "CA", "IN", "QA", "JP", "HK", "DE", "FR", "NL", "TR", "EU"];
const LANGUAGES = ["en", "de", "fr", "es", "pt", "it", "hi", "ar", "ru", "ja", "zh"];

interface SourceFilter {
  slug: string;
  name: string;
}

/**
 * The Wire — the whole feed: search, topic chips, sort & type filters,
 * editorial grid with pagination. The ingestion scheduler keeps the
 * database current; this view notices new arrivals on a quiet 60s poll
 * and folds them in — instantly when you're at the top of the page,
 * otherwise via a bottom-of-screen summons that never moves your place.
 */
export function FeedExperience() {
  const [topics, setTopics] = useState<TopicDTO[]>([]);
  const [status, setStatus] = useState<StatusDTO | null>(null);
  const [items, setItems] = useState<ItemDTO[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [q, setQ] = useState("");
  const [debouncedQ, setDebouncedQ] = useState("");
  const [topic, setTopic] = useState("");
  const [type, setType] = useState("");
  const [sort, setSort] = useState<Sort>("newest");
  const [source, setSource] = useState<SourceFilter | null>(null);
  const [country, setCountry] = useState("");
  const [language, setLanguage] = useState("");
  const [sinceDays, setSinceDays] = useState("");
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState(false);
  const [pending, setPending] = useState<ItemDTO[]>([]);

  /* Mirrors of state for the polling interval (stays closure-fresh). */
  const viewRef = useRef({ items, total, sort, debouncedQ, topic, type, source, country, language, sinceDays, page });
  useEffect(() => {
    viewRef.current = { items, total, sort, debouncedQ, topic, type, source, country, language, sinceDays, page };
  }, [items, total, sort, debouncedQ, topic, type, source, country, language, sinceDays, page]);

  /* Topics + status, once. */
  useEffect(() => {
    fetch("/api/topics")
      .then((r) => r.json())
      .then((d: TopicDTO[]) => setTopics(d))
      .catch(() => {});
    fetch("/api/status")
      .then((r) => r.json())
      .then((d: StatusDTO) => setStatus(d))
      .catch(() => {});
  }, []);

  /* Quiet status refresh — keeps the masthead honest. */
  useEffect(() => {
    const t = setInterval(() => {
      fetch("/api/status")
        .then((r) => r.json())
        .then((d: StatusDTO) => setStatus(d))
        .catch(() => {});
    }, 90_000);
    return () => clearInterval(t);
  }, []);

  /* New-arrival watch — a quiet poll of the newest page; fresh ids are
     folded straight in when the reader sits at the top of a default
     view, otherwise counted for the summons bar. */
  useEffect(() => {
    const check = async () => {
      if (document.hidden) return;
      try {
        const res = await fetch("/api/content?sort=newest&page=1&pageSize=12");
        if (!res.ok) return;
        const data = (await res.json()) as { items: ItemDTO[] };
        const known = new Set([
          ...viewRef.current.items.map((i) => i.id),
          ...pending.map((i) => i.id),
        ]);
        const fresh = data.items.filter((i) => !known.has(i.id));
        if (fresh.length === 0) return;
        const v = viewRef.current;
        const atTop = window.scrollY < 120;
        const defaultView =
          v.sort === "newest" && !v.debouncedQ && !v.topic && !v.type &&
          !v.source && !v.country && !v.language && !v.sinceDays && v.page === 1;
        if (defaultView && atTop) {
          setItems((prev) => [...fresh, ...prev]);
          setTotal((t) => t + fresh.length);
        } else {
          setPending((prev) => {
            const seen = new Set(prev.map((i) => i.id));
            return [...fresh.filter((i) => !seen.has(i.id)), ...prev].slice(0, 30);
          });
        }
      } catch {
        /* the wire retries on its own cadence */
      }
    };
    const t = setInterval(check, 60_000);
    const onVisible = () => {
      if (!document.hidden) void check();
    };
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      clearInterval(t);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, []);

  /* The Sources directory can aim the wire at one publisher. */
  useEffect(() => {
    const onSourceFilter = (e: Event) => {
      const detail = (e as CustomEvent<SourceFilter | null>).detail ?? null;
      setSource(detail);
    };
    window.addEventListener("maison:source-filter", onSourceFilter);
    return () => window.removeEventListener("maison:source-filter", onSourceFilter);
  }, []);

  /* Debounce the search field. */
  useEffect(() => {
    const t = setTimeout(() => setDebouncedQ(q.trim()), 450);
    return () => clearTimeout(t);
  }, [q]);

  const load = useCallback(
    async (targetPage: number, append: boolean) => {
      if (append) setLoadingMore(true);
      else {
        setLoading(true);
        setError(false);
      }
      try {
        const params = new URLSearchParams({
          sort,
          page: String(targetPage),
          pageSize: String(PAGE_SIZE),
        });
        if (debouncedQ) params.set("q", debouncedQ);
        if (topic) params.set("topic", topic);
        if (type) params.set("type", type);
        if (source) params.set("source", source.slug);
        if (country) params.set("country", country);
        if (language) params.set("language", language);
        if (sinceDays) {
          const d = new Date(Date.now() - Number(sinceDays) * 86_400_000);
          params.set("since", d.toISOString());
        }
        const res = await fetch(`/api/content?${params.toString()}`);
        if (!res.ok) throw new Error("bad response");
        const data = (await res.json()) as { items: ItemDTO[]; total: number };
        setTotal(data.total);
        setItems((prev) => (append ? [...prev, ...data.items] : data.items));
        setPage(targetPage);
        if (!append) setPending([]); // a page-one refetch already carries the arrivals
      } catch {
        if (!append) setError(true);
      } finally {
        setLoading(false);
        setLoadingMore(false);
      }
    },
    [sort, debouncedQ, topic, type, source, country, language, sinceDays]
  );

  /* Any filter change rewinds to page one. */
  useEffect(() => {
    let cancelled = false;
    queueMicrotask(() => {
      if (!cancelled) load(1, false);
    });
    return () => {
      cancelled = true;
    };
  }, [load]);

  const resetAll = () => {
    setQ("");
    setTopic("");
    setType("");
    setSort("newest");
    setSource(null);
    setCountry("");
    setLanguage("");
    setSinceDays("");
  };

  /* Fold the counted arrivals into view — prepend in the default view
     (and glide back up so they're seen), otherwise simply re-render the
     current view from the freshest data. */
  const acceptPending = () => {
    const v = viewRef.current;
    const arriving = pending;
    setPending([]);
    const defaultView =
      v.sort === "newest" && !v.debouncedQ && !v.topic && !v.type &&
      !v.source && !v.country && !v.language && !v.sinceDays && v.page === 1;
    if (defaultView) {
      const seen = new Set(v.items.map((i) => i.id));
      const fresh = arriving.filter((i) => !seen.has(i.id));
      if (fresh.length > 0) {
        setItems((prev) => [...fresh, ...prev]);
        setTotal((t) => t + fresh.length);
      }
      document.getElementById("wire")?.scrollIntoView({ behavior: "smooth", block: "start" });
    } else {
      void load(1, false);
    }
  };

  const hasMore = items.length < total;
  const filtering = Boolean(debouncedQ || topic || type || source || country || language || sinceDays);

  return (
    <section id="wire" className="relative scroll-mt-24 py-24 md:py-32">
      <VerticalLabel className="absolute left-5 top-56 hidden xl:block">
        Live — updated continuously
      </VerticalLabel>

      <div className="mx-auto max-w-[1600px] px-8 md:px-16">
        {/* Section header */}
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <div>
            <Overline className="-ml-3 md:-ml-5">The Whole Wire</Overline>
            <h2 className="mt-6 font-serif text-5xl leading-[0.95] text-charcoal md:text-7xl">
              Every story,
              <br />
              <span className="inline-block pl-[0.5em]">
                <Em>fresh from the wire.</Em>
              </span>
            </h2>
          </div>
          <p className="max-w-sm text-base leading-relaxed text-warm-grey md:pb-2 md:text-right">
            {status
              ? `${status.totalItems.toLocaleString("en-US")} dispatches from ${status.activeSources} sources — ingested continuously and set in type as they arrive.`
              : "Reading the state of the wire…"}
          </p>
        </div>

        {/* Filter bar — search / sort / type */}
        <div className="mt-14 flex flex-col gap-10 border-t border-charcoal/15 pt-10 lg:flex-row lg:items-end lg:justify-between">
          <label className="relative block w-full lg:max-w-sm">
            <span className="sr-only">Search the wire</span>
            <Search
              className="pointer-events-none absolute left-0 top-1/2 h-4 w-4 -translate-y-1/2 text-warm-grey"
              strokeWidth={1.5}
              aria-hidden
            />
            <input
              type="search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search headlines, sources, topics…"
              className="h-12 w-full border-b border-charcoal/30 bg-transparent pl-8 font-serif text-lg italic text-charcoal placeholder:font-serif placeholder:italic placeholder:text-warm-grey/60 focus:border-gold focus:outline-none transition-colors duration-500 ease-luxe"
            />
          </label>

          <div className="flex flex-wrap items-center gap-x-8 gap-y-4" role="group" aria-label="Sort order">
            {SORTS.map((s) => {
              const active = sort === s.value;
              return (
                <button
                  key={s.value}
                  type="button"
                  aria-pressed={active}
                  onClick={() => setSort(s.value)}
                  className={cn(
                    "inline-flex items-center gap-3 text-xs uppercase tracking-[0.25em] transition-colors duration-500 ease-luxe",
                    active ? "text-charcoal" : "text-warm-grey hover:text-charcoal"
                  )}
                >
                  <span
                    aria-hidden
                    className={cn(
                      "h-px bg-gold transition-all duration-500 ease-luxe",
                      active ? "w-8 opacity-100" : "w-0 opacity-0"
                    )}
                  />
                  {s.label}
                </button>
              );
            })}
          </div>

          <div className="flex flex-wrap items-center gap-x-6 gap-y-3" role="group" aria-label="Content type">
            {TYPES.map((t) => {
              const active = type === t.value;
              return (
                <button
                  key={t.value}
                  type="button"
                  aria-pressed={active}
                  onClick={() => setType(t.value)}
                  className={cn(
                    "border-b pb-1 text-[11px] uppercase tracking-[0.2em] transition-colors duration-500 ease-luxe",
                    active
                      ? "border-gold text-charcoal"
                      : "border-transparent text-warm-grey hover:text-charcoal"
                  )}
                >
                  {t.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Refinements — the remaining content-API filters, in the same quiet key */}
        <div className="mt-8 flex flex-wrap items-center gap-x-8 gap-y-4" role="group" aria-label="Refinements">
          <RefineSelect
            label="Country"
            value={country}
            onChange={setCountry}
            allLabel="All countries"
            options={COUNTRIES.map((c) => ({ value: c, label: c }))}
          />
          <RefineSelect
            label="Language"
            value={language}
            onChange={setLanguage}
            allLabel="All languages"
            options={LANGUAGES.map((l) => ({ value: l, label: l.toUpperCase() }))}
          />
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2" aria-label="Date range">
            {WINDOWS.map((w) => {
              const active = sinceDays === w.value;
              return (
                <button
                  key={w.value}
                  type="button"
                  aria-pressed={active}
                  onClick={() => setSinceDays(w.value)}
                  className={cn(
                    "border-b pb-1 text-[11px] uppercase tracking-[0.2em] transition-colors duration-500 ease-luxe",
                    active
                      ? "border-gold text-charcoal"
                      : "border-transparent text-warm-grey hover:text-charcoal"
                  )}
                >
                  {w.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Topic chips — plus the pinned-source chip when one is aimed */}
        <div className="no-scrollbar mt-10 flex gap-x-7 gap-y-3 overflow-x-auto pb-2 md:flex-wrap">
          {source && (
            <button
              type="button"
              onClick={() => setSource(null)}
              aria-label={`Clear source filter ${source.name}`}
              className="whitespace-nowrap border-b border-gold pb-2 text-xs uppercase tracking-[0.2em] text-charcoal transition-colors duration-500 ease-luxe hover:text-gold-ink"
            >
              {source.name} — clear ×
            </button>
          )}
          <button
            type="button"
            aria-pressed={topic === ""}
            onClick={() => setTopic("")}
            className={cn(
              "whitespace-nowrap border-b pb-2 text-xs uppercase tracking-[0.2em] transition-colors duration-500 ease-luxe",
              topic === ""
                ? "border-gold text-charcoal"
                : "border-charcoal/15 text-warm-grey hover:border-charcoal/40 hover:text-charcoal"
            )}
          >
            All Desks
          </button>
          {topics.map((t) => {
            const active = topic === t.slug;
            return (
              <button
                key={t.slug}
                type="button"
                aria-pressed={active}
                onClick={() => setTopic(active ? "" : t.slug)}
                className={cn(
                  "whitespace-nowrap border-b pb-2 text-xs uppercase tracking-[0.2em] transition-colors duration-500 ease-luxe",
                  active
                    ? "border-gold text-charcoal"
                    : "border-charcoal/15 text-warm-grey hover:border-charcoal/40 hover:text-charcoal"
                )}
              >
                {t.name}
              </button>
            );
          })}
        </div>

        {/* Status / count line */}
        <div className="mt-10 flex flex-wrap items-center justify-between gap-4 text-[10px] uppercase tracking-[0.25em] text-warm-grey">
          <span>
            {loading
              ? "Setting type…"
              : `Showing ${items.length.toLocaleString("en-US")} of ${total.toLocaleString("en-US")} dispatches`}
          </span>
          <div className="flex items-center gap-6">
            {status?.lastUpdated && (
              <span className="hidden sm:inline">
                Wire refreshed {timeAgo(status.lastUpdated)}
              </span>
            )}
            <button
              type="button"
              onClick={() => load(1, false)}
              className="inline-flex items-center gap-2 transition-colors duration-500 ease-luxe hover:text-gold-ink"
            >
              <RefreshCw className="h-3 w-3" strokeWidth={1.5} aria-hidden />
              Refresh
            </button>
          </div>
        </div>

        {/* New-arrival summons — fixed, so it follows the reader */}
        {pending.length > 0 && !loading && (
          <button
            type="button"
            onClick={acceptPending}
            className="overlay-in group fixed bottom-8 left-1/2 z-40 inline-flex -translate-x-1/2 items-center gap-4 rounded-media border border-charcoal/15 bg-alabaster px-6 py-3.5 shadow-[0_12px_36px_rgba(0,0,0,0.10)] transition-colors duration-500 ease-luxe hover:border-gold focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-charcoal"
          >
            <span aria-hidden className="h-1.5 w-1.5 animate-pulse bg-gold" />
            <span className="whitespace-nowrap text-[10px] uppercase tracking-[0.25em] text-charcoal">
              {pending.length} new {pending.length === 1 ? "dispatch" : "dispatches"} on the wire
            </span>
            <span
              aria-hidden
              className="h-px w-6 bg-charcoal/30 transition-all duration-500 ease-luxe group-hover:w-10 group-hover:bg-gold"
            />
            <span className="whitespace-nowrap text-[10px] uppercase tracking-[0.25em] text-warm-grey transition-colors duration-500 ease-luxe hover:text-charcoal">
              Set {pending.length === 1 ? "it" : "them"} in type
            </span>
          </button>
        )}

        {/* Grid */}
        {error ? (
          <div className="mt-20 flex flex-col items-center border-t border-charcoal/15 py-24 text-center">
            <p className="font-serif text-4xl italic text-charcoal">
              The wire hiccuped.
            </p>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-warm-grey">
              Something interrupted the transmission — try again, the presses
              rarely stop twice.
            </p>
            <button
              type="button"
              onClick={() => load(1, false)}
              className="mt-8 text-xs uppercase tracking-[0.25em] text-warm-grey underline-offset-8 transition-colors duration-500 ease-luxe hover:text-gold-ink hover:underline"
            >
              Retry the wire
            </button>
          </div>
        ) : loading ? (
          <SkeletonGrid />
        ) : items.length === 0 ? (
          <div className="mt-20 flex flex-col items-center border-t border-charcoal/15 py-24 text-center">
            <p className="font-serif text-4xl italic text-charcoal">
              Nothing on the wire.
            </p>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-warm-grey">
              No dispatches match this view — loosen the filters and the
              presses will oblige.
            </p>
            <button
              type="button"
              onClick={resetAll}
              className="mt-8 text-xs uppercase tracking-[0.25em] text-warm-grey underline-offset-8 transition-colors duration-500 ease-luxe hover:text-gold-ink hover:underline"
            >
              Reset the wire
            </button>
          </div>
        ) : (
          <div className="mt-14 grid grid-flow-dense grid-cols-1 gap-x-8 gap-y-16 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {items.map((item, i) => (
              <ItemCard
                key={item.id}
                item={item}
                lead={i === 0 || i === 7}
                delay={(i % 4) * 110}
              />
            ))}
          </div>
        )}

        {/* Pagination footer */}
        {!loading && items.length > 0 && (
          <div className="mt-24 flex flex-col items-center gap-6">
            {hasMore && (
              <LuxeButton
                variant="secondary"
                size="lg"
                onClick={() => load(page + 1, true)}
                disabled={loadingMore}
              >
                {loadingMore ? "Setting more type…" : "Load More Dispatches"}
              </LuxeButton>
            )}
            <p className="text-[10px] uppercase tracking-[0.25em] text-warm-grey">
              {hasMore
                ? `${items.length.toLocaleString("en-US")} of ${total.toLocaleString("en-US")}`
                : "End of the wire — for now"}
            </p>
          </div>
        )}
      </div>
    </section>
  );
}

function SkeletonGrid() {
  return (
    <div
      aria-hidden
      className="mt-14 grid grid-cols-1 gap-x-8 gap-y-16 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
    >
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} className="border-t border-charcoal/15 pt-6">
          <div className="aspect-[3/4] w-full animate-pulse bg-taupe/50" />
          <div className="mt-6 h-2.5 w-1/3 animate-pulse bg-taupe/70" />
          <div className="mt-4 h-5 w-full animate-pulse bg-taupe/70" />
          <div className="mt-2 h-5 w-2/3 animate-pulse bg-taupe/70" />
        </div>
      ))}
    </div>
  );
}

/** Quiet underline select — native for accessibility, dressed in the filter key. */
function RefineSelect({
  label,
  value,
  onChange,
  options,
  allLabel,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
  allLabel: string;
}) {
  return (
    <label className="inline-flex items-baseline gap-2.5 text-[11px] uppercase tracking-[0.2em] text-warm-grey">
      <span>{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="cursor-pointer border-b border-charcoal/30 bg-transparent pb-1 pr-1 text-[11px] uppercase tracking-[0.2em] text-charcoal transition-colors duration-500 ease-luxe focus:border-gold focus:outline-none"
      >
        <option value="">{allLabel}</option>
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </label>
  );
}
