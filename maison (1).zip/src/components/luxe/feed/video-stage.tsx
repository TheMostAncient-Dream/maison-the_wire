"use client";

import { useState } from "react";
import { Play } from "lucide-react";
import type { ItemDTO } from "@/lib/types";
import { SmartThumb } from "./smart-thumb";
import { extractYouTubeId, formatDuration } from "./utils";

/**
 * Inline film stage for the dispatch modal: the grayscale→colour still
 * carries a centred gold play glyph; only a click mounts the YouTube
 * nocookie iframe, so feeds and modal opens never eagerly load embeds.
 * When the video id can't be parsed the stage degrades to a plain still
 * (the modal footer's external link remains the way in for that item).
 */
export function VideoStage({ item }: { item: ItemDTO }) {
  const videoId = extractYouTubeId(item.url);
  const [playing, setPlaying] = useState(false);
  const [imgOk, setImgOk] = useState(true);
  const hasThumb = Boolean(item.thumbnailUrl) && imgOk;

  /* Re-arm still/play state when a different film is opened
     (adjust-state-during-render — no effect needed). */
  const [prevItemId, setPrevItemId] = useState(item.id);
  if (prevItemId !== item.id) {
    setPrevItemId(item.id);
    setImgOk(true);
    setPlaying(false);
  }

  const slot =
    "rounded-panel relative aspect-[16/9] overflow-hidden bg-taupe shadow-[0_8px_32px_rgba(0,0,0,0.12)]";

  if (playing && videoId) {
    return (
      <div className={`group mb-8 border border-charcoal/10 ${slot}`}>
        <iframe
          src={`https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&rel=0`}
          title={item.title}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
          className="absolute inset-0 h-full w-full"
        />
      </div>
    );
  }

  if (hasThumb) {
    return (
      <div className="group mb-8">
        <div className={slot}>
          <SmartThumb
            src={item.thumbnailUrl ?? ""}
            onDead={() => setImgOk(false)}
            className="absolute inset-0 h-full w-full object-cover grayscale transition-all duration-[1600ms] ease-luxe group-hover:scale-[1.03] group-hover:grayscale-0"
          />
          {videoId && <PlayGlyph onPlay={() => setPlaying(true)} />}
          <span className="absolute bottom-4 left-4 inline-flex items-center gap-2 bg-charcoal/85 px-3 py-1.5 text-[10px] uppercase tracking-[0.2em] text-alabaster">
            {item.durationSec ? formatDuration(item.durationSec) : "Film"}
          </span>
        </div>
      </div>
    );
  }

  /* No still available — an editorial plate keeps the slot and the play
     affordance so inline playback stays reachable. */
  const monogram = (item.source.name.match(/[a-z]/i)?.[0] ?? "M").toUpperCase();
  return (
    <div className="group mb-8">
      <div className="rounded-media relative flex items-center justify-center border border-charcoal/10 bg-taupe/60 shadow-[0_8px_32px_rgba(0,0,0,0.08)] aspect-[16/9] overflow-hidden">
        <span
          aria-hidden
          className="select-none font-serif text-[7rem] leading-none text-charcoal/10 transition-colors duration-700 ease-luxe group-hover:text-charcoal/15"
        >
          {monogram}
        </span>
        <span className="absolute bottom-3 left-4 text-[9px] uppercase tracking-[0.3em] text-warm-grey/60">
          {item.source.name}
        </span>
        {videoId && <PlayGlyph onPlay={() => setPlaying(true)} />}
        <span className="absolute top-4 right-4 inline-flex items-center gap-2 bg-charcoal/85 px-3 py-1.5 text-[10px] uppercase tracking-[0.2em] text-alabaster">
          {item.durationSec ? formatDuration(item.durationSec) : "Film"}
        </span>
      </div>
    </div>
  );
}

/** Centred play affordance — hairline plate, gold on hover, eased corners. */
function PlayGlyph({ onPlay }: { onPlay: () => void }) {
  return (
    <button
      type="button"
      onClick={onPlay}
      aria-label="Play film"
      className="absolute inset-0 z-10 flex items-center justify-center focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-gold"
    >
      <span className="rounded-media flex h-20 w-20 items-center justify-center border border-alabaster/50 bg-charcoal/45 backdrop-blur-[2px] transition-all duration-700 ease-luxe hover:border-gold hover:bg-charcoal/60">
        <Play
          className="h-7 w-7 translate-x-[2px] text-alabaster transition-colors duration-500 ease-luxe hover:text-gold"
          fill="currentColor"
          strokeWidth={1}
          aria-hidden
        />
      </span>
    </button>
  );
}
