"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";

/**
 * Self-healing thumbnail. Some publisher CDNs answer hot-linked <img>
 * requests with 403; when the direct load fails we transparently retry
 * through our own /api/img proxy, and only give up (rendering nothing)
 * if even the proxy can't fetch it. The parent keeps the taupe plate
 * visible either way, so the grid rhythm never breaks.
 */
export function SmartThumb({
  src,
  alt = "",
  className,
  onDead,
  loading = "lazy",
  fetchPriority,
}: {
  src: string;
  alt?: string;
  className?: string;
  onDead?: () => void;
  loading?: "lazy" | "eager";
  fetchPriority?: "high" | "low" | "auto";
}) {
  const [stage, setStage] = useState<"direct" | "proxy" | "dead">("direct");

  if (!src || stage === "dead") return null;

  const url =
    stage === "direct" ? src : `/api/img?u=${encodeURIComponent(src)}`;

  return (
    <img
      src={url}
      alt={alt}
      loading={loading}
      fetchPriority={fetchPriority}
      decoding="async"
      onError={() => {
        if (stage === "direct") setStage("proxy");
        else {
          setStage("dead");
          onDead?.();
        }
      }}
      className={cn(className)}
    />
  );
}
