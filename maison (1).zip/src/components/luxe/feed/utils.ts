/** Formatting helpers shared by the feed components. */

export function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60_000);
  if (m < 1) return "Just now";
  if (m < 60) return `${m} min ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} hr${h > 1 ? "s" : ""} ago`;
  const d = Math.floor(h / 24);
  if (d < 7) return `${d} day${d > 1 ? "s" : ""} ago`;
  return new Date(iso).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
  });
}

export function formatDuration(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
}

/** Human label for the item's primary topic slug. */
export function primaryTopicLabel(item: { topicSlugs: string[] }): string {
  const slug = item.topicSlugs[0];
  if (!slug) return "Dispatch";
  return slug.charAt(0).toUpperCase() + slug.slice(1);
}

/** Distinct source names behind a cluster, for editorial kickers. */
export function uniqueSources(items: { source: { name: string } }[]): string {
  const names = [...new Set(items.map((i) => i.source.name))];
  const head = names.slice(0, 3).join(" · ");
  return names.length > 3 ? `${head} …` : head;
}

/**
 * Pull the 11-character YouTube video id out of any URL shape the
 * ingestion pipeline may have stored (watch?v=, youtu.be, /embed/,
 * /shorts/, /live/). Returns null when the id can't be parsed —
 * callers fall back to external-link behaviour for that item.
 */
export function extractYouTubeId(url: string | null | undefined): string | null {
  if (!url) return null;
  let u: URL;
  try {
    u = new URL(url);
  } catch {
    return null;
  }
  const host = u.hostname.replace(/^www\.|^m\./, "").toLowerCase();
  const id = (() => {
    if (host === "youtu.be") return u.pathname.slice(1).split("/")[0] ?? "";
    if (host === "youtube.com" || host === "youtube-nocookie.com") {
      const v = u.searchParams.get("v");
      if (v) return v;
      const m = u.pathname.match(/\/(?:embed|shorts|live|v)\/([\w-]{11})/);
      return m?.[1] ?? "";
    }
    return "";
  })();
  return /^[\w-]{11}$/.test(id) ? id : null;
}
