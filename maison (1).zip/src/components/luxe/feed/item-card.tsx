"use client";

import { useState, type CSSProperties } from "react";
import { Bookmark, Play } from "lucide-react";
import type { ItemDTO } from "@/lib/types";
import { cn } from "@/lib/utils";
import { useSession } from "@/components/luxe/session/session-provider";
import { useReveal } from "@/components/luxe/reveal";
import { Rule } from "@/components/luxe/rule";
import { ItemTrigger } from "./news-modal";
import { SmartThumb } from "./smart-thumb";
import { formatDuration, primaryTopicLabel, timeAgo } from "./utils";

/**
 * One dispatch, set as an editorial card: hairline top border, grayscale
 * image that slowly develops colour on hover, kicker + serif headline.
 * `lead` doubles its width and deepens the type scale (grids that can
 * absorb the span); `featured` deepens the scale only — for the opening
 * slot of a column, where a span would break the narrow grid.
 * Every card also sets itself into type — a slow reveal as it enters the
 * viewport (stagger with `delay`, e.g. (i % 4) * 110 across a grid row).
 */
export function ItemCard({
  item,
  lead = false,
  featured = false,
  delay = 0,
}: {
  item: ItemDTO;
  lead?: boolean;
  featured?: boolean;
  delay?: number;
}) {
  const [imgOk, setImgOk] = useState(true);
  const { ref, visible } = useReveal<HTMLElement>();
  const hasThumb = Boolean(item.thumbnailUrl) && imgOk;
  const scale = lead || featured;
  const aspect = scale ? "aspect-[16/10]" : "aspect-[3/4]";
  const monogram = (item.source.name.match(/[a-z]/i)?.[0] ?? "M").toUpperCase();
  const { savedIds, toggleSave } = useSession();
  const saved = savedIds.has(item.id);

  return (
    <article
      ref={ref}
      style={delay ? ({ "--reveal-delay": `${delay}ms` } as CSSProperties) : undefined}
      className={cn(
        "group reveal relative ease-luxe hover:bg-taupe/25",
        visible && "is-visible",
        lead && "sm:col-span-2"
      )}
    >
      {/* The card is drawn by its rule — which every so often
          refuses to sit straight. */}
      <Rule className="h-px bg-charcoal/60" />
      <div className="pt-6">
      <ItemTrigger
        item={item}
        ariaLabel={`Details: ${item.title}`}
        className="block w-full overflow-hidden text-left"
      >
        {hasThumb ? (
          <div
            className={cn(
              "rounded-media relative overflow-hidden bg-taupe shadow-[0_2px_8px_rgba(0,0,0,0.02)] transition-shadow duration-700 ease-luxe group-hover:shadow-[0_8px_24px_rgba(0,0,0,0.06)]",
              aspect
            )}
          >
            <SmartThumb
              src={item.thumbnailUrl ?? ""}
              onDead={() => setImgOk(false)}
              className="h-full w-full object-cover grayscale transition-all duration-[1600ms] ease-luxe group-hover:scale-[1.04] group-hover:grayscale-0"
            />
            {item.type === "video" && (
              <span className="absolute bottom-4 left-4 inline-flex items-center gap-2 bg-charcoal/85 px-3 py-1.5 text-[10px] uppercase tracking-[0.2em] text-alabaster">
                <Play className="h-3 w-3" strokeWidth={1.5} aria-hidden />
                {item.durationSec ? formatDuration(item.durationSec) : "Film"}
              </span>
            )}
          </div>
        ) : (
          /* No artwork (yet) — an editorial monogram plate keeps the rhythm */
          <div
            className={cn(
              "rounded-media relative flex items-center justify-center overflow-hidden border border-charcoal/10 bg-taupe/60 transition-colors duration-700 ease-luxe group-hover:bg-taupe",
              aspect
            )}
          >
            <span
              aria-hidden
              className={cn(
                "select-none font-serif leading-none text-charcoal/10 transition-colors duration-700 ease-luxe group-hover:text-charcoal/15",
                scale ? "text-[7rem] md:text-[9rem]" : "text-7xl"
              )}
            >
              {monogram}
            </span>
            <span className="absolute bottom-3 left-4 text-[9px] uppercase tracking-[0.3em] text-warm-grey/60">
              {item.source.name}
            </span>
            {item.type === "video" && (
              <span className="absolute bottom-4 left-4 inline-flex items-center gap-2 bg-charcoal/85 px-3 py-1.5 text-[10px] uppercase tracking-[0.2em] text-alabaster">
                <Play className="h-3 w-3" strokeWidth={1.5} aria-hidden />
                {item.durationSec ? formatDuration(item.durationSec) : "Film"}
              </span>
            )}
          </div>
        )}
      </ItemTrigger>

      {/* The gold mark — saves the dispatch (guests are invited to sign in).
          A sibling of the trigger, so the two buttons never nest. */}
      <button
        type="button"
        aria-pressed={saved}
        aria-label={saved ? `Remove ${item.title} from saved` : `Save ${item.title}`}
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          void toggleSave(item);
        }}
        className={cn(
          "absolute right-2 top-8 z-10 flex h-8 w-8 items-center justify-center rounded-media bg-charcoal/40 backdrop-blur-[2px] transition-all duration-500 ease-luxe hover:bg-charcoal/60 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-gold",
          saved ? "text-gold" : "text-alabaster/85 hover:text-gold"
        )}
      >
        <Bookmark
          className="h-4 w-4"
          strokeWidth={1.5}
          fill={saved ? "currentColor" : "none"}
          aria-hidden
        />
      </button>

      {/* Kicker row — source (gold on hover) + recency */}
      <div className="mt-6 flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
        <span className="text-[10px] font-medium uppercase tracking-[0.25em] text-warm-grey transition-colors duration-500 ease-luxe group-hover:text-gold-ink">
          {item.source.name}
        </span>
        <span className="whitespace-nowrap text-[10px] uppercase tracking-[0.2em] text-warm-grey/60">
          {timeAgo(item.publishedAt)}
        </span>
      </div>

      <h3
        className={cn(
          "mt-3 font-serif leading-[1.15] text-charcoal",
          scale ? "text-2xl md:text-3xl" : "text-xl"
        )}
      >
        <ItemTrigger
          item={item}
          className="text-left transition-colors duration-500 ease-luxe hover:text-gold-ink"
        >
          {item.title}
        </ItemTrigger>
      </h3>

      {item.snippet && (
        <p
          className={cn(
            "mt-3 text-sm leading-relaxed text-warm-grey",
            scale ? "line-clamp-4" : "line-clamp-2"
          )}
        >
          {item.snippet}
        </p>
      )}

      <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1 text-[10px] uppercase tracking-[0.2em] text-warm-grey/70">
        <span>{item.type === "video" ? "Film" : "Article"}</span>
        {item.topicSlugs[0] && (
          <>
            <span aria-hidden className="h-px w-4 bg-charcoal/30" />
            <span>{primaryTopicLabel(item)}</span>
          </>
        )}
      </div>
      </div>
    </article>
  );
}
