"use client";

import { cn } from "@/lib/utils";
import { useEffect, useRef, useState, type ReactNode } from "react";

/**
 * Visible editorial grid — four fixed vertical lines aligned with the
 * 12-column container edges and middle thirds, at whisper opacity.
 * The lines belong to the opening view: they fade out once the reader
 * scrolls past the front page (IntersectionObserver on #front-page),
 * so grids/columns/sources/admin get their content back without the
 * fixed scaffolding competing behind it. Desktop only.
 */
export function GridLines() {
  const [pastFrontPage, setPastFrontPage] = useState(false);
  const sentinel = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const target = document.getElementById("front-page") ?? sentinel.current;
    if (!target) return;
    const io = new IntersectionObserver(
      ([entry]) => setPastFrontPage(!entry.isIntersecting),
      { rootMargin: "-10% 0px 0px 0px" }
    );
    io.observe(target);
    return () => io.disconnect();
  }, []);

  return (
    <div
      aria-hidden
      ref={sentinel}
      className={cn(
        "pointer-events-none fixed inset-0 z-0 hidden transition-opacity duration-[1600ms] ease-luxe md:block",
        pastFrontPage ? "opacity-0" : "opacity-100"
      )}
    >
      <div className="mx-auto h-full max-w-[1600px] px-16">
        <div className="relative h-full">
          <span className="absolute left-0 top-0 h-full w-px bg-charcoal/8" />
          <span className="absolute left-1/3 top-0 h-full w-px bg-charcoal/5" />
          <span className="absolute left-2/3 top-0 h-full w-px bg-charcoal/5" />
          <span className="absolute left-full top-0 h-full w-px bg-charcoal/8" />
        </div>
      </div>
    </div>
  );
}

/** Paper grain overlay — SVG fractal noise at ~3% opacity across the page. */
export function NoiseOverlay() {
  return <div aria-hidden className="noise-overlay" />;
}

/**
 * Vertical side label (writing-mode: vertical-rl), desktop only.
 * Position it absolutely against a parent with `relative`.
 */
export function VerticalLabel({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <span
      aria-hidden
      className={cn(
        "writing-vertical text-[10px] font-medium uppercase tracking-[0.3em] text-warm-grey",
        className
      )}
    >
      {children}
    </span>
  );
}

/**
 * Overline label preceded by a short decorative horizontal line —
 * the signature editorial kicker.
 */
export function Overline({
  children,
  tone = "light",
  className,
}: {
  children: ReactNode;
  tone?: "light" | "dark";
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-4 text-xs font-medium uppercase tracking-[0.25em]",
        tone === "light" ? "text-warm-grey" : "text-alabaster/60",
        className
      )}
    >
      <span aria-hidden className="h-px w-8 bg-gold md:w-12" />
      {children}
    </span>
  );
}

/** Mixed-italic emphasis within large serif headlines — gold, "spoken" cadence. */
export function Em({ children }: { children: ReactNode }) {
  return <em className="italic text-gold-ink">{children}</em>;
}
