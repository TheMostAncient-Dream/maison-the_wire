import { cn } from "@/lib/utils";
import type { ComponentPropsWithoutRef, ReactNode } from "react";

type Variant = "primary" | "secondary" | "paper" | "link";
type Size = "sm" | "md" | "lg";

type LuxeButtonProps = {
  variant?: Variant;
  size?: Size;
  href?: string;
  target?: string;
  rel?: string;
  children: ReactNode;
} & Omit<ComponentPropsWithoutRef<"button">, "children">;

const sizes: Record<Size, string> = {
  sm: "h-10 px-6",
  md: "h-12 px-8",
  lg: "h-14 px-10",
};

const base =
  "inline-flex select-none items-center justify-center text-xs font-medium uppercase tracking-[0.2em] transition-all duration-500 ease-luxe focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-charcoal focus-visible:ring-offset-2 focus-visible:ring-offset-alabaster disabled:pointer-events-none disabled:opacity-50";

const variants: Record<Variant, { root: string; overlay: string | null }> = {
  /* Dark button — gold layer slides in from the left on hover */
  primary: {
    root: "group relative overflow-hidden bg-charcoal text-alabaster shadow-[0_4px_16px_rgba(0,0,0,0.15)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.25)]",
    overlay:
      "absolute inset-0 -translate-x-[101%] bg-gold transition-transform duration-500 ease-luxe group-hover:translate-x-0",
  },
  /* Transparent with thin border — fills dark on hover, text inverts */
  secondary: {
    root: "border border-charcoal bg-transparent text-charcoal hover:bg-charcoal hover:text-alabaster",
    overlay: null,
  },
  /* For dark sections — paper button with the same gold slide */
  paper: {
    root: "group relative overflow-hidden bg-alabaster text-charcoal shadow-[0_4px_16px_rgba(0,0,0,0.15)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.25)]",
    overlay:
      "absolute inset-0 -translate-x-[101%] bg-gold transition-transform duration-500 ease-luxe group-hover:translate-x-0",
  },
  /* Text link — underline on hover */
  link: {
    root: "h-auto px-0 text-charcoal underline-offset-8 hover:text-gold-ink hover:underline",
    overlay: null,
  },
};

export function LuxeButton({
  variant = "primary",
  size = "md",
  href,
  target,
  rel,
  className,
  children,
  ...props
}: LuxeButtonProps) {
  const v = variants[variant];
  const classes = cn(base, sizes[size], v.root, className);

  const inner =
    v.overlay !== null ? (
      <>
        <span aria-hidden className={v.overlay} />
        <span className="relative z-10 inline-flex items-center gap-3 transition-colors duration-500 ease-luxe group-hover:text-charcoal">
          {children}
        </span>
      </>
    ) : (
      children
    );

  if (href) {
    return (
      <a href={href} target={target} rel={rel} className={classes}>
        {inner}
      </a>
    );
  }

  return (
    <button className={classes} {...props}>
      {inner}
    </button>
  );
}
