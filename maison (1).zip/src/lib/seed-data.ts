/**
 * Source registry seed data — the single source of truth for ingested sources.
 * RSS feed URLs are real, verifiable endpoints from real publishers.
 * YouTube channel IDs were verified against live channel pages (canonical link tag).
 * Instagram accounts are preview/link-out only (see About page for platform constraints).
 */

export interface TopicSeed {
  slug: string
  name: string
  description: string
}

export const TOPICS: TopicSeed[] = [
  { slug: 'world', name: 'World', description: 'International news and global affairs' },
  { slug: 'politics', name: 'Politics', description: 'Government, elections and policy' },
  { slug: 'business', name: 'Business', description: 'Companies, economy and work' },
  { slug: 'markets', name: 'Markets', description: 'Finance, investing and deals' },
  { slug: 'technology', name: 'Technology', description: 'Software, hardware and the internet' },
  { slug: 'science', name: 'Science', description: 'Research, space and discovery' },
  { slug: 'climate', name: 'Climate', description: 'Environment, energy and weather' },
  { slug: 'health', name: 'Health', description: 'Medicine, public health and wellbeing' },
  { slug: 'sports', name: 'Sports', description: 'Leagues, athletes and competitions' },
  { slug: 'entertainment', name: 'Entertainment', description: 'Film, TV, music and celebrity' },
  { slug: 'culture', name: 'Culture', description: 'Books, ideas, art and lifestyle' },
]

export interface SourceSeed {
  slug: string
  name: string
  type: 'rss' | 'youtube' | 'instagram'
  feedUrl?: string
  websiteUrl?: string
  externalId?: string
  country?: string
  language?: string
  topicSlugs: string[]
  prominence?: number
  fetchIntervalMin?: number
  logoUrl?: string
}

/** Google favicon service — reliable, no per-site scraping needed. */
const favicon = (site: string) => `https://www.google.com/s2/favicons?domain=${site}&sz=64`

export const RSS_SOURCES: SourceSeed[] = [
  // ── General / World ──────────────────────────────────────────────────────
  { slug: 'bbc-news', name: 'BBC News', type: 'rss', feedUrl: 'https://feeds.bbci.co.uk/news/rss.xml', websiteUrl: 'https://www.bbc.co.uk/news', country: 'UK', language: 'en', topicSlugs: ['world'], prominence: 3, fetchIntervalMin: 5 },
  { slug: 'bbc-world', name: 'BBC World', type: 'rss', feedUrl: 'https://feeds.bbci.co.uk/news/world/rss.xml', websiteUrl: 'https://www.bbc.co.uk/news/world', country: 'UK', language: 'en', topicSlugs: ['world'], prominence: 3, fetchIntervalMin: 5 },
  { slug: 'guardian-world', name: 'The Guardian — World', type: 'rss', feedUrl: 'https://www.theguardian.com/world/rss', websiteUrl: 'https://www.theguardian.com/world', country: 'UK', language: 'en', topicSlugs: ['world'], prominence: 3, fetchIntervalMin: 5 },
  { slug: 'guardian-us', name: 'The Guardian — US', type: 'rss', feedUrl: 'https://www.theguardian.com/us-news/rss', websiteUrl: 'https://www.theguardian.com/us-news', country: 'US', language: 'en', topicSlugs: ['world', 'politics'], prominence: 2 },
  { slug: 'guardian-uk', name: 'The Guardian — UK News', type: 'rss', feedUrl: 'https://www.theguardian.com/uk/rss', websiteUrl: 'https://www.theguardian.com/uk', country: 'UK', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'nyt-home', name: 'The New York Times — Top Stories', type: 'rss', feedUrl: 'https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml', websiteUrl: 'https://www.nytimes.com', country: 'US', language: 'en', topicSlugs: ['world'], prominence: 3, fetchIntervalMin: 5 },
  { slug: 'nyt-world', name: 'The New York Times — World', type: 'rss', feedUrl: 'https://rss.nytimes.com/services/xml/rss/nyt/World.xml', websiteUrl: 'https://www.nytimes.com/section/world', country: 'US', language: 'en', topicSlugs: ['world'], prominence: 3, fetchIntervalMin: 5 },
  { slug: 'aljazeera', name: 'Al Jazeera English', type: 'rss', feedUrl: 'https://www.aljazeera.com/xml/rss/all.xml', websiteUrl: 'https://www.aljazeera.com', country: 'QA', language: 'en', topicSlugs: ['world'], prominence: 3, fetchIntervalMin: 5 },
  { slug: 'dw-en', name: 'Deutsche Welle', type: 'rss', feedUrl: 'https://rss.dw.com/rdf/rss-en-all', websiteUrl: 'https://www.dw.com', country: 'DE', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'france24', name: 'France 24', type: 'rss', feedUrl: 'https://www.france24.com/en/rss', websiteUrl: 'https://www.france24.com/en', country: 'FR', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'euronews', name: 'Euronews', type: 'rss', feedUrl: 'https://www.euronews.com/rss', websiteUrl: 'https://www.euronews.com', country: 'EU', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'sky-news', name: 'Sky News', type: 'rss', feedUrl: 'https://feeds.skynews.com/feeds/rss/home.xml', websiteUrl: 'https://news.sky.com', country: 'UK', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'sky-world', name: 'Sky News — World', type: 'rss', feedUrl: 'https://feeds.skynews.com/feeds/rss/world.xml', websiteUrl: 'https://news.sky.com/world', country: 'UK', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'npr-news', name: 'NPR — Top Stories', type: 'rss', feedUrl: 'https://feeds.npr.org/1001/rss.xml', websiteUrl: 'https://www.npr.org', country: 'US', language: 'en', topicSlugs: ['world'], prominence: 3 },
  { slug: 'npr-world', name: 'NPR — World', type: 'rss', feedUrl: 'https://feeds.npr.org/1004/rss.xml', websiteUrl: 'https://www.npr.org/sections/world', country: 'US', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'cbs-news', name: 'CBS News', type: 'rss', feedUrl: 'https://www.cbsnews.com/latest/rss/main', websiteUrl: 'https://www.cbsnews.com', country: 'US', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'nbc-news', name: 'NBC News', type: 'rss', feedUrl: 'https://feeds.nbcnews.com/nbcnews/public/news', websiteUrl: 'https://www.nbcnews.com', country: 'US', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'abc-news-us', name: 'ABC News (US)', type: 'rss', feedUrl: 'https://abcnews.go.com/abcnews/topstories', websiteUrl: 'https://abcnews.go.com', country: 'US', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'cbc-news', name: 'CBC News', type: 'rss', feedUrl: 'https://www.cbc.ca/webfeed/rss/rss-topstories', websiteUrl: 'https://www.cbc.ca', country: 'CA', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'nypost', name: 'New York Post', type: 'rss', feedUrl: 'https://nypost.com/feed/', websiteUrl: 'https://nypost.com', country: 'US', language: 'en', topicSlugs: ['world'], prominence: 1 },
  { slug: 'timesofindia', name: 'The Times of India', type: 'rss', feedUrl: 'https://timesofindia.indiatimes.com/rssfeedstopstories.cms', websiteUrl: 'https://timesofindia.indiatimes.com', country: 'IN', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'scmp', name: 'South China Morning Post', type: 'rss', feedUrl: 'https://www.scmp.com/rss/91/feed', websiteUrl: 'https://www.scmp.com', country: 'HK', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'japantimes', name: 'The Japan Times', type: 'rss', feedUrl: 'https://www.japantimes.co.jp/feed/', websiteUrl: 'https://www.japantimes.co.jp', country: 'JP', language: 'en', topicSlugs: ['world'], prominence: 1 },
  { slug: 'ndtv', name: 'NDTV', type: 'rss', feedUrl: 'https://feeds.feedburner.com/ndtvnews-india-news', websiteUrl: 'https://www.ndtv.com', country: 'IN', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'vox', name: 'Vox', type: 'rss', feedUrl: 'https://www.vox.com/rss/index.xml', websiteUrl: 'https://www.vox.com', country: 'US', language: 'en', topicSlugs: ['world', 'culture'], prominence: 1 },

  // ── Politics ─────────────────────────────────────────────────────────────
  { slug: 'politico', name: 'Politico', type: 'rss', feedUrl: 'https://www.politico.com/rss/politicopicks.xml', websiteUrl: 'https://www.politico.com', country: 'US', language: 'en', topicSlugs: ['politics'], prominence: 2 },
  { slug: 'thehill', name: 'The Hill', type: 'rss', feedUrl: 'https://thehill.com/feed/', websiteUrl: 'https://thehill.com', country: 'US', language: 'en', topicSlugs: ['politics'], prominence: 2 },
  { slug: 'bbc-politics', name: 'BBC — UK Politics', type: 'rss', feedUrl: 'https://feeds.bbci.co.uk/news/politics/rss.xml', websiteUrl: 'https://www.bbc.co.uk/news/politics', country: 'UK', language: 'en', topicSlugs: ['politics'], prominence: 2 },
  { slug: 'guardian-politics', name: 'The Guardian — Politics', type: 'rss', feedUrl: 'https://www.theguardian.com/politics/rss', websiteUrl: 'https://www.theguardian.com/politics', country: 'UK', language: 'en', topicSlugs: ['politics'], prominence: 2 },

  // ── Business / Markets ───────────────────────────────────────────────────
  { slug: 'bbc-business', name: 'BBC Business', type: 'rss', feedUrl: 'https://feeds.bbci.co.uk/news/business/rss.xml', websiteUrl: 'https://www.bbc.co.uk/news/business', country: 'UK', language: 'en', topicSlugs: ['business'], prominence: 3 },
  { slug: 'guardian-business', name: 'The Guardian — Business', type: 'rss', feedUrl: 'https://www.theguardian.com/uk/business/rss', websiteUrl: 'https://www.theguardian.com/uk/business', country: 'UK', language: 'en', topicSlugs: ['business'], prominence: 2 },
  { slug: 'nyt-business', name: 'The New York Times — Business', type: 'rss', feedUrl: 'https://rss.nytimes.com/services/xml/rss/nyt/Business.xml', websiteUrl: 'https://www.nytimes.com/section/business', country: 'US', language: 'en', topicSlugs: ['business'], prominence: 3 },
  { slug: 'nyt-economy', name: 'The New York Times — Economy', type: 'rss', feedUrl: 'https://rss.nytimes.com/services/xml/rss/nyt/Economy.xml', websiteUrl: 'https://www.nytimes.com/section/economy', country: 'US', language: 'en', topicSlugs: ['business', 'markets'], prominence: 2 },
  { slug: 'cnbc-top', name: 'CNBC — Top News', type: 'rss', feedUrl: 'https://www.cnbc.com/id/100003114/device/rss/rss.html', websiteUrl: 'https://www.cnbc.com', country: 'US', language: 'en', topicSlugs: ['business'], prominence: 3 },
  { slug: 'cnbc-world', name: 'CNBC — World News', type: 'rss', feedUrl: 'https://www.cnbc.com/id/100727362/device/rss/rss.html', websiteUrl: 'https://www.cnbc.com/world', country: 'US', language: 'en', topicSlugs: ['world', 'business'], prominence: 2 },
  { slug: 'cnbc-business', name: 'CNBC — Business', type: 'rss', feedUrl: 'https://www.cnbc.com/id/10001147/device/rss/rss.html', websiteUrl: 'https://www.cnbc.com/business', country: 'US', language: 'en', topicSlugs: ['business'], prominence: 2 },
  { slug: 'marketwatch', name: 'MarketWatch — Top Stories', type: 'rss', feedUrl: 'https://feeds.content.dowjones.io/public/rss/mw_topstories', websiteUrl: 'https://www.marketwatch.com', country: 'US', language: 'en', topicSlugs: ['markets'], prominence: 3 },
  { slug: 'wsj-markets', name: 'The Wall Street Journal — Markets', type: 'rss', feedUrl: 'https://feeds.a.dj.com/rss/RSSMarketsMain.xml', websiteUrl: 'https://www.wsj.com/news/markets', country: 'US', language: 'en', topicSlugs: ['markets'], prominence: 3 },
  { slug: 'wsj-world', name: 'The Wall Street Journal — World', type: 'rss', feedUrl: 'https://feeds.a.dj.com/rss/RSSWorldNews.xml', websiteUrl: 'https://www.wsj.com/news/world', country: 'US', language: 'en', topicSlugs: ['world'], prominence: 3 },
  { slug: 'yahoo-finance', name: 'Yahoo Finance', type: 'rss', feedUrl: 'https://finance.yahoo.com/news/rssindex', websiteUrl: 'https://finance.yahoo.com', country: 'US', language: 'en', topicSlugs: ['markets'], prominence: 2 },
  { slug: 'economic-times', name: 'The Economic Times', type: 'rss', feedUrl: 'https://economictimes.indiatimes.com/rssfeedstopstories.cms', websiteUrl: 'https://economictimes.indiatimes.com', country: 'IN', language: 'en', topicSlugs: ['business', 'markets'], prominence: 2 },
  { slug: 'et-markets', name: 'ET Markets', type: 'rss', feedUrl: 'https://economictimes.indiatimes.com/markets/rssfeeds/1977021501.cms', websiteUrl: 'https://economictimes.indiatimes.com/markets', country: 'IN', language: 'en', topicSlugs: ['markets'], prominence: 2 },

  // ── Technology ───────────────────────────────────────────────────────────
  { slug: 'bbc-tech', name: 'BBC Technology', type: 'rss', feedUrl: 'https://feeds.bbci.co.uk/news/technology/rss.xml', websiteUrl: 'https://www.bbc.co.uk/news/technology', country: 'UK', language: 'en', topicSlugs: ['technology'], prominence: 3 },
  { slug: 'guardian-tech', name: 'The Guardian — Technology', type: 'rss', feedUrl: 'https://www.theguardian.com/uk/technology/rss', websiteUrl: 'https://www.theguardian.com/uk/technology', country: 'UK', language: 'en', topicSlugs: ['technology'], prominence: 2 },
  { slug: 'nyt-tech', name: 'The New York Times — Technology', type: 'rss', feedUrl: 'https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml', websiteUrl: 'https://www.nytimes.com/section/technology', country: 'US', language: 'en', topicSlugs: ['technology'], prominence: 3 },
  { slug: 'cnbc-tech', name: 'CNBC — Technology', type: 'rss', feedUrl: 'https://www.cnbc.com/id/19854910/device/rss/rss.html', websiteUrl: 'https://www.cnbc.com/technology', country: 'US', language: 'en', topicSlugs: ['technology'], prominence: 2 },
  { slug: 'techcrunch', name: 'TechCrunch', type: 'rss', feedUrl: 'https://techcrunch.com/feed/', websiteUrl: 'https://techcrunch.com', country: 'US', language: 'en', topicSlugs: ['technology'], prominence: 3 },
  { slug: 'theverge', name: 'The Verge', type: 'rss', feedUrl: 'https://www.theverge.com/rss/index.xml', websiteUrl: 'https://www.theverge.com', country: 'US', language: 'en', topicSlugs: ['technology'], prominence: 3 },
  { slug: 'arstechnica', name: 'Ars Technica', type: 'rss', feedUrl: 'https://feeds.arstechnica.com/arstechnica/index', websiteUrl: 'https://arstechnica.com', country: 'US', language: 'en', topicSlugs: ['technology'], prominence: 2 },
  { slug: 'wired', name: 'WIRED', type: 'rss', feedUrl: 'https://www.wired.com/feed/rss', websiteUrl: 'https://www.wired.com', country: 'US', language: 'en', topicSlugs: ['technology', 'science'], prominence: 2 },
  { slug: 'engadget', name: 'Engadget', type: 'rss', feedUrl: 'https://www.engadget.com/rss.xml', websiteUrl: 'https://www.engadget.com', country: 'US', language: 'en', topicSlugs: ['technology'], prominence: 2 },
  { slug: 'mashable', name: 'Mashable', type: 'rss', feedUrl: 'https://mashable.com/feed/', websiteUrl: 'https://mashable.com', country: 'US', language: 'en', topicSlugs: ['technology', 'culture'], prominence: 1 },
  { slug: 'techradar', name: 'TechRadar', type: 'rss', feedUrl: 'https://www.techradar.com/feeds.xml', websiteUrl: 'https://www.techradar.com', country: 'UK', language: 'en', topicSlugs: ['technology'], prominence: 1 },
  { slug: 'thenextweb', name: 'The Next Web', type: 'rss', feedUrl: 'https://thenextweb.com/feed', websiteUrl: 'https://thenextweb.com', country: 'NL', language: 'en', topicSlugs: ['technology'], prominence: 1 },
  { slug: 'hackernews', name: 'Hacker News', type: 'rss', feedUrl: 'https://hnrss.org/frontpage', websiteUrl: 'https://news.ycombinator.com', country: 'US', language: 'en', topicSlugs: ['technology'], prominence: 1, fetchIntervalMin: 15 },
  { slug: 'npr-tech', name: 'NPR — Technology', type: 'rss', feedUrl: 'https://feeds.npr.org/1019/rss.xml', websiteUrl: 'https://www.npr.org/sections/technology', country: 'US', language: 'en', topicSlugs: ['technology'], prominence: 2 },

  // ── Science / Climate ────────────────────────────────────────────────────
  { slug: 'bbc-science', name: 'BBC — Science & Environment', type: 'rss', feedUrl: 'https://feeds.bbci.co.uk/news/science_and_environment/rss.xml', websiteUrl: 'https://www.bbc.co.uk/news/science_and_environment', country: 'UK', language: 'en', topicSlugs: ['science', 'climate'], prominence: 3 },
  { slug: 'guardian-science', name: 'The Guardian — Science', type: 'rss', feedUrl: 'https://www.theguardian.com/science/rss', websiteUrl: 'https://www.theguardian.com/science', country: 'UK', language: 'en', topicSlugs: ['science'], prominence: 2 },
  { slug: 'guardian-environment', name: 'The Guardian — Environment', type: 'rss', feedUrl: 'https://www.theguardian.com/environment/rss', websiteUrl: 'https://www.theguardian.com/environment', country: 'UK', language: 'en', topicSlugs: ['climate'], prominence: 2 },
  { slug: 'nyt-science', name: 'The New York Times — Science', type: 'rss', feedUrl: 'https://rss.nytimes.com/services/xml/rss/nyt/Science.xml', websiteUrl: 'https://www.nytimes.com/section/science', country: 'US', language: 'en', topicSlugs: ['science'], prominence: 3 },
  { slug: 'nyt-climate', name: 'The New York Times — Climate', type: 'rss', feedUrl: 'https://rss.nytimes.com/services/xml/rss/nyt/Climate.xml', websiteUrl: 'https://www.nytimes.com/section/climate', country: 'US', language: 'en', topicSlugs: ['climate'], prominence: 2 },
  { slug: 'npr-science', name: 'NPR — Science', type: 'rss', feedUrl: 'https://feeds.npr.org/1007/rss.xml', websiteUrl: 'https://www.npr.org/sections/science', country: 'US', language: 'en', topicSlugs: ['science'], prominence: 2 },
  { slug: 'phys-org', name: 'Phys.org', type: 'rss', feedUrl: 'https://phys.org/rss-feed/', websiteUrl: 'https://phys.org', country: 'US', language: 'en', topicSlugs: ['science'], prominence: 1 },
  { slug: 'sciencedaily', name: 'ScienceDaily', type: 'rss', feedUrl: 'https://www.sciencedaily.com/rss/all.xml', websiteUrl: 'https://www.sciencedaily.com', country: 'US', language: 'en', topicSlugs: ['science'], prominence: 1 },
  { slug: 'nature', name: 'Nature', type: 'rss', feedUrl: 'https://www.nature.com/nature.rss', websiteUrl: 'https://www.nature.com', country: 'UK', language: 'en', topicSlugs: ['science'], prominence: 2, fetchIntervalMin: 30 },

  // ── Health ───────────────────────────────────────────────────────────────
  { slug: 'bbc-health', name: 'BBC Health', type: 'rss', feedUrl: 'https://feeds.bbci.co.uk/news/health/rss.xml', websiteUrl: 'https://www.bbc.co.uk/news/health', country: 'UK', language: 'en', topicSlugs: ['health'], prominence: 2 },
  { slug: 'nyt-health', name: 'The New York Times — Health', type: 'rss', feedUrl: 'https://rss.nytimes.com/services/xml/rss/nyt/Health.xml', websiteUrl: 'https://www.nytimes.com/section/health', country: 'US', language: 'en', topicSlugs: ['health'], prominence: 2 },
  { slug: 'npr-health', name: 'NPR — Health', type: 'rss', feedUrl: 'https://feeds.npr.org/1128/rss.xml', websiteUrl: 'https://www.npr.org/sections/health-shots', country: 'US', language: 'en', topicSlugs: ['health'], prominence: 2 },
  { slug: 'guardian-society', name: 'The Guardian — Society', type: 'rss', feedUrl: 'https://www.theguardian.com/society/rss', websiteUrl: 'https://www.theguardian.com/society', country: 'UK', language: 'en', topicSlugs: ['health'], prominence: 1 },

  // ── Sports ───────────────────────────────────────────────────────────────
  { slug: 'bbc-sport', name: 'BBC Sport', type: 'rss', feedUrl: 'https://feeds.bbci.co.uk/sport/rss.xml', websiteUrl: 'https://www.bbc.co.uk/sport', country: 'UK', language: 'en', topicSlugs: ['sports'], prominence: 3 },
  { slug: 'guardian-sport', name: 'The Guardian — Sport', type: 'rss', feedUrl: 'https://www.theguardian.com/uk/sport/rss', websiteUrl: 'https://www.theguardian.com/uk/sport', country: 'UK', language: 'en', topicSlugs: ['sports'], prominence: 2 },
  { slug: 'cbs-sports', name: 'CBS Sports', type: 'rss', feedUrl: 'https://www.cbssports.com/rss/headlines/', websiteUrl: 'https://www.cbssports.com', country: 'US', language: 'en', topicSlugs: ['sports'], prominence: 2 },
  { slug: 'yahoo-sports', name: 'Yahoo Sports', type: 'rss', feedUrl: 'https://sports.yahoo.com/rss/', websiteUrl: 'https://sports.yahoo.com', country: 'US', language: 'en', topicSlugs: ['sports'], prominence: 2 },
  { slug: 'sky-sports', name: 'Sky Sports', type: 'rss', feedUrl: 'https://www.skysports.com/rss/12040', websiteUrl: 'https://www.skysports.com', country: 'UK', language: 'en', topicSlugs: ['sports'], prominence: 2 },
  { slug: 'nyt-sports', name: 'The New York Times — Sports', type: 'rss', feedUrl: 'https://rss.nytimes.com/services/xml/rss/nyt/Sports.xml', websiteUrl: 'https://www.nytimes.com/section/sports', country: 'US', language: 'en', topicSlugs: ['sports'], prominence: 2 },

  // ── Entertainment / Culture ──────────────────────────────────────────────
  { slug: 'bbc-entertainment', name: 'BBC — Entertainment & Arts', type: 'rss', feedUrl: 'https://feeds.bbci.co.uk/news/entertainment_and_arts/rss.xml', websiteUrl: 'https://www.bbc.co.uk/news/entertainment_and_arts', country: 'UK', language: 'en', topicSlugs: ['entertainment'], prominence: 2 },
  { slug: 'guardian-culture', name: 'The Guardian — Culture', type: 'rss', feedUrl: 'https://www.theguardian.com/culture/rss', websiteUrl: 'https://www.theguardian.com/culture', country: 'UK', language: 'en', topicSlugs: ['culture'], prominence: 2 },
  { slug: 'nyt-arts', name: 'The New York Times — Arts', type: 'rss', feedUrl: 'https://rss.nytimes.com/services/xml/rss/nyt/Arts.xml', websiteUrl: 'https://www.nytimes.com/section/arts', country: 'US', language: 'en', topicSlugs: ['culture'], prominence: 2 },
  { slug: 'nyt-movies', name: 'The New York Times — Movies', type: 'rss', feedUrl: 'https://rss.nytimes.com/services/xml/rss/nyt/Movies.xml', websiteUrl: 'https://www.nytimes.com/section/movies', country: 'US', language: 'en', topicSlugs: ['entertainment'], prominence: 2 },
  { slug: 'variety', name: 'Variety', type: 'rss', feedUrl: 'https://variety.com/feed/', websiteUrl: 'https://variety.com', country: 'US', language: 'en', topicSlugs: ['entertainment'], prominence: 2 },
  { slug: 'hollywood-reporter', name: 'The Hollywood Reporter', type: 'rss', feedUrl: 'https://www.hollywoodreporter.com/feed/', websiteUrl: 'https://www.hollywoodreporter.com', country: 'US', language: 'en', topicSlugs: ['entertainment'], prominence: 2 },
  { slug: 'deadline', name: 'Deadline', type: 'rss', feedUrl: 'https://deadline.com/feed/', websiteUrl: 'https://deadline.com', country: 'US', language: 'en', topicSlugs: ['entertainment'], prominence: 2 },
  { slug: 'billboard', name: 'Billboard', type: 'rss', feedUrl: 'https://www.billboard.com/feed/', websiteUrl: 'https://www.billboard.com', country: 'US', language: 'en', topicSlugs: ['entertainment', 'culture'], prominence: 1 },
  { slug: 'npr-popculture', name: 'NPR — Pop Culture', type: 'rss', feedUrl: 'https://feeds.npr.org/1008/rss.xml', websiteUrl: 'https://www.npr.org/sections/pop-culture', country: 'US', language: 'en', topicSlugs: ['culture', 'entertainment'], prominence: 1 },
  { slug: 'nyt-books', name: 'The New York Times — Books', type: 'rss', feedUrl: 'https://rss.nytimes.com/services/xml/rss/nyt/Books.xml', websiteUrl: 'https://www.nytimes.com/section/books', country: 'US', language: 'en', topicSlugs: ['culture'], prominence: 1 },
]

/** Apply consistent favicon logos to all RSS sources at seed time. */
export function rssSourcesWithLogos(): SourceSeed[] {
  return RSS_SOURCES.map((s) => ({
    ...s,
    logoUrl: favicon(new URL(s.websiteUrl!).hostname),
  }))
}

export const YOUTUBE_CHANNELS: SourceSeed[] = [
  { slug: 'yt-aljazeera-en', name: 'Al Jazeera English', type: 'youtube', externalId: 'UCNye-wNBqNL5ZzHSJj3l8Bg', websiteUrl: 'https://www.youtube.com/@AlJazeeraEnglish', country: 'QA', language: 'en', topicSlugs: ['world'], prominence: 3 },
  { slug: 'yt-bbcnews', name: 'BBC News', type: 'youtube', externalId: 'UC16niRr50-MSBwiO3YDb3RA', websiteUrl: 'https://www.youtube.com/@BBCNews', country: 'UK', language: 'en', topicSlugs: ['world'], prominence: 3 },
  { slug: 'yt-dwnews', name: 'DW News', type: 'youtube', externalId: 'UCknLrEdhRCp1aegoMqRaCZg', websiteUrl: 'https://www.youtube.com/@dwnews', country: 'DE', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'yt-skynews', name: 'Sky News', type: 'youtube', externalId: 'UCkFclpi8U9VJjfxLYoms7Aw', websiteUrl: 'https://www.youtube.com/@skynews', country: 'UK', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'yt-france24', name: 'France 24 English', type: 'youtube', externalId: 'UCQfwfsi5VrQ8yKZ-UWmAEFg', websiteUrl: 'https://www.youtube.com/@France24_en', country: 'FR', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'yt-bloomberg-tv', name: 'Bloomberg Television', type: 'youtube', externalId: 'UCdK2BueKxC9VxXh7e1Ne4oQ', websiteUrl: 'https://www.youtube.com/@BloombergTelevision', country: 'US', language: 'en', topicSlugs: ['business', 'markets'], prominence: 3 },
  { slug: 'yt-cnbc-tv', name: 'CNBC Television', type: 'youtube', externalId: 'UCrp_UI8XtuYfpiqluWLD7Lw', websiteUrl: 'https://www.youtube.com/@CNBCtelevision', country: 'US', language: 'en', topicSlugs: ['business', 'markets'], prominence: 2 },
  { slug: 'yt-yahoo-finance', name: 'Yahoo Finance', type: 'youtube', externalId: 'UCEAZeUIeJs0IjQiqTCdVSIg', websiteUrl: 'https://www.youtube.com/@yahooFinance', country: 'US', language: 'en', topicSlugs: ['markets'], prominence: 2 },
  { slug: 'yt-cbsnews', name: 'CBS News', type: 'youtube', externalId: 'UC8p1vwvWtl6T73JiExfWs1g', websiteUrl: 'https://www.youtube.com/@CBSNews', country: 'US', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'yt-euronews', name: 'euronews', type: 'youtube', externalId: 'UCSrZ3UV4jOidv8ppoVuvW9Q', websiteUrl: 'https://www.youtube.com/@euronews', country: 'EU', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'yt-wion', name: 'WION', type: 'youtube', externalId: 'UCWEIPvoxRwn6llPOIn555rQ', websiteUrl: 'https://www.youtube.com/@WIONews', country: 'IN', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'yt-india-today', name: 'India Today', type: 'youtube', externalId: 'UCYPvAwZP8pZhSMW8qs7cVCw', websiteUrl: 'https://www.youtube.com/@IndiaToday', country: 'IN', language: 'en', topicSlugs: ['world', 'politics'], prominence: 2 },
  { slug: 'yt-ndtv', name: 'NDTV 24x7', type: 'youtube', externalId: 'UCZFMm1mMw0F81Z37aaEzTUA', websiteUrl: 'https://www.youtube.com/@NDTV', country: 'IN', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'yt-guardian', name: 'The Guardian', type: 'youtube', externalId: 'UCHpw8xwDNhU9gdohEcJu4aA', websiteUrl: 'https://www.youtube.com/@theguardian', country: 'UK', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'yt-espn', name: 'ESPN', type: 'youtube', externalId: 'UCiWLfSweyRNmLpgEHekhoAg', websiteUrl: 'https://www.youtube.com/@ESPN', country: 'US', language: 'en', topicSlugs: ['sports'], prominence: 2 },
  { slug: 'yt-nbcnews', name: 'NBC News', type: 'youtube', externalId: 'UCeY0bbntWzzVIaj2z3QigXg', websiteUrl: 'https://www.youtube.com/@NBCNews', country: 'US', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'yt-abcnews', name: 'ABC News (US)', type: 'youtube', externalId: 'UCBi2mrWuNuyYy4gbM6fU18Q', websiteUrl: 'https://www.youtube.com/@abcnews', country: 'US', language: 'en', topicSlugs: ['world'], prominence: 2 },
  { slug: 'yt-trtworld', name: 'TRT World', type: 'youtube', externalId: 'UC7fWeaHhqgM4Ry-RMpM2YYw', websiteUrl: 'https://www.youtube.com/@TRTWorld', country: 'TR', language: 'en', topicSlugs: ['world'], prominence: 1 },
  { slug: 'yt-timesofindia', name: 'The Times of India', type: 'youtube', externalId: 'UCckHqySbfy5FcPP6MD_S-Yg', websiteUrl: 'https://www.youtube.com/@timesofindia', country: 'IN', language: 'en', topicSlugs: ['world'], prominence: 1 },
  { slug: 'yt-skysports', name: 'Sky Sports News', type: 'youtube', externalId: 'UCcw05gGzjLIs5dnxGkQHMvw', websiteUrl: 'https://www.youtube.com/@SkySportsNews', country: 'UK', language: 'en', topicSlugs: ['sports'], prominence: 2 },
  // Science & technology creators — slower upload cadence than the news desks,
  // so they poll at 60 min instead of the 30 min default.
  { slug: 'yt-veritasium', name: 'Veritasium', type: 'youtube', externalId: 'UCHnyfMqiRRG1u-2MsSQLbXA', websiteUrl: 'https://www.youtube.com/@veritasium', country: 'AU', language: 'en', topicSlugs: ['science'], prominence: 2, fetchIntervalMin: 60 },
  { slug: 'yt-kurzgesagt', name: 'Kurzgesagt – In a Nutshell', type: 'youtube', externalId: 'UCsXVk37bltHxD1rDPwtNM8Q', websiteUrl: 'https://www.youtube.com/@kurzgesagt', country: 'DE', language: 'en', topicSlugs: ['science'], prominence: 2, fetchIntervalMin: 60 },
  { slug: 'yt-markrober', name: 'Mark Rober', type: 'youtube', externalId: 'UCY1kMZp36IQSyNx_9h4mpCg', websiteUrl: 'https://www.youtube.com/@MarkRober', country: 'US', language: 'en', topicSlugs: ['science'], prominence: 2, fetchIntervalMin: 60 },
  { slug: 'yt-nasa', name: 'NASA', type: 'youtube', externalId: 'UCLA_DiR1FfKNvjuUpBHmylQ', websiteUrl: 'https://www.youtube.com/@NASA', country: 'US', language: 'en', topicSlugs: ['science'], prominence: 2, fetchIntervalMin: 60 },
  { slug: 'yt-mkbhd', name: 'Marques Brownlee', type: 'youtube', externalId: 'UCBJycsmduvYEL83R_U4JriQ', websiteUrl: 'https://www.youtube.com/@mkbhd', country: 'US', language: 'en', topicSlugs: ['technology'], prominence: 2 },
  { slug: 'yt-fireship', name: 'Fireship', type: 'youtube', externalId: 'UCsBjURrPoezykLs9EqgamOA', websiteUrl: 'https://www.youtube.com/@Fireship', country: 'US', language: 'en', topicSlugs: ['technology'], prominence: 2 },
  { slug: 'yt-3blue1brown', name: '3Blue1Brown', type: 'youtube', externalId: 'UCYO_jab_esuFRV4b17AJtAw', websiteUrl: 'https://www.youtube.com/@3blue1brown', country: 'US', language: 'en', topicSlugs: ['science'], prominence: 1, fetchIntervalMin: 60 },
  { slug: 'yt-vsauce', name: 'Vsauce', type: 'youtube', externalId: 'UC6nSFpj9HTCZ5t-N3Rm3-HA', websiteUrl: 'https://www.youtube.com/@Vsauce', country: 'US', language: 'en', topicSlugs: ['science'], prominence: 1, fetchIntervalMin: 60 },
]

/**
 * Instagram accounts — preview/link-out ONLY (see spec §4.3 and About page).
 * No scraping, no fake content: each renders as a clearly-labeled card that
 * deep-links to the original account on instagram.com.
 */
export const INSTAGRAM_ACCOUNTS: SourceSeed[] = [
  { slug: 'ig-bbcnews', name: '@bbcnews', type: 'instagram', externalId: 'bbcnews', websiteUrl: 'https://www.instagram.com/bbcnews/', country: 'UK', language: 'en', topicSlugs: ['world'] },
  { slug: 'ig-cnn', name: '@cnn', type: 'instagram', externalId: 'cnn', websiteUrl: 'https://www.instagram.com/cnn/', country: 'US', language: 'en', topicSlugs: ['world'] },
  { slug: 'ig-npr', name: '@npr', type: 'instagram', externalId: 'npr', websiteUrl: 'https://www.instagram.com/npr/', country: 'US', language: 'en', topicSlugs: ['world', 'culture'] },
  { slug: 'ig-theguardian', name: '@theguardian', type: 'instagram', externalId: 'theguardian', websiteUrl: 'https://www.instagram.com/theguardian/', country: 'UK', language: 'en', topicSlugs: ['world'] },
  { slug: 'ig-aljazeera', name: '@aljazeeraenglish', type: 'instagram', externalId: 'aljazeeraenglish', websiteUrl: 'https://www.instagram.com/aljazeeraenglish/', country: 'QA', language: 'en', topicSlugs: ['world'] },
  { slug: 'ig-economist', name: '@theeconomist', type: 'instagram', externalId: 'theeconomist', websiteUrl: 'https://www.instagram.com/theeconomist/', country: 'UK', language: 'en', topicSlugs: ['business'] },
  { slug: 'ig-bloomberg', name: '@bloomberg', type: 'instagram', externalId: 'bloomberg', websiteUrl: 'https://www.instagram.com/bloomberg/', country: 'US', language: 'en', topicSlugs: ['business'] },
  { slug: 'ig-natgeo', name: '@natgeo', type: 'instagram', externalId: 'natgeo', websiteUrl: 'https://www.instagram.com/natgeo/', country: 'US', language: 'en', topicSlugs: ['science'] },
  { slug: 'ig-nasa', name: '@nasa', type: 'instagram', externalId: 'nasa', websiteUrl: 'https://www.instagram.com/nasa/', country: 'US', language: 'en', topicSlugs: ['science'] },
  { slug: 'ig-espn', name: '@espn', type: 'instagram', externalId: 'espn', websiteUrl: 'https://www.instagram.com/espn/', country: 'US', language: 'en', topicSlugs: ['sports'] },
  { slug: 'ig-economictimes', name: '@economictimes', type: 'instagram', externalId: 'economictimes', websiteUrl: 'https://www.instagram.com/economictimes/', country: 'IN', language: 'en', topicSlugs: ['business'] },
  { slug: 'ig-hindustantimes', name: '@hindustantimes', type: 'instagram', externalId: 'hindustantimes', websiteUrl: 'https://www.instagram.com/hindustantimes/', country: 'IN', language: 'en', topicSlugs: ['world'] },
]
