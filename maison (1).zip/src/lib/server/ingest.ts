/**
 * Ingestion pipeline — fetches RSS / YouTube / Instagram sources, normalizes
 * everything into the unified ContentItem model, tracks per-source health,
 * and runs a background scheduler with per-source intervals + backoff.
 *
 * The browser never talks to external feeds directly; everything flows
 * through this pipeline into the database.
 */
import Parser from 'rss-parser'
import { db } from '@/lib/db'
import { contentHash } from './cluster'
import { bumpDataEpoch } from './cache'
import {
  collectMediaUrls,
  firstInlineImage,
  pickBestImageUrl,
  scrapePageImage,
} from './image'
import { secret } from '@/lib/server/persisted-env'
import { notifyUsersForSource } from './push'
import type { Source, ContentItem } from '@prisma/client'

const parser: Parser = new Parser({
  timeout: 15_000,
  headers: {
    'User-Agent': 'Mozilla/5.0 (compatible; NewswireTerminal/1.0; +https://newswire.local/about)',
    Accept: 'application/rss+xml, application/xml, application/atom+xml, text/xml;q=0.9, */*;q=0.8',
  },
  customFields: {
    item: [
      ['media:content', 'media:content', { keepArray: true }],
      ['media:thumbnail', 'media:thumbnail', { keepArray: true }],
      ['media:group', 'mediaGroup'],
      ['image', 'rssImage'],
      ['itunes:image', 'itunesImage'],
    ],
  },
})

/**
 * Some publishers block bot-like User-Agents at the CDN; others block browser
 * strings. Rotate through a small honest list — first success wins.
 */
const USER_AGENTS = [
  'Mozilla/5.0 (compatible; NewswireTerminal/1.0; +https://newswire.local/about)',
  'curl/8.7.1',
  'NewswireTerminal/1.0 (feed reader; +https://newswire.local/about)',
]

/** Fetch raw XML with UA rotation. */
async function fetchFeedXml(url: string): Promise<string> {
  let lastErr: unknown
  for (const ua of USER_AGENTS) {
    try {
      const res = await fetch(url, {
        headers: { 'User-Agent': ua, Accept: 'application/rss+xml, application/xml, application/atom+xml, text/xml;q=0.9, */*;q=0.8' },
        signal: AbortSignal.timeout(15_000),
        redirect: 'follow',
      })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      let xml = await res.text()
      // Strip BOM / junk before the XML prologue (some CDNs prepend content).
      const prologue = xml.search(/<\?xml|<rss[\s>]|<feed[\s>]|<rdf[\s>]|<rdf:RDF/i)
      if (prologue > 0) xml = xml.slice(prologue)
      else if (prologue === -1 && !/^[\s]*<\?xml/i.test(xml) && !/<rss[\s>]|<feed[\s>]|<rdf[\s>]/i.test(xml.slice(0, 500))) {
        throw new Error('Response is not a valid RSS/Atom document')
      }
      return xml
    } catch (err) {
      lastErr = err
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error('Feed fetch failed')
}

// ─── State shared with the status endpoint ───────────────────────────────────

interface IngestState {
  ingesting: boolean
  lastRunAt: Date | null
  lastFullRunMs: number | null
  lastError: string | null
  youtubeEnabled: boolean
}

const globalForIngest = globalThis as unknown as {
  __newswire_ingest?: IngestState
  __newswire_scheduler?: ReturnType<typeof setInterval> | null
  __newswire_bootstrapped?: boolean
}

export const ingestState: IngestState =
  globalForIngest.__newswire_ingest ??
  (globalForIngest.__newswire_ingest = {
    ingesting: false,
    lastRunAt: null,
    lastFullRunMs: null,
    lastError: null,
    youtubeEnabled: !!secret('YOUTUBE_API_KEY'),
  })

// ─── Helpers ─────────────────────────────────────────────────────────────────

/* Decode HTML entities in feed-supplied text. Some publishers (notably
   Yahoo) pre-escape their fields, so rss-parser's output still carries
   &#39;-style residue into the DB and the page. Idempotent by design:
   decoding repeats until the text stops changing (handles double-escaping),
   so repaired rows and freshly-ingested rows hash and render identically.
   ponytail: this regex set covers feed reality; a full entity parser is
   the upgrade if an exotic named entity ever slips through untouched. */
const NAMED_ENTITIES: Record<string, string> = {
  amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ',
  hellip: '\u2026', mdash: '\u2014', ndash: '\u2013',
  rsquo: '\u2019', lsquo: '\u2018', rdquo: '\u201C', ldquo: '\u201D',
}

function codePointOf(n: number): string {
  return Number.isInteger(n) && n > 0 && n <= 0x10ffff && !(n >= 0xd800 && n <= 0xdfff)
    ? String.fromCodePoint(n)
    : ''
}

export function decodeEntities(input: string): string {
  let out = input
  for (let prev = ''; out !== prev; ) {
    prev = out
    out = out
      .replace(/&#x([0-9a-fA-F]+);/g, (_, h) => codePointOf(parseInt(h, 16)))
      .replace(/&#(\d+);/g, (_, d) => codePointOf(parseInt(d, 10)))
      .replace(/&([a-zA-Z]+);/g, (m, name: string) => NAMED_ENTITIES[name] ?? m)
  }
  return out
}

function stripHtml(html: string | undefined | null): string | null {
  if (!html) return null
  const text = html
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/\s+/g, ' ')
    .trim()
  return text || null
}

/**
 * Harvest the best thumbnail from every media surface the feed offers:
 * media:group, media:content / media:thumbnail (single or array),
 * itunes:image, enclosures, and inline <img> in the description.
 * Tracking pixels and entity-mangled URLs are filtered / repaired.
 */
function extractImage(item: ParserItem, html: string | null): string | null {
  const media: any = item as any
  const candidates = collectMediaUrls([
    media.mediaGroup,
    media['media:content'],
    media['media:thumbnail'],
    media.itunesImage,
    media.rssImage,
    item.enclosure && /image|jpg|jpeg|png|webp/i.test(item.enclosure.type ?? item.enclosure.url ?? '')
      ? { $: { url: item.enclosure.url } }
      : null,
  ])
  const best = pickBestImageUrl(candidates)
  if (best) return best
  // Last resort: first <img> inside content / description.
  return firstInlineImage(html)
}

/**
 * Feed gave us nothing visual → fetch the article page and take its
 * og:image / twitter:image. Runs with a small pool so a full feed ingest
 * stays well under a few extra seconds.
 */
async function enrichMissingThumbnails(items: NormalizedItem[]): Promise<void> {
  const missing = items.filter(
    (i) => !i.thumbnailUrl && /^https?:\/\//i.test(i.url)
  )
  if (missing.length === 0) return
  let cursor = 0
  const workers = Array.from({ length: Math.min(8, missing.length) }, async () => {
    while (cursor < missing.length) {
      const target = missing[cursor++]
      const img = await scrapePageImage(target.url)
      if (img) target.thumbnailUrl = img
    }
  })
  await Promise.all(workers)
}

type ParserItem = {
  title?: string
  link?: string
  pubDate?: string
  isoDate?: string
  creator?: string
  contentSnippet?: string
  enclosure?: { url?: string; type?: string }
  content?: string
  'content:encoded'?: string
  summary?: string
}

interface NormalizedItem {
  title: string
  snippet: string | null
  url: string
  author: string | null
  thumbnailUrl: string | null
  durationSec: number | null
  publishedAt: Date
  contentHash: string
}

/** Parse ISO-8601 duration (PT13M37S) → seconds. */
function isoDurationToSeconds(iso: string): number | null {
  const m = iso.match(/^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/)
  if (!m) return null
  return (+(m[1] ?? 0)) * 3600 + (+(m[2] ?? 0)) * 60 + (+(m[3] ?? 0))
}

/**
 * Aggregator mirrors (Bing News RSS) wrap the real publisher link in a click
 * tracker. Unwrap it so "Read at Source", brief extraction, and og:image
 * scraping all hit the true article URL.
 */
function unwrapAggregatorLink(url: string): string {
  try {
    const u = new URL(url)
    if (u.hostname.endsWith('bing.com') && u.pathname === '/news/apiclick.aspx') {
      const real = u.searchParams.get('url')
      if (real && /^https?:\/\//i.test(real)) return real
    }
  } catch {
    /* keep original */
  }
  return url
}

/**
 * Bing News RSS ships artwork in a <News:Image> element whose namespace
 * prefix defeats rss-parser's customFields. Harvest the URLs straight from
 * the raw XML, preserving document order so entries zip with parsed items.
 */
function bingNewsImages(xml: string): (string | null)[] {
  const images: (string | null)[] = []
  const itemRe = /<item\b[^>]*>([\s\S]*?)<\/item>/gi
  const imgRe = /<news:image>([\s\S]*?)<\/news:image>/i
  let match: RegExpExecArray | null
  while ((match = itemRe.exec(xml))) {
    const raw = match[1].match(imgRe)?.[1]?.trim()
    images.push(
      raw
        ? raw
            .replace(/&amp;/g, '&')
            .replace(/&lt;/g, '<')
            .replace(/&gt;/g, '>')
            .replace(/&quot;/g, '"')
            .replace(/&#39;/g, "'")
        : null
    )
  }
  return images
}

// ─── RSS ─────────────────────────────────────────────────────────────────────

async function fetchRss(source: Source): Promise<NormalizedItem[]> {
  const xml = await fetchFeedXml(source.feedUrl!)
  const feed = await parser.parseString(xml)
  // Aggregator mirrors (Bing News) need per-item post-processing:
  // unwrapped publisher links + News:Image artwork.
  const bingImages = /bing\.com/i.test(source.feedUrl ?? '') ? bingNewsImages(xml) : []
  const items: NormalizedItem[] = []
  const entries = (feed.items ?? []) as ParserItem[]
  for (let idx = 0; idx < entries.length; idx++) {
    const item = entries[idx]
    if (!item.title || !item.link) continue
    const html = (item['content:encoded'] ?? item.content ?? item.summary ?? null) as string | null
    const rawTitle = decodeEntities(item.title)
    const rawSnippet = item.contentSnippet ?? stripHtml(html) ?? null
    items.push({
      title: rawTitle.trim(),
      snippet: rawSnippet ? decodeEntities(rawSnippet).slice(0, 400) : null,
      url: unwrapAggregatorLink(item.link),
      author: item.creator ? decodeEntities(item.creator) : null,
      thumbnailUrl: extractImage(item, html) ?? bingImages[idx] ?? null,
      durationSec: null,
      publishedAt: item.isoDate ? new Date(item.isoDate) : item.pubDate ? new Date(item.pubDate) : new Date(),
      contentHash: contentHash(rawTitle.trim()),
    })
  }
  // Feeds without media tags still deserve artwork — scrape og:image.
  await enrichMissingThumbnails(items)
  return items
}

// ─── YouTube ─────────────────────────────────────────────────────────────────

async function fetchYouTube(source: Source): Promise<NormalizedItem[]> {
  const key = secret('YOUTUBE_API_KEY')
  if (!key) throw new Error('YOUTUBE_API_KEY not configured — YouTube integration is disabled')
  if (!source.externalId) throw new Error('Missing channel ID')

  // Resolve the channel's uploads playlist (UULF prefix = uploads-only playlist).
  const uploadsId = source.externalId.replace(/^UC/, 'UULF')
  const res = await fetch(
    `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet,contentDetails&maxResults=20&playlistId=${uploadsId}&key=${key}`,
    { signal: AbortSignal.timeout(15_000) }
  )
  if (res.status === 403 || res.status === 429) {
    throw new Error('YouTube API quota exceeded or restricted — serving cached data only')
  }
  if (!res.ok) throw new Error(`YouTube API HTTP ${res.status}`)
  const data = (await res.json()) as any
  const entries: any[] = data.items ?? []

  // Batch video details for durations.
  const videoIds = entries.map((e) => e.contentDetails?.videoId).filter(Boolean)
  const durations = new Map<string, number>()
  if (videoIds.length > 0) {
    try {
      const dres = await fetch(
        `https://www.googleapis.com/youtube/v3/videos?part=contentDetails&id=${videoIds.join(',')}&key=${key}`,
        { signal: AbortSignal.timeout(15_000) }
      )
      if (dres.ok) {
        const ddata = (await dres.json()) as any
        for (const v of ddata.items ?? []) {
          const secs = isoDurationToSeconds(v.contentDetails?.duration ?? '')
          if (secs) durations.set(v.id, secs)
        }
      }
    } catch {
      // durations are optional
    }
  }

  return entries
    .filter((e) => e.snippet?.title && e.snippet?.title !== 'Private video' && e.snippet?.title !== 'Deleted video')
    .map((e) => {
      const videoId = e.contentDetails?.videoId
      const title: string = decodeEntities(e.snippet.title)
      return {
        title: title.trim(),
        snippet: decodeEntities(stripHtml(e.snippet.description) ?? '')?.slice(0, 400) || null,
        url: videoId ? `https://www.youtube.com/watch?v=${videoId}` : source.websiteUrl ?? '',
        author: e.snippet.videoOwnerChannelTitle ?? e.snippet.channelTitle ?? source.name,
        thumbnailUrl:
          e.snippet.thumbnails?.high?.url ?? e.snippet.thumbnails?.medium?.url ?? e.snippet.thumbnails?.default?.url ?? null,
        durationSec: videoId ? durations.get(videoId) ?? null : null,
        publishedAt: new Date(e.snippet.publishedAt ?? e.contentDetails?.videoPublishedAt ?? Date.now()),
        contentHash: contentHash(`${source.name}:${title.trim()}`),
      }
    })
}

// ─── Instagram (honest link-out fallback — see spec §4.3) ────────────────────

/**
 * Instagram official API access requires business-account linkage + app review.
 * We do NOT scrape. Instagram sources are rendered as clearly-labeled link-out
 * cards in the UI; ingestion simply verifies the handle still resolves.
 */
async function checkInstagram(source: Source): Promise<NormalizedItem[]> {
  return []
}

// ─── Single-source ingestion with health tracking ────────────────────────────

export async function ingestSource(sourceId: string, opts: { force?: boolean } = {}): Promise<{ ok: boolean; newItems: number; items?: { id: string; title: string }[]; message?: string }> {
  const source = await db.source.findUnique({ where: { id: sourceId } })
  if (!source) return { ok: false, newItems: 0, message: 'Source not found' }
  if (!source.isActive) return { ok: false, newItems: 0, message: 'Source is disabled' }

  // Respect per-source interval unless forced.
  if (!opts.force && source.lastFetchedAt) {
    const dueAt = new Date(source.lastFetchedAt).getTime() + source.fetchIntervalMin * 60_000
    if (Date.now() < dueAt) return { ok: true, newItems: 0, message: 'Not due yet' }
  }

  const started = Date.now()
  let ok = false
  let newItems = 0
  let newItemsList: { id: string; title: string }[] | undefined
  let message: string | undefined

  try {
    let items: NormalizedItem[]
    if (source.type === 'rss') items = await fetchRss(source)
    else if (source.type === 'youtube') items = await fetchYouTube(source)
    else items = await checkInstagram(source)

    // Only insert items we don't already have (query existing hashes first).
    const recent = await db.contentItem.findMany({
      where: { sourceId: source.id },
      select: { contentHash: true },
      orderBy: { publishedAt: 'desc' },
      take: 400,
    })
    const existing = new Set(recent.map((r) => r.contentHash))
    const fresh = items.filter((i) => !existing.has(i.contentHash))

    if (fresh.length > 0) {
      const primaryTopic = (() => {
        try {
          return (JSON.parse(source.topicSlugs) as string[])[0] ?? 'world'
        } catch {
          return 'world'
        }
      })()
      const topicsJson = JSON.stringify([primaryTopic])
      try {
        await db.contentItem.createMany({
          data: fresh.map((i) => ({
            type: source.type === 'youtube' ? 'video' : source.type === 'instagram' ? 'instagram' : 'article',
            title: i.title.slice(0, 500),
            snippet: i.snippet,
            sourceId: source.id,
            author: i.author,
            url: i.url,
            thumbnailUrl: i.thumbnailUrl,
            durationSec: i.durationSec,
            language: source.language,
            country: source.country,
            topicSlugs: topicsJson,
            publishedAt: i.publishedAt,
            contentHash: i.contentHash,
          })),
        })
        newItems = fresh.length
        // Read back what landed so quiet-alert delivery can name the stories.
        const created = await db.contentItem.findMany({
          where: { sourceId: source.id, contentHash: { in: fresh.map((f) => f.contentHash) } },
          select: { id: true, title: true },
        })
        newItemsList = created.map((c) => ({ id: c.id, title: c.title }))
      } catch {
        // Fallback: row-by-row insert (handles rare concurrent duplicates).
        newItemsList = []
        for (const i of fresh) {
          try {
            const item = await db.contentItem.create({
              data: {
                type: source.type === 'youtube' ? 'video' : source.type === 'instagram' ? 'instagram' : 'article',
                title: i.title.slice(0, 500),
                snippet: i.snippet,
                sourceId: source.id,
                author: i.author,
                url: i.url,
                thumbnailUrl: i.thumbnailUrl,
                durationSec: i.durationSec,
                language: source.language,
                country: source.country,
                topicSlugs: topicsJson,
                publishedAt: i.publishedAt,
                contentHash: i.contentHash,
              },
            })
            newItems++
            newItemsList.push({ id: item.id, title: item.title })
          } catch {
            /* duplicate — ignore */
          }
        }
      }
    }

    ok = true
    await db.source.update({
      where: { id: source.id },
      data: {
        lastFetchedAt: new Date(),
        lastSuccessAt: new Date(),
        lastError: null,
        consecutiveFailures: 0,
        healthStatus: 'healthy',
        itemsIngested: { increment: newItems },
      },
    })
    await db.sourceHealthLog.create({
      data: { sourceId: source.id, status: 'success', itemCount: items.length, durationMs: Date.now() - started, message: newItems > 0 ? `${newItems} new items` : null },
    })
  } catch (err) {
    const failures = source.consecutiveFailures + 1
    message = err instanceof Error ? err.message : String(err)
    // Backoff schedule: after N consecutive failures the source is retried
    // every fetchInterval × min(N, 5) minutes. Degrades to 'error' fast.
    await db.source.update({
      where: { id: source.id },
      data: {
        lastFetchedAt: new Date(),
        lastError: message.slice(0, 500),
        consecutiveFailures: failures,
        healthStatus: failures >= 3 ? 'error' : 'degraded',
      },
    })
    await db.sourceHealthLog.create({
      data: { sourceId: source.id, status: 'error', message: message.slice(0, 500), durationMs: Date.now() - started },
    })
  }

  return { ok, newItems, items: newItemsList, message }
}

// ─── Orchestrator ────────────────────────────────────────────────────────────

async function runPool<T>(tasks: (() => Promise<T>)[], concurrency: number): Promise<void> {
  const queue = [...tasks]
  const workers = Array.from({ length: Math.min(concurrency, queue.length) }, async () => {
    while (queue.length > 0) {
      const task = queue.shift()
      if (!task) break
      await task().catch(() => {})
    }
  })
  await Promise.all(workers)
}

/** Run ingestion for every due active source. */
export async function runIngestion(opts: { force?: boolean; onlySourceId?: string } = {}): Promise<{ ingested: number; newItems: number; failed: number }> {
  if (ingestState.ingesting) return { ingested: 0, newItems: 0, failed: 0 }
  ingestState.ingesting = true
  const started = Date.now()

  try {
    const youtubeReady = !!secret('YOUTUBE_API_KEY')
    const sources = await db.source.findMany({
      where: opts.onlySourceId
        ? { id: opts.onlySourceId }
        : { isActive: true, ...(youtubeReady ? { type: { not: 'instagram' } } : { type: 'rss' }) },
    })

    const now = Date.now()
    const due = sources.filter((s) => {
      if (opts.force) return true
      if (!s.lastFetchedAt) return true
      // Exponential backoff on consecutive failures (×1, ×2, ×3… capped ×5).
      const backoff = Math.min(s.consecutiveFailures, 5)
      const dueAt = new Date(s.lastFetchedAt).getTime() + s.fetchIntervalMin * 60_000 * backoff
      return now >= dueAt
    })

    let newItems = 0
    let failed = 0
    const freshBySource = new Map<string, { source: Source; items: { id: string; title: string }[] }>()
    await runPool(
      due.map((s) => async () => {
        const r = await ingestSource(s.id, { force: opts.force })
        if (r.ok) {
          newItems += r.newItems
          if (r.items && r.items.length > 0) freshBySource.set(s.id, { source: s, items: r.items })
        } else failed++
      }),
      8
    )

    // Quiet alerts — one collapsed notification per source per run, sent
    // out-of-band so a slow push service never delays the pipeline.
    for (const { source, items } of freshBySource.values()) {
      void notifyUsersForSource(
        { id: source.id, name: source.name, slug: source.slug },
        items
      ).catch((err) => console.error('[push] dispatch failed:', err))
    }

    ingestState.lastRunAt = new Date()
    ingestState.lastFullRunMs = Date.now() - started
    ingestState.lastError = failed > 0 ? `${failed} sources failed this cycle` : null

    if (newItems > 0) bumpDataEpoch()
    return { ingested: due.length, newItems, failed }
  } finally {
    ingestState.ingesting = false
  }
}

/** Delete items older than RETENTION_DAYS (default 14) to keep the DB lean. */
export async function pruneOldItems(): Promise<number> {
  const days = Number(process.env.RETENTION_DAYS || 14)
  const cutoff = new Date(Date.now() - days * 86_400_000)
  const res = await db.contentItem.deleteMany({ where: { publishedAt: { lt: cutoff } } })
  return res.count
}

/** Bootstrap: first full ingestion after server start (idempotent). */
export async function bootstrapIngestion(): Promise<void> {
  if (globalForIngest.__newswire_bootstrapped) return
  globalForIngest.__newswire_bootstrapped = true
  ingestState.youtubeEnabled = !!secret('YOUTUBE_API_KEY')

  const itemCount = await db.contentItem.count()
  if (itemCount < 50) {
    // Fresh database → force a full first ingest so the terminal opens with data.
    await runIngestion({ force: true })
    await pruneOldItems().catch(() => {})
  }
}

/** Start the background scheduler loop (every 60s tick; sources run when due). */
export function startScheduler(): void {
  if (globalForIngest.__newswire_scheduler) return
  globalForIngest.__newswire_scheduler = setInterval(async () => {
    try {
      await runIngestion()
    } catch (err) {
      console.error('[scheduler] ingest cycle failed:', err)
    }
    // Hourly prune.
    if (new Date().getMinutes() === 0) {
      await pruneOldItems().catch(() => {})
    }
  }, 60_000)
  // Don't keep the process alive just for the scheduler in dev.
  globalForIngest.__newswire_scheduler.unref?.()
  console.log('[scheduler] news ingestion loop started (tick every 60s)')
}

/**
 * Idempotent lazy-start — safe to call from any API route. Guarantees the
 * scheduler runs even if instrumentation.ts didn't fire on this boot.
 */
export function ensureSchedulerStarted(): void {
  ingestState.youtubeEnabled = !!secret('YOUTUBE_API_KEY')
  startScheduler()
  if (!globalForIngest.__newswire_bootstrapped) {
    globalForIngest.__newswire_bootstrapped = true
    void bootstrapIngestion().catch((err) => console.error('[bootstrap] failed:', err))
  }
}
