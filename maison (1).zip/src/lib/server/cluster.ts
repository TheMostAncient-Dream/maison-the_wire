/**
 * Story clustering engine.
 * - Normalizes titles and computes content hashes for exact/near-duplicate detection.
 * - Clusters recent items into "stories" when multiple outlets cover the same event
 *   (token-set similarity with inverted-index candidate lookup).
 * - Scores stories for Featured / Trending: cross-source coverage × source
 *   prominence × recency decay.
 */
import { createHash } from 'crypto'
import type { ItemDTO, StoryClusterDTO } from '@/lib/types'

const STOPWORDS = new Set(
  ('a,an,and,are,as,at,be,by,for,from,has,have,he,her,his,how,i,in,is,it,its,of,on,or,' +
    'she,that,the,their,they,this,to,was,were,will,with,what,when,where,who,whom,why,' +
    'after,before,between,during,over,under,again,further,then,once,here,there,all,any,' +
    'both,each,few,more,most,other,some,such,no,nor,not,only,own,same,so,than,too,very,' +
    'can,just,should,now,says,say,said,new,report,reports,live,updates,latest,video,watch,' +
    'news,amid,amid,against,about,into,up,down,out,off,per,via,am,pm,gt,bst,est,update')
    .split(',')
)

export function normalizeTitle(title: string): string {
  return title
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // strip diacritics
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

export function contentHash(title: string): string {
  return createHash('sha1').update(normalizeTitle(title)).digest('hex')
}

export function tokenize(title: string): string[] {
  return normalizeTitle(title)
    .split(' ')
    .filter((t) => t.length > 2 && !STOPWORDS.has(t))
}

function jaccard(a: Set<string>, b: Set<string>): number {
  let shared = 0
  for (const t of a) if (b.has(t)) shared++
  const union = a.size + b.size - shared
  return union === 0 ? 0 : shared / union
}

interface StoryCluster {
  id: string
  tokens: Set<string>
  items: ItemDTO[]
  sourceSlugs: Set<string>
  score: number
  latest: number
  primaryTopic: string
}

/** Recency decay: exponential half-life of 6 hours. */
function recencyDecay(publishedAtMs: number, nowMs: number): number {
  const hours = Math.max(0, (nowMs - publishedAtMs) / 3_600_000)
  return Math.pow(0.5, hours / 6)
}

const SIMILARITY_THRESHOLD = 0.42

/**
 * Cluster items into stories. Items within `windowHours` are candidates;
 * matching uses an inverted index so comparisons stay sub-quadratic in practice.
 */
export function clusterItems(items: ItemDTO[], windowHours = 72): ItemDTO[][] {
  const now = Date.now()
  const candidates = items.filter(
    (i): i is ItemDTO & { type: 'article' | 'video' } =>
      now - new Date(i.publishedAt).getTime() < windowHours * 3_600_000 &&
      (i.type === 'article' || i.type === 'video')
  )

  const clusters: StoryCluster[] = []

  // Inverted index token → cluster indices, keeps comparisons cheap.
  const index = new Map<string, number[]>()

  for (const item of candidates) {
    const tokens = new Set(tokenize(item.title))
    if (tokens.size === 0) continue

    // Candidate clusters = clusters sharing ≥2 significant tokens.
    const hits = new Map<number, number>()
    for (const t of tokens) {
      const ids = index.get(t)
      if (!ids) continue
      for (const id of ids) hits.set(id, (hits.get(id) ?? 0) + 1)
    }

    let best: { cluster: StoryCluster; sim: number } | null = null
    for (const [clusterIdx] of hits) {
      const cluster = clusters[clusterIdx]
      if (!cluster) continue
      const sim = jaccard(tokens, cluster.tokens)
      if (sim >= SIMILARITY_THRESHOLD && (!best || sim > best.sim)) {
        best = { cluster, sim }
      }
    }

    if (best) {
      const cluster = best.cluster
      cluster.items.push(item)
      cluster.sourceSlugs.add(item.source.slug)
      for (const t of tokens) cluster.tokens.add(t)
      const published = new Date(item.publishedAt).getTime()
      if (published > cluster.latest) cluster.latest = published
    } else {
      const cluster: StoryCluster = {
        id: `c-${clusters.length}-${normalizeTitle(item.title).slice(0, 40)}`,
        tokens,
        items: [item],
        sourceSlugs: new Set([item.source.slug]),
        score: 0,
        latest: new Date(item.publishedAt).getTime(),
        primaryTopic: item.topicSlugs[0] ?? 'world',
      }
      clusters.push(cluster)
      const idx = clusters.length - 1
      for (const t of tokens) {
        const ids = index.get(t)
        if (ids) ids.push(idx)
        else index.set(t, [idx])
      }
    }
  }

  return clusters.map((c) => c.items)
}

/**
 * Score and rank story clusters.
 * score = Σ over items ( sourceProminence × recencyDecay ) + 1.5 × distinctSources
 */
export function scoreClusters(items: ItemDTO[], windowHours = 48): { stories: ItemDTO[][]; singles: ItemDTO[] } {
  const now = Date.now()
  const groups = clusterItems(items, windowHours)
  const scored: { items: ItemDTO[]; score: number; latest: number; sources: number }[] = []
  const singles: ItemDTO[] = []

  for (const g of groups) {
    const first = g[0]
    if (first.type !== 'article' && first.type !== 'video') continue
    let score = 0
    let latest = 0
    const sources = new Set<string>()
    for (const item of g) {
      const published = new Date(item.publishedAt).getTime()
      latest = Math.max(latest, published)
      sources.add(item.source.slug)
      score += item.source.prominence * recencyDecay(published, now)
    }
    score += 1.5 * sources.size
    if (g.length > 0) scored.push({ items: g, score, latest, sources: sources.size })
  }

  scored.sort((a, b) => b.score - a.score || b.latest - a.latest)

  const stories = scored.filter((s) => s.sources >= 2 || s.items.length >= 2)
  const lonely = scored.filter((s) => s.sources < 2 && s.items.length < 2)
  singles.push(...lonely.map((s) => s.items[0]).filter((i): i is ItemDTO => !!i))

  return { stories: stories.map((s) => s.items), singles }
}

/** Build a StoryClusterDTO list (used by /api/featured). */
export function buildStoryClusters(items: ItemDTO[], limit: number, windowHours = 48): StoryClusterDTO[] {
  const { stories, singles } = scoreClusters(items, windowHours)
  const now = Date.now()
  const editorialStories = stories
    .map((members) => members.filter((item): item is ItemDTO & { type: 'article' | 'video' } =>
      item.type === 'article' || item.type === 'video'
    ))
    .filter((members) => members.length > 0)
  const result: StoryClusterDTO[] = editorialStories.slice(0, limit).map((members) => {
    members.sort((a, b) => {
      const byScore = b.source.prominence - a.source.prominence
      if (byScore !== 0) return byScore
      return new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
    })
    const lead = members[0]
    let score = 0
    for (const m of members) {
      score += m.source.prominence * recencyDecay(new Date(m.publishedAt).getTime(), now)
    }
    return {
      id: lead.id,
      title: lead.title,
      score: Math.round(score * 10) / 10,
      publishedAt: members.reduce(
        (acc, m) => (new Date(m.publishedAt) > new Date(acc) ? m.publishedAt : acc),
        members[0].publishedAt
      ),
      primaryTopic: lead.topicSlugs[0] ?? 'world',
      type: lead.type,
      items: members.slice(0, 8),
    }
  })

  // Fill shortfall with high-signal single items so featured never looks empty.
  const editorialSingles = singles.filter(
    (item): item is ItemDTO & { type: 'article' | 'video' } => item.type === 'article' || item.type === 'video'
  )
  const shortfall = limit - result.length
  if (shortfall > 0) {
    for (const single of editorialSingles.slice(0, shortfall)) {
      result.push({
        id: single.id,
        title: single.title,
        score: 0,
        publishedAt: single.publishedAt,
        primaryTopic: single.topicSlugs[0] ?? 'world',
        type: single.type,
        items: [single],
      })
    }
  }

  return result
}
