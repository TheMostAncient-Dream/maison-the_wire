/**
 * Secrets that survive the host pipeline rewriting env files on publish
 * (observed: .env rewritten, .env.local deleted). Resolution order:
 *   1. process.env — proper deployments, as documented in .env.example
 *   2. db/.secrets.json (0600) — durable store the pipeline leaves alone,
 *      seeded by the operator; this module only reads, never writes.
 * No known-string fallbacks: an unresolvable name simply returns undefined
 * and the feature degrades the way a missing env var always has.
 */
import { existsSync, readFileSync } from 'fs'
import { join } from 'path'

let fileCache: Record<string, string> | null = null

function loadFile(): Record<string, string> {
  if (fileCache) return fileCache
  const file = join(process.cwd(), 'db', '.secrets.json')
  try {
    fileCache = existsSync(file) ? JSON.parse(readFileSync(file, 'utf8')) : {}
  } catch {
    fileCache = {}
  }
  return fileCache ?? {}
}

export function secret(name: string): string | undefined {
  const fromEnv = process.env[name]
  if (fromEnv) return fromEnv
  const fromFile = loadFile()[name]
  return typeof fromFile === 'string' && fromFile.length > 0 ? fromFile : undefined
}
