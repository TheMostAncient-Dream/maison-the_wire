/**
 * Email verification — the timed mechanics of proving an address.
 *
 * A registration issues a 6-digit code that dies in 15 minutes (tunable
 * MAIL_CODE_TTL_MIN); resends wait out a 60-second cooldown
 * (MAIL_RESEND_COOLDOWN_SEC). Codes are stored as scrypt hashes — they are
 * passwords, not tokens.
 *
 * Transport, honestly: no mail desk is attached to this press yet. The
 * console transport sets the letter into the server log (dev.log follows
 * stdout). There is no pretend SMTP switch — when a real mailer arrives it
 * joins `deliver()` as a second transport and the log line becomes the
 * fallback. In dev (and only dev, unless MAIL_DEV_EXPOSE is forced) the
 * freshly issued code is also remembered in-memory so the verify screen can
 * show it as the "demo post" — the server log stays the source of truth.
 */
import { randomInt } from 'crypto'
import { db } from '@/lib/db'
import { hashPassword } from './auth'

export const CODE_TTL_MS = (Number(process.env.MAIL_CODE_TTL_MIN) || 15) * 60_000
export const RESEND_COOLDOWN_MS = (Number(process.env.MAIL_RESEND_COOLDOWN_SEC) || 60) * 1000

const DEV_EXPOSE_CODE =
  process.env.NODE_ENV !== 'production' && process.env.MAIL_DEV_EXPOSE !== 'false'

/** Dev-only memo of freshly issued codes, so the verify screen can show the
 *  "demo post" even after a page reload. Never populated in production. */
const devMemo = new Map<string, string>()

function rememberDevCode(userId: string, code: string) {
  if (!DEV_EXPOSE_CODE) return
  if (devMemo.size > 500) {
    const oldest = devMemo.keys().next().value
    if (oldest) devMemo.delete(oldest)
  }
  devMemo.set(userId, code)
}

/** Set a fresh code into the world: hashed at rest, logged in transit. */
export async function issueEmailVerification(
  userId: string,
  email: string
): Promise<{ expiresAt: number; sentAt: number; devCode?: string }> {
  const code = String(randomInt(0, 1_000_000)).padStart(6, '0')
  const sentAt = new Date()
  const expiresAt = new Date(sentAt.getTime() + CODE_TTL_MS)
  await db.user.update({
    where: { id: userId },
    data: {
      verificationCodeHash: hashPassword(code),
      verificationExpiresAt: expiresAt,
      verificationSentAt: sentAt,
    },
  })
  // The console transport — the letter is set into the server log.
  console.log(
    `[mail:console] to=${email} subject="Your MAISON verification code" code=${code} (valid ${Math.round(CODE_TTL_MS / 60_000)} minutes)`
  )
  rememberDevCode(userId, code)
  const out: { expiresAt: number; sentAt: number; devCode?: string } = {
    expiresAt: expiresAt.getTime(),
    sentAt: sentAt.getTime(),
  }
  if (DEV_EXPOSE_CODE) out.devCode = code
  return out
}

/** The pending-code snapshot for the status endpoint (no code material —
 *  only the dev memo may surface one, and only in dev). */
export function verificationSnapshot(user: {
  emailVerifiedAt: Date | null
  verificationExpiresAt: Date | null
  verificationSentAt: Date | null
  id: string
}): {
  verified: boolean
  expiresAt: number | null
  resendAfter: number
  devCode?: string
} {
  if (user.emailVerifiedAt) return { verified: true, expiresAt: null, resendAfter: 0 }
  const expiresAt = user.verificationExpiresAt?.getTime() ?? null
  const resendAfter = user.verificationSentAt
    ? user.verificationSentAt.getTime() + RESEND_COOLDOWN_MS
    : 0
  const out: { verified: boolean; expiresAt: number | null; resendAfter: number; devCode?: string } =
    { verified: false, expiresAt, resendAfter }
  if (DEV_EXPOSE_CODE && expiresAt && expiresAt > Date.now()) {
    const memo = devMemo.get(user.id)
    if (memo) out.devCode = memo
  }
  return out
}
