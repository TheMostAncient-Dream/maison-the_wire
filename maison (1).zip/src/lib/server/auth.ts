/**
 * Session auth — HMAC-signed tokens in httpOnly cookies.
 * Passwords hashed with scrypt (salt:hash). No secrets client-side.
 */
import { createHmac, timingSafeEqual, scryptSync, randomBytes } from 'crypto'
import { existsSync, readFileSync, writeFileSync } from 'fs'
import { join } from 'path'
import { cookies } from 'next/headers'
import { db } from '@/lib/db'
import type { SessionUser } from '@/lib/types'

/**
 * AUTH_SECRET resolution order:
 *   1. process.env.AUTH_SECRET (proper deployments — see .env.example)
 *   2. db/.auth-secret — a random 32-byte secret generated on first boot and
 *      persisted 0600. This exists because the host pipeline rewrites env
 *      files on publish (observed twice wiping .env / deleting .env.local),
 *      which would otherwise brick the boot and invalidate every session.
 * A known string is still never used; if no secret can be sourced at all,
 * the app refuses to start, as before.
 */
function resolveSecret(): string {
  const fromEnv = process.env.AUTH_SECRET
  if (fromEnv && fromEnv.length >= 32) return fromEnv

  // A container filesystem is ephemeral: per-instance fallback keys would
  // revoke sessions on restart and can differ across overlapping instances.
  if (process.env.NODE_ENV === 'production') {
    throw new Error('AUTH_SECRET must be configured (at least 32 characters) in production')
  }

  const file = join(process.cwd(), 'db', '.auth-secret')
  try {
    if (existsSync(file)) {
      const fromFile = readFileSync(file, 'utf8').trim()
      if (fromFile.length >= 32) return fromFile
    }
    const generated = randomBytes(32).toString('base64')
    writeFileSync(file, generated, { mode: 0o600 })
    console.warn('[auth] AUTH_SECRET absent — generated and persisted db/.auth-secret (set AUTH_SECRET to override)')
    return generated
  } catch {
    throw new Error(
      'AUTH_SECRET is missing and db/.auth-secret could not be created — the app refuses to start. Generate one with: openssl rand -base64 32'
    )
  }
}
const SECRET = resolveSecret()
export const SESSION_COOKIE = 'nw_session'
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 30 // 30 days

function sign(payload: string): string {
  return createHmac('sha256', SECRET).update(payload).digest('base64url')
}

/**
 * The token carries the user's sessionVersion at issue time; verifyToken
 * alone checks signature + expiry, and getSessionUser compares `sv` against
 * the live DB value — bumping sessionVersion invalidates every existing
 * token for that user ("sign out everywhere", admin-forced logout).
 */
export function createToken(userId: string, sessionVersion: number): string {
  const payload = Buffer.from(
    JSON.stringify({ sub: userId, exp: Date.now() + SESSION_TTL_MS, sv: sessionVersion })
  ).toString('base64url')
  return `${payload}.${sign(payload)}`
}

export function verifyToken(token: string): { sub: string; sv: number } | null {
  const [payload, sig] = token.split('.')
  if (!payload || !sig) return null
  const expected = sign(payload)
  const a = Buffer.from(sig)
  const b = Buffer.from(expected)
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null
  try {
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString())
    if (typeof data.sub !== 'string' || typeof data.exp !== 'number') return null
    if (typeof data.sv !== 'number') return null // pre-versioning tokens are invalid
    if (Date.now() > data.exp) return null
    return { sub: data.sub, sv: data.sv }
  } catch {
    return null
  }
}

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex')
  return `${salt}:${scryptSync(password, salt, 64).toString('hex')}`
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(':')
  if (!salt || !hash) return false
  const candidate = scryptSync(password, salt, 64)
  const expected = Buffer.from(hash, 'hex')
  return candidate.length === expected.length && timingSafeEqual(candidate, expected)
}

/** Read session from cookies → user or null. Rejects tokens whose
 *  sessionVersion no longer matches the live user row. */
export async function getSessionUser(): Promise<SessionUser | null> {
  try {
    const jar = await cookies()
    const token = jar.get(SESSION_COOKIE)?.value
    if (!token) return null
    const claims = verifyToken(token)
    if (!claims) return null
    const user = await db.user.findUnique({ where: { id: claims.sub } })
    if (!user) return null
    if (user.sessionVersion !== claims.sv) return null // revoked (signed out everywhere)
    return {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      onboarded: user.onboardingCompletedAt != null,
      emailVerified: user.emailVerifiedAt != null,
    }
  } catch {
    return null
  }
}

export async function requireAdmin(): Promise<SessionUser | null> {
  const user = await getSessionUser()
  return user && user.role === 'admin' ? user : null
}

/*
 * Preview is HTTPS at the browser even when its proxy reaches this server over
 * HTTP. Default to Secure/SameSite=None; only opt into insecure Lax cookies
 * for a deliberate plain-HTTP local-network development session.
 */
const allowLocalHttpCookies = process.env.MAISON_ALLOW_HTTP_LOCAL_COOKIES === 'true'

export const sessionCookieOptions = {
  httpOnly: true,
  sameSite: allowLocalHttpCookies ? ('lax' as const) : ('none' as const),
  secure: !allowLocalHttpCookies,
  path: '/',
  maxAge: SESSION_TTL_MS / 1000,
}
