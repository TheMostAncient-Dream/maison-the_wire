/**
 * The Webdev managed MySQL DSN includes a Node-style `ssl` JSON option.
 * Prisma's MySQL connector uses `sslaccept=strict` instead. Translate only the
 * platform's explicit peer-verification=true option; never downgrade TLS.
 */
export function prismaDatabaseUrl(raw = process.env.DATABASE_URL): string {
  if (!raw) throw new Error('DATABASE_URL is required.')

  let url: URL
  try {
    url = new URL(raw)
  } catch {
    throw new Error('DATABASE_URL is not a valid connection URL.')
  }

  if (url.protocol !== 'mysql:') return raw

  const sslOptions = url.searchParams.getAll('ssl')
  if (sslOptions.length === 0) {
    if (process.env.NODE_ENV === 'production' && url.searchParams.get('sslaccept') !== 'strict') {
      throw new Error('Production MySQL must use strict TLS certificate verification.')
    }
    return raw
  }

  if (sslOptions.length !== 1 || url.searchParams.has('sslaccept')) {
    throw new Error('DATABASE_URL contains conflicting TLS options; connection refused.')
  }

  let settings: unknown
  try {
    settings = JSON.parse(sslOptions[0])
  } catch {
    throw new Error('DATABASE_URL contains an unsupported TLS option; connection refused.')
  }

  if (
    !settings ||
    typeof settings !== 'object' ||
    Array.isArray(settings) ||
    Object.keys(settings).length !== 1 ||
    (settings as { rejectUnauthorized?: unknown }).rejectUnauthorized !== true
  ) {
    throw new Error('MySQL TLS peer verification must remain enabled; connection refused.')
  }

  url.searchParams.delete('ssl')
  url.searchParams.set('sslaccept', 'strict')
  return url.toString()
}
