/**
 * Web Push delivery — VAPID-based, no third-party service account.
 *
 * After each ingestion run, every user who has the source in their
 * notifySourceIds (and a stored PushSubscription) receives ONE collapsed
 * notification per source per run — "3 new stories from BBC News", not
 * three separate pings. Per-user volume is further bounded: the same
 * source cannot ping the same reader more than once per quiet window,
 * even across consecutive ingestion cycles.
 *
 * Subscriptions whose endpoint comes back expired (410 Gone / 404) are
 * pruned so the table never accumulates dead rows.
 */
import webpush from 'web-push'
import { db } from '@/lib/db'

const VAPID_PUBLIC = process.env.VAPID_PUBLIC_KEY
const VAPID_PRIVATE = process.env.VAPID_PRIVATE_KEY
const VAPID_SUBJECT = process.env.VAPID_SUBJECT || 'mailto:desk@maison.press'

let configured = false
if (VAPID_PUBLIC && VAPID_PRIVATE) {
  try {
    webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC, VAPID_PRIVATE)
    configured = true
  } catch (err) {
    console.error('[push] invalid VAPID keys — push disabled:', err)
  }
} else {
  console.warn('[push] VAPID keys not set — quiet alerts are disabled (see .env.example)')
}

export function isPushConfigured(): boolean {
  return configured
}

/** Quiet window — one push per source per user per this many ms. */
const PER_SOURCE_WINDOW_MS = 15 * 60_000
// ponytail: in-memory quiet window + JSON-column reader match — both single-
// process conveniences. Upgrade path: Redis for the window, a join table for
// the match (see /api/notifications) if this ever leaves one box.
const lastSent = new Map<string, number>() // `${userId}:${sourceId}` → epoch ms

export interface PushItem {
  id: string
  title: string
}

/**
 * Notify every subscriber of this source about the newly-ingested items.
 * One notification per user per source per run; fires-and-forgets so a
 * slow push service never delays the ingestion pipeline.
 */
export async function notifyUsersForSource(
  source: { id: string; name: string; slug: string },
  newItems: PushItem[]
): Promise<void> {
  if (!configured || newItems.length === 0) return
  try {
    const count = newItems.length
    const first = newItems[0]
    const displayTitle =
      count === 1 ? `${source.name} — new story` : `${source.name} — ${count} new stories`
    const payload = JSON.stringify({
      displayTitle,
      body: first.title,
      sourceId: source.id,
      sourceName: source.name,
      count,
      itemId: first.id,
      url: `/?item=${first.id}`,
    })

    // Readers with at least one alerting desk. notifySourceIds is a JSON
    // string array (the schema's list convention); match ids in JS. Fine at
    // this scale; a join table
    // is the move if the reader base grows.
    const candidates = await db.user.findMany({
      where: { notifySourceIds: { not: '[]' }, onboardingCompletedAt: { not: null } },
      select: { id: true, notifySourceIds: true, pushSubscriptions: true },
    })

    const now = Date.now()
    let pruned = 0
    const sends: Promise<unknown>[] = []
    for (const user of candidates) {
      let ids: string[] = []
      try {
        ids = JSON.parse(user.notifySourceIds) as string[]
      } catch {
        continue
      }
      if (!ids.includes(source.id)) continue

      // Quiet window — even across multiple ingestion cycles.
      const key = `${user.id}:${source.id}`
      const last = lastSent.get(key) ?? 0
      if (now - last < PER_SOURCE_WINDOW_MS) continue
      lastSent.set(key, now)

      for (const sub of user.pushSubscriptions) {
        sends.push(
          webpush
            .sendNotification(
              { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
              payload,
              { TTL: 3600, urgency: 'normal' }
            )
            .catch((err: (Error & { statusCode?: number }) | undefined) => {
              const status = err?.statusCode
              if (status === 404 || status === 410) {
                // Expired subscription — prune so dead rows don't accumulate.
                return db.pushSubscription
                  .deleteMany({ where: { endpoint: sub.endpoint } })
                  .then((r) => {
                    pruned += r.count
                  })
              }
              console.warn(`[push] delivery failed (${status ?? 'no status'}):`, err?.message)
            })
        )
      }
    }
    await Promise.all(sends)
    if (sends.length > 0) {
      console.log(
        `[push] ${displayTitle} → ${sends.length} subscription(s)${pruned ? `, pruned ${pruned} dead` : ''}`
      )
    }
  } catch (err) {
    // Push is a courtesy layer — never let it break ingestion.
    console.error('[push] notifyUsersForSource failed:', err)
  }
}
