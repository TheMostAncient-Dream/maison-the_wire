/**
 * In-memory TTL cache + data epoch invalidation + sliding-window rate limiter.
 * (Single-process deployment; swap for Redis when scaling horizontally.)
 */

interface CacheEntry<T> {
  value: T
  expiresAt: number
  epoch: number
}

const store = new Map<string, CacheEntry<unknown>>()

/** Bumped after every ingestion run — auto-invalidates all cached queries. */
let dataEpoch = 0
export function bumpDataEpoch() {
  dataEpoch++
}
export function getDataEpoch() {
  return dataEpoch
}

export function cacheGet<T>(key: string): T | null {
  const entry = store.get(key) as CacheEntry<T> | undefined
  if (!entry) return null
  if (entry.expiresAt < Date.now() || entry.epoch !== dataEpoch) {
    store.delete(key)
    return null
  }
  return entry.value
}

export function cacheSet<T>(key: string, value: T, ttlMs: number): void {
  store.set(key, { value, expiresAt: Date.now() + ttlMs, epoch: dataEpoch })
}

/** Wrap an async producer with cache. */
export async function cached<T>(key: string, ttlMs: number, producer: () => Promise<T>): Promise<T> {
  const hit = cacheGet<T>(key)
  if (hit !== null) return hit
  const value = await producer()
  cacheSet(key, value, ttlMs)
  return value
}

// ─── Rate limiting ────────────────────────────────────────────────────────────

const buckets = new Map<string, number[]>()

/**
 * Sliding-window limiter. Returns true when allowed.
 * @param key     unique key, e.g. `ip:route`
 * @param limit   max requests per window
 * @param windowMs window size
 */
export function rateLimit(key: string, limit: number, windowMs: number): boolean {
  const now = Date.now()
  const arr = (buckets.get(key) ?? []).filter((t) => t > now - windowMs)
  if (arr.length >= limit) {
    buckets.set(key, arr)
    return false
  }
  arr.push(now)
  buckets.set(key, arr)
  if (buckets.size > 5000) {
    // periodic cleanup of stale buckets
    for (const [k, v] of buckets) {
      if (!v.some((t) => t > now - windowMs)) buckets.delete(k)
    }
  }
  return true
}

export function clientIp(req: Request): string {
  const fwd = req.headers.get('x-forwarded-for')
  if (fwd) return fwd.split(',')[0].trim()
  return req.headers.get('x-real-ip') || 'local'
}
