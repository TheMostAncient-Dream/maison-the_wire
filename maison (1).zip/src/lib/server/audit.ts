/**
 * Admin audit trail — one row per admin mutation, written from the
 * admin routes. Best-effort: an audit write must never break the
 * mutation it records.
 */
import { db } from '@/lib/db'

export async function logAdminAction(
  actorUserId: string,
  action: string,
  targetId?: string | null,
  detail?: string | null
): Promise<void> {
  try {
    await db.adminAuditLog.create({
      data: {
        actorUserId,
        action,
        targetId: targetId ?? null,
        detail: detail ? detail.slice(0, 500) : null,
      },
    })
  } catch {
    /* the ledger never blocks the presses */
  }
}
