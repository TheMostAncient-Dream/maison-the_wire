/**
 * Story briefs — pull the full article text from the publisher's page and
 * distill it into an editorial gist + the important details via LLM.
 * Server-only module: never throws to callers, degrades to null.
 */

import ZAI from "z-ai-web-dev-sdk";
import { isPrivateHost } from "./image";

export interface StoryBrief {
  brief: string;
  keyPoints: string[];
}

// ─── HTML text helpers ───────────────────────────────────────────────────────

const BROWSER_UA =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

const NAMED_ENTITIES: Record<string, string> = {
  amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " ",
  ndash: "–", mdash: "—", hellip: "…", rsquo: "’", lsquo: "‘",
  rdquo: "”", ldquo: "“", bull: "•", middot: "·", copy: "©",
  reg: "®", trade: "™", eacute: "é", egrave: "è", agrave: "à",
  ccedil: "ç", uuml: "ü", ouml: "ö", auml: "ä", szlig: "ß", pound: "£", euro: "€",
};

/** Decode text-level HTML entities (`&rsquo;`, `&#8217;`, `&#x2019;` …). */
export function decodeHtmlEntities(raw: string): string {
  return raw.replace(/&(#x?[0-9a-fA-F]+|[a-zA-Z]+);/g, (ent, body: string) => {
    if (body.startsWith("#x") || body.startsWith("#X")) {
      const code = parseInt(body.slice(2), 16);
      return Number.isFinite(code) ? String.fromCodePoint(code) : ent;
    }
    if (body.startsWith("#")) {
      const code = parseInt(body.slice(1), 10);
      return Number.isFinite(code) ? String.fromCodePoint(code) : ent;
    }
    return NAMED_ENTITIES[body.toLowerCase()] ?? ent;
  });
}

/** Collapse whitespace, drop control chars — make text print-ready. */
function cleanText(s: string): string {
  return decodeHtmlEntities(s)
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

// ─── Article text extraction ─────────────────────────────────────────────────

const STRIP_BLOCKS =
  /<(script|style|noscript|svg|nav|header|footer|form|aside|iframe|figure|button|select|template)\b[\s\S]*?<\/\1>/gi;
const HTML_COMMENT = /<!--[\s\S]*?-->/g;

/**
 * Fetch an article page and extract the body paragraphs. Streaming, capped
 * at ~900 KB; blocks likely to be boilerplate are stripped first so only
 * narrative prose remains. Returns null on any failure; never throws.
 */
export async function extractArticleText(
  pageUrl: string,
  timeoutMs = 12_000,
): Promise<string | null> {
  try {
    const parsed = new URL(pageUrl);
    if (!/^https?:$/.test(parsed.protocol) || isPrivateHost(parsed.hostname)) return null;

    const res = await fetch(parsed, {
      headers: {
        "User-Agent": BROWSER_UA,
        Accept: "text/html,application/xhtml+xml;q=0.9,*/*;q=0.5",
        "Accept-Language": "en-US,en;q=0.9",
      },
      redirect: "follow",
      signal: AbortSignal.timeout(timeoutMs),
      cache: "no-store",
    });
    if (!res.ok) return null;

    const reader = res.body?.getReader();
    if (!reader) return null;
    const decoder = new TextDecoder();
    let html = "";
    let received = 0;
    const LIMIT = 900_000;
    while (received < LIMIT) {
      const { done, value } = await reader.read();
      if (done) break;
      received += value.byteLength;
      html += decoder.decode(value, { stream: true });
      if (/<\/body>/i.test(html)) break;
    }
    reader.cancel().catch(() => {});
    if (html.length < 500) return null;

    // JSON-LD articleBody shortcut — several publishers bury the whole text there.
    const ldMatch =
      html.match(/"articleBody"\s*:\s*"((?:[^"\\]|\\.)*)"/) ??
      html.match(/"description"\s*:\s*"((?:[^"\\]|\\.){200,})"/);
    if (ldMatch) {
      try {
        const text = cleanText(JSON.parse(`"${ldMatch[1]}"`));
        if (text.length >= 400) return text.slice(0, 14_000);
      } catch {
        /* fall through to <p> extraction */
      }
    }

    // Classic extraction: strip boilerplate blocks, keep long <p> prose.
    const body = html.replace(HTML_COMMENT, " ").replace(STRIP_BLOCKS, " ");
    const paragraphs: string[] = [];
    const pRe = /<p\b[^>]*>([\s\S]*?)<\/p>/gi;
    let m: RegExpExecArray | null;
    while ((m = pRe.exec(body)) !== null) {
      const text = cleanText(m[1].replace(/<[^>]+>/g, " "));
      if (text.length >= 45 && !/^(advertisement|subscribe|read more|sign up|share this)/i.test(text)) {
        paragraphs.push(text);
      }
      if (paragraphs.length >= 120) break;
    }
    const joined = paragraphs.join("\n\n");
    if (joined.length < 200) return null;
    return joined.slice(0, 14_000);
  } catch {
    return null;
  }
}

// ─── LLM distillation ────────────────────────────────────────────────────────

let zaiPromise: Promise<ZAI> | null = null;
function getZai() {
  zaiPromise ??= ZAI.create();
  return zaiPromise;
}

const SYSTEM_PROMPT = [
  "You are the senior editor of MAISON, an editorial news digest.",
  "You distill news stories into precise, elegant briefs for busy readers.",
  "Absolute rules:",
  "- Use ONLY facts present in the provided material. Never invent names, numbers, dates or claims.",
  "- Write in clear English, regardless of the source language.",
  "- Prefer saying less over speculating.",
].join("\n");

function userPrompt(input: {
  title: string;
  sourceName: string;
  type: string;
  publishedAt?: string;
  material: string;
}): string {
  return [
    `Distill this story for the morning briefing.`,
    ``,
    `Headline: ${input.title}`,
    `Outlet: ${input.sourceName}`,
    input.publishedAt ? `Published: ${input.publishedAt}` : "",
    `Format: ${input.type === "video" ? "video report" : "news article"}`,
    ``,
    `Material:`,
    `──────────────────`,
    input.material.slice(0, 14_000),
    `──────────────────`,
    ``,
    `Return STRICT JSON only — no markdown fences, no commentary:`,
    `{"brief": "2-4 sentence gist: what happened, who is involved, and why it matters", "keyPoints": ["2 to 6 concrete important details — only as many as the material genuinely supports: numbers, names, dates, places, decisions, quotes; each a standalone factual sentence under 160 characters"]}`,
  ]
    .filter(Boolean)
    .join("\n");
}

/** Tolerant JSON extraction — models occasionally add fences or prose. */
function parseBriefJson(raw: string): StoryBrief | null {
  if (!raw) return null;
  let text = raw.trim().replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start === -1 || end <= start) return null;
  text = text.slice(start, end + 1);

  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    return null;
  }
  if (typeof parsed !== "object" || parsed === null) return null;
  const obj = parsed as Record<string, unknown>;

  const brief = typeof obj.brief === "string" ? cleanText(obj.brief) : "";
  if (brief.length < 40 || brief.length > 900) return null;

  const keyPoints = Array.isArray(obj.keyPoints)
    ? obj.keyPoints
        .filter((k): k is string => typeof k === "string")
        .map((k) => cleanText(k))
        .filter((k) => k.length >= 8 && k.length <= 240)
        .slice(0, 6)
    : [];

  return { brief, keyPoints };
}

/**
 * Distill a story into {brief, keyPoints}. Returns null when there is not
 * enough material or the model call fails — the UI then falls back to the
 * raw wire snippet.
 */
export async function distillBrief(input: {
  title: string;
  sourceName: string;
  type: string;
  publishedAt?: string;
  snippet: string | null;
  articleText: string | null;
}): Promise<StoryBrief | null> {
  const material = input.articleText?.trim() || input.snippet?.trim() || "";
  // Too thin to say anything honest — skip the model call entirely.
  if (material.length < 80) return null;

  try {
    const zai = await getZai();
    const completion = await zai.chat.completions.create({
      messages: [
        { role: "assistant", content: SYSTEM_PROMPT },
        {
          role: "user",
          content: userPrompt({
            title: input.title,
            sourceName: input.sourceName,
            type: input.type,
            publishedAt: input.publishedAt,
            material,
          }),
        },
      ],
      thinking: { type: "disabled" },
    });
    const raw = completion.choices[0]?.message?.content ?? "";
    return parseBriefJson(raw);
  } catch {
    return null;
  }
}
