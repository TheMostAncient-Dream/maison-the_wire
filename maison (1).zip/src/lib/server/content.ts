/**
 * Content query layer — filtered feeds, per-topic columns, featured stories,
 * and status. All hot paths are cached with the data-epoch invalidation so
 * repeated dashboard loads never re-hit the database.
 */
import { db } from '@/lib/db'
import { cached, cacheGet, cacheSet } from './cache'
import { scoreClusters, buildStoryClusters } from './cluster'
import { ingestState } from './ingest'
import type { ContentItem, Source } from '@prisma/client'
import type { ItemDTO, ItemType, PrefsDTO, StatusDTO, StoryClusterDTO } from '@/lib/types'
import { DEFAULT_PREFS } from '@/lib/types'
import { secret } from '@/lib/server/persisted-env'

type ItemWithSource = ContentItem & { source: Source }

/**
 * One dispatch by id — the server-side twin of /api/item/[id]. Serves the
 * deep link (/?item=<id>) for per-item metadata, sitemap and the feed.
 */
export async function getItemById(id: string): Promise<ItemWithSource | null> {
  return db.contentItem.findUnique({
    where: { id },
    include: { source: true },
  })
}

export function mapItem(i: ItemWithSource): ItemDTO {
  let topicSlugs: string[] = []
  try {
    topicSlugs = JSON.parse(i.topicSlugs)
  } catch { /* ignore */ }
  return {
    id: i.id,
    type: i.type as ItemDTO['type'],
    title: i.title,
    snippet: i.snippet,
    url: i.url,
    author: i.author,
    thumbnailUrl: i.thumbnailUrl,
    durationSec: i.durationSec,
    language: i.language,
    country: i.country,
    topicSlugs,
    publishedAt: i.publishedAt.toISOString(),
    source: {
      id: i.source.id,
      slug: i.source.slug,
      name: i.source.name,
      type: i.source.type as ItemDTO['source']['type'],
      logoUrl: i.source.logoUrl,
      websiteUrl: i.source.websiteUrl,
      prominence: i.source.prominence,
    },
  }
}

export interface ContentFilters {
  q?: string
  topic?: string
  source?: string
  type?: string
  country?: string
  language?: string
  since?: string // ISO date
  until?: string
  sort?: 'newest' | 'trending' | 'source'
  page?: number
  pageSize?: number
}

export async function getContent(filters: ContentFilters): Promise<{ items: ItemDTO[]; total: number; page: number; pageSize: number }> {
  const page = Math.max(1, filters.page ?? 1)
  const pageSize = Math.min(60, Math.max(1, filters.pageSize ?? 24))
  const key = `content:${JSON.stringify({ ...filters, page, pageSize })}`

  const result = await cached(key, 30_000, async () => {
    const where: Record<string, unknown> = {}
    if (filters.type) where.type = filters.type
    if (filters.language) where.language = filters.language
    if (filters.country) where.country = filters.country
    if (filters.since || filters.until) {
      where.publishedAt = {
        ...(filters.since ? { gte: new Date(filters.since) } : {}),
        ...(filters.until ? { lte: new Date(filters.until) } : {}),
      }
    }
    if (filters.source) {
      const src = await db.source.findUnique({ where: { slug: filters.source } })
      where.sourceId = src?.id ?? 'none'
    }
    if (filters.q) {
      // Tokenized LIKE search across title, snippet, source name, topic slugs.
      const terms = filters.q.toLowerCase().split(/\s+/).filter(Boolean).slice(0, 5)
      where.OR = terms.flatMap((t) => [
        { title: { contains: t } },
        { snippet: { contains: t } },
        { source: { is: { name: { contains: t } } } },
        { topicSlugs: { contains: t } },
      ])
    }
    if (filters.topic) {
      where.topicSlugs = { contains: `"${filters.topic}"` }
    }

    let orderBy: Record<string, 'asc' | 'desc'> = { publishedAt: 'desc' }
    if (filters.sort === 'source') orderBy = { sourceId: 'asc' }

    const [rows, total] = await Promise.all([
      db.contentItem.findMany({
        where,
        include: { source: true },
        orderBy,
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      db.contentItem.count({ where }),
    ])

    let items = rows.map(mapItem)
    if (filters.sort === 'source') {
      items.sort((a, b) => a.source.name.localeCompare(b.source.name) || (a.publishedAt < b.publishedAt ? 1 : -1))
    }
    return { items, total, page, pageSize }
  })

  return result
}

/** Recent items used as the clustering pool for featured/trending. */
export async function getRecentPool(hours = 48, cap = 1200): Promise<ItemDTO[]> {
  const key = `recentpool:${hours}:${cap}`
  return cached(key, 45_000, async () => {
    const since = new Date(Date.now() - hours * 3_600_000)
    const rows = await db.contentItem.findMany({
      where: { publishedAt: { gte: since }, type: { in: ['article', 'video'] } },
      include: { source: true },
      orderBy: { publishedAt: 'desc' },
      take: cap,
    })
    return rows.map(mapItem)
  })
}

export async function getFeatured(limit = 6): Promise<{ featured: StoryClusterDTO[]; latest: ItemDTO[] }> {
  return cached('featured:v2', 45_000, async () => {
    const pool = await getRecentPool(72, 1400)
    const featured = buildStoryClusters(pool, limit, 48)
    const latest = pool.slice(0, 10)
    return { featured, latest }
  })
}

export async function getTrending(limit = 14): Promise<ItemDTO[]> {
  return cached('trending:v2', 45_000, async () => {
    const pool = await getRecentPool(24, 1400)
    const { stories, singles } = scoreClusters(pool, 24)
    const tops = stories
      .slice(0, limit)
      .map((members) => {
        members.sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime())
        return members[0]
      })
      .filter((i): i is ItemDTO => !!i)
    if (tops.length >= limit) return tops
    const seen = new Set(tops.map((t) => t.id))
    return [...tops, ...singles.filter((s) => !seen.has(s.id))].slice(0, limit)
  })
}

/** Feed for one pseudo/topic column. */
export async function getColumnFeed(
  slug: string,
  limit: number,
  prefs?: Partial<Pick<PrefsDTO, 'sourceSlugs' | 'contentTypes' | 'languages' | 'countries'>>
): Promise<ItemDTO[]> {
  const key = `col:${slug}:${limit}:${JSON.stringify(prefs ?? {})}`
  return cached(key, 30_000, async () => {
    const where: Record<string, unknown> = {}
    const types = prefs?.contentTypes?.length ? prefs.contentTypes : ['article', 'video']
    where.type = { in: types }
    if (prefs?.languages?.length) where.language = { in: prefs.languages }
    if (prefs?.countries?.length) where.country = { in: prefs.countries }
    if (prefs?.sourceSlugs?.length) {
      const sources = await db.source.findMany({ where: { slug: { in: prefs.sourceSlugs } }, select: { id: true } })
      where.sourceId = { in: sources.map((s) => s.id) }
    }

    if (slug === 'latest') {
      const rows = await db.contentItem.findMany({
        where,
        include: { source: true },
        orderBy: { publishedAt: 'desc' },
        take: limit,
      })
      return rows.map(mapItem)
    }
    if (slug === 'trending') return getTrending(limit)

    where.topicSlugs = { contains: `"${slug}"` }
    const rows = await db.contentItem.findMany({
      where,
      include: { source: true },
      orderBy: { publishedAt: 'desc' },
      take: limit * 3, // over-fetch so interleaving video+article has material
    })
    const items = rows.map(mapItem)
    // Interleave articles and videos for the side-by-side experience.
    return interleaveByType(items).slice(0, limit)
  })
}

function interleaveByType(items: ItemDTO[]): ItemDTO[] {
  const articles = items.filter((i) => i.type === 'article')
  const videos = items.filter((i) => i.type === 'video')
  const out: ItemDTO[] = []
  let ai = 0
  let vi = 0
  // Roughly 4:1 article:video rhythm, mirroring real-world feed composition.
  while (ai < articles.length || vi < videos.length) {
    for (let k = 0; k < 4 && ai < articles.length; k++) out.push(articles[ai++])
    if (vi < videos.length) out.push(videos[vi++])
    if (ai >= articles.length && vi >= videos.length) break
  }
  return out
}

export async function getStatus(): Promise<StatusDTO> {
  const key = 'status:v1'
  const cachedStatus = cacheGet<StatusDTO>(key)
  if (cachedStatus) return cachedStatus

  const [totalItems, items24h, activeSources, healthySources, errorSources, lastSuccess] = await Promise.all([
    db.contentItem.count(),
    db.contentItem.count({ where: { publishedAt: { gte: new Date(Date.now() - 86_400_000) } } }),
    db.source.count({ where: { isActive: true, type: { not: 'instagram' } } }),
    db.source.count({ where: { isActive: true, healthStatus: 'healthy' } }),
    db.source.count({ where: { isActive: true, healthStatus: 'error' } }),
    db.source.findFirst({ where: { lastSuccessAt: { not: null } }, orderBy: { lastSuccessAt: 'desc' }, select: { lastSuccessAt: true } }),
  ])

  const status: StatusDTO = {
    lastUpdated: lastSuccess?.lastSuccessAt?.toISOString() ?? null,
    totalItems,
    items24h,
    activeSources,
    healthySources,
    errorSources,
    youtubeEnabled: !!secret('YOUTUBE_API_KEY'),
    ingesting: ingestState.ingesting,
    lastIngestDurationMs: ingestState.lastFullRunMs,
  }
  cacheSet(key, status, 15_000)
  return status
}

export async function getUserPrefs(userId: string): Promise<PrefsDTO> {
  const pref = await db.userPreference.findUnique({ where: { userId } })
  if (!pref) return DEFAULT_PREFS
  const parse = (s: string, fallback: string[]): string[] => {
    try {
      const value: unknown = JSON.parse(s)
      return Array.isArray(value)
        ? value.filter((entry): entry is string => typeof entry === 'string')
        : fallback
    } catch {
      return fallback
    }
  }
  return {
    columns: parse(pref.columns, DEFAULT_PREFS.columns),
    sourceSlugs: parse(pref.sourceSlugs, []),
    youtubeChannelIds: parse(pref.youtubeChannelIds, []),
    instagramHandles: parse(pref.instagramHandles, []),
    languages: parse(pref.languages, []),
    countries: parse(pref.countries, []),
    contentTypes: parse(pref.contentTypes, DEFAULT_PREFS.contentTypes).filter(
      (type): type is ItemType => type === 'article' || type === 'video' || type === 'instagram'
    ),
    itemsPerColumn: Math.min(30, Math.max(4, pref.itemsPerColumn || 12)),
    refreshIntervalMin: Math.min(60, Math.max(1, pref.refreshIntervalMin || 5)),
    theme: pref.theme || 'system',
  }
}
