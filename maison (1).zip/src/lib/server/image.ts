/**
 * Image pipeline helpers — extraction, sanitation, and og:image scraping.
 * Shared between the ingestion pipeline (Next.js) and backfill scripts (bun),
 * so this module must stay dependency-free (no @/ imports, no db).
 */

// ─── URL sanitation ──────────────────────────────────────────────────────────

/** Decode double-escaped HTML entities in extracted URLs (`&amp;#038;` → `&`). */
export function decodeUrlEntities(raw: string): string {
  let prev = raw;
  for (let i = 0; i < 3; i++) {
    const next = prev
      .replace(/&amp;/gi, "&")
      .replace(/&#0?38;/g, "&")
      .replace(/&#x0?26;/gi, "&")
      .replace(/&quot;/g, "%22");
    if (next === prev) break;
    prev = next;
  }
  return prev.trim();
}

/**
 * Tracking pixels / analytics beacons that masquerade as thumbnails in RSS
 * (NPR's 1×1 pixel, BBC's hit.xiti beacon, ESPs' open-trackers…).
 */
const JUNK_IMAGE = /npr-rss-pixel|hit\.xiti|\/tracking\/|\/pixel(?![a-z])|pixel\.(gif|png)|opentrack|beacon|spacer\.gif|transparent\.gif|blank\.(gif|png)|1x1\.|doubleclick|google-analytics|\/stats\/|mailfoogae/i;

/** True when the URL is a usable, honest image candidate. */
export function isUsableImageUrl(raw: string | undefined | null): raw is string {
  if (!raw) return false;
  const url = decodeUrlEntities(raw);
  if (!/^https?:\/\//i.test(url)) return false;
  if (JUNK_IMAGE.test(url)) return false;
  return true;
}

// ─── Media extraction from RSS items ─────────────────────────────────────────

export interface MediaCandidate {
  url: string;
  width?: number;
  height?: number;
}

function toNum(v: unknown): number | undefined {
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? n : undefined;
}

/** Recursively harvest every media URL from rss-parser's namespace soup. */
export function collectMediaUrls(node: unknown, out: MediaCandidate[] = [], depth = 0): MediaCandidate[] {
  if (depth > 6 || node == null) return out;

  if (typeof node === "object") {
    const obj = node as Record<string, unknown>;

    // An object with $ attrs that include a url/href → candidate.
    const attrs = (obj.$ ?? {}) as Record<string, unknown>;
    const url = typeof attrs.url === "string" ? attrs.url : typeof attrs.href === "string" ? (attrs.href as string) : undefined;
    if (url) {
      out.push({
        url: decodeUrlEntities(url),
        width: toNum(attrs.width),
        height: toNum(attrs.height),
      });
    }

    for (const [key, value] of Object.entries(obj)) {
      if (key === "$") continue;
      // Only walk media-ish / image-ish branches to stay cheap.
      if (/^(media|image|enclosure|thumbnail|group|content|item)/i.test(key) || typeof value !== "string") {
        collectMediaUrls(value, out, depth + 1);
      }
    }
  } else if (Array.isArray(node)) {
    for (const v of node) collectMediaUrls(v, out, depth + 1);
  }
  return out;
}

/** Pick the best image URL from a candidate set — largest known width wins; junk filtered. */
export function pickBestImageUrl(candidates: MediaCandidate[]): string | null {
  const usable = candidates.filter((c) => isUsableImageUrl(c.url));
  if (usable.length === 0) return null;
  usable.sort((a, b) => (b.width ?? 0) - (a.width ?? 0));
  return usable[0].url;
}

/** Pull the first inline <img src> from an HTML fragment. */
export function firstInlineImage(html: string | null | undefined): string | null {
  if (!html) return null;
  const m = html.match(/<img[^>]+src=["']?(https?:\/\/[^"'\s>]+)/i);
  if (!m) return null;
  const url = decodeUrlEntities(m[1]);
  return isUsableImageUrl(url) ? url : null;
}

// ─── og:image scraping (article pages that carry no media in the feed) ───────

const BROWSER_UA =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

const META_PATTERNS: RegExp[] = [
  /<meta[^>]+property=["']og:image(?::secure_url)?["'][^>]*content=["']([^"']+)["']/i,
  /<meta[^>]+content=["']([^"']+)["'][^>]*property=["']og:image(?::secure_url)?["']/i,
  /<meta[^>]+name=["']twitter:image(?::src)?["'][^>]*content=["']([^"']+)["']/i,
  /<meta[^>]+content=["']([^"']+)["'][^>]*name=["']twitter:image(?::src)?["']/i,
  /<link[^>]+rel=["']image_src["'][^>]*href=["']([^"']+)["']/i,
];

/** Block list for SSRF — never fetch loopback / private ranges. */
export function isPrivateHost(hostname: string): boolean {
  const h = hostname.toLowerCase().replace(/\.$/, "");
  if (h === "localhost" || h.endsWith(".localhost") || h.endsWith(".local") || h.endsWith(".internal")) return true;
  if (h === "::1" || h === "[::1]" || h === "0.0.0.0") return true;
  if (/^127\./.test(h)) return true;
  if (/^10\./.test(h)) return true;
  if (/^192\.168\./.test(h)) return true;
  if (/^169\.254\./.test(h)) return true;
  if (/^0\./.test(h)) return true;
  if (/^172\.(1[6-9]|2\d|3[01])\./.test(h)) return true;
  return false;
}

/**
 * Fetch an article page and scrape its social-share image (og:image →
 * twitter:image → image_src). Reads at most 300 KB — the meta tags always
 * live in <head>. Returns null on any failure; never throws.
 */
export async function scrapePageImage(pageUrl: string, timeoutMs = 9_000): Promise<string | null> {
  try {
    const parsed = new URL(pageUrl);
    if (!/^https?:$/.test(parsed.protocol) || isPrivateHost(parsed.hostname)) return null;

    const res = await fetch(parsed, {
      headers: {
        "User-Agent": BROWSER_UA,
        Accept: "text/html,application/xhtml+xml;q=0.9,*/*;q=0.5",
        "Accept-Language": "en-US,en;q=0.9",
      },
      redirect: "follow",
      signal: AbortSignal.timeout(timeoutMs),
      cache: "no-store",
    });
    if (!res.ok) return null;

    const reader = res.body?.getReader();
    if (!reader) return null;
    const decoder = new TextDecoder();
    let html = "";
    let received = 0;
    const LIMIT = 300_000;
    while (received < LIMIT) {
      const { done, value } = await reader.read();
      if (done) break;
      received += value.byteLength;
      html += decoder.decode(value, { stream: true });
      if (/<\/head>/i.test(html)) break; // everything we need is in <head>
    }
    reader.cancel().catch(() => {});
    if (!html) return null;

    for (const re of META_PATTERNS) {
      const m = html.match(re);
      if (m?.[1]) {
        const url = decodeUrlEntities(m[1]);
        if (isUsableImageUrl(url)) return url;
      }
    }
    // Last resort inside the fetched head: a large <img> in JSON-LD or hero markup.
    const img = firstInlineImage(html.slice(0, LIMIT));
    return img;
  } catch {
    return null;
  }
}
