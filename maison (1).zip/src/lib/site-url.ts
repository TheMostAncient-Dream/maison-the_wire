/**
 * Absolute public origin for canonical URLs, sitemaps, robots and RSS.
 * Never publish localhost or an internal Preview host as a canonical domain.
 * Configure NEXT_PUBLIC_SITE_URL with the real HTTPS origin at deployment.
 */
export function siteUrl(): string | undefined {
  const configured = process.env.NEXT_PUBLIC_SITE_URL?.trim();
  if (!configured) return undefined;

  try {
    const url = new URL(configured);
    const localHost = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
    if (url.username || url.password) return undefined;
    if (url.protocol !== "https:" && !(localHost && url.protocol === "http:")) {
      return undefined;
    }
    return url.origin;
  } catch {
    return undefined;
  }
}
