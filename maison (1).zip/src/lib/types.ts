/** Shared types between server and client. */

export type ItemType = 'article' | 'video' | 'instagram'
export type SourceType = 'rss' | 'youtube' | 'instagram'

export interface ItemDTO {
  id: string
  type: ItemType
  title: string
  snippet: string | null
  url: string
  author: string | null
  thumbnailUrl: string | null
  durationSec: number | null
  language: string
  country: string | null
  topicSlugs: string[]
  publishedAt: string
  source: {
    id: string
    slug: string
    name: string
    type: SourceType
    logoUrl: string | null
    websiteUrl: string | null
    prominence: number
  }
}

export interface StoryClusterDTO {
  id: string
  title: string
  score: number
  publishedAt: string
  primaryTopic: string
  type: 'article' | 'video'
  items: ItemDTO[]
}

/** AI-distilled story brief served by /api/brief */
export interface StoryBriefDTO {
  brief: string
  keyPoints: string[]
  cached?: boolean
}

export interface SourceDTO {
  id: string
  slug: string
  name: string
  type: SourceType
  websiteUrl: string | null
  feedUrl: string | null
  externalId: string | null
  country: string | null
  language: string
  topicSlugs: string[]
  logoUrl: string | null
  prominence: number
  isActive: boolean
  healthStatus: string
  lastSuccessAt: string | null
  lastError: string | null
  itemsIngested: number
}

export interface TopicDTO {
  id: string
  slug: string
  name: string
  description: string | null
  sortOrder: number
}

export interface StatusDTO {
  lastUpdated: string | null
  totalItems: number
  items24h: number
  activeSources: number
  healthySources: number
  errorSources: number
  youtubeEnabled: boolean
  ingesting: boolean
  lastIngestDurationMs: number | null
}

export interface PrefsDTO {
  columns: string[]
  sourceSlugs: string[]
  youtubeChannelIds: string[]
  instagramHandles: string[]
  languages: string[]
  countries: string[]
  contentTypes: ItemType[]
  itemsPerColumn: number
  refreshIntervalMin: number
  theme: string
}

export const DEFAULT_PREFS: PrefsDTO = {
  columns: ['latest', 'trending', 'world', 'business', 'technology', 'science', 'sports', 'entertainment'],
  sourceSlugs: [],
  youtubeChannelIds: [],
  instagramHandles: [],
  languages: [],
  countries: [],
  contentTypes: ['article', 'video'],
  itemsPerColumn: 12,
  refreshIntervalMin: 5,
  theme: 'system',
}

export interface SessionUser {
  id: string
  email: string
  name: string | null
  role: string
  /** True once the reader has finished (or skipped) the post-signup onboarding. */
  onboarded: boolean
  /** True once the reader proved the address with a timed verification code. */
  emailVerified: boolean
}
