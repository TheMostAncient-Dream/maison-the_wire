"use client";

/**
 * Client-side Web Push plumbing — VAPID, no third-party account.
 *
 * The service worker is registered ONLY here, and only from moments of
 * reader intent (onboarding Step 2, the Settings section). Permission is
 * requested exactly once per intent action and never on page load —
 * browsers punish speculative prompts, and so do we.
 */

export function pushSupported(): boolean {
  return (
    typeof window !== "undefined" &&
    "serviceWorker" in navigator &&
    "PushManager" in window &&
    "Notification" in window
  );
}

export function permissionState(): NotificationPermission | "unsupported" {
  if (!pushSupported()) return "unsupported";
  return Notification.permission;
}

/** Idempotent — safe to call repeatedly. */
async function registerWorker(): Promise<ServiceWorkerRegistration> {
  return navigator.serviceWorker.register("/sw.js");
}

function urlBase64ToUint8Array(base64String: string): Uint8Array<ArrayBuffer> {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(base64);
  const output = new Uint8Array(new ArrayBuffer(raw.length));
  for (let i = 0; i < raw.length; ++i) output[i] = raw.charCodeAt(i);
  return output;
}

export type SubscribeOutcome =
  | { ok: true }
  | { ok: false; reason: "unsupported" | "denied" | "dismissed" | "error" };

/**
 * Ask permission (caller must have shown the one-line explanation first),
 * register the worker, subscribe to push, and store the subscription.
 */
export async function subscribeToPush(vapidPublicKey: string): Promise<SubscribeOutcome> {
  if (!pushSupported() || !vapidPublicKey) return { ok: false, reason: "unsupported" };
  try {
    const perm = await Notification.requestPermission();
    if (perm === "denied") return { ok: false, reason: "denied" };
    if (perm !== "granted") return { ok: false, reason: "dismissed" };

    const reg = await registerWorker();
    await navigator.serviceWorker.ready;
    const existing = await reg.pushManager.getSubscription();
    let sub = existing;
    /*
     * On a cold browser the push service's own handshake (Firefox's hello,
     * Chrome's FCM checkin) may still be in flight; subscribe() aborts
     * instead of queueing in that window. A short retry with backoff
     * bridges first-visit races and slow networks.
     */
    for (let attempt = 0; !sub && attempt < 4; attempt++) {
      try {
        sub = await reg.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: urlBase64ToUint8Array(vapidPublicKey),
        });
      } catch (err) {
        if (attempt === 3) {
          console.warn(
            "[push] subscribe failed:",
            err instanceof Error ? `${err.name}: ${err.message}` : String(err)
          );
          return { ok: false, reason: "error" };
        }
        await new Promise((r) => setTimeout(r, 1_500 * (attempt + 1)));
      }
    }

    const res = await fetch("/api/notifications/subscribe", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ subscription: sub!.toJSON() }),
    });
    if (!res.ok) return { ok: false, reason: "error" };
    return { ok: true };
  } catch (err) {
    console.warn(
      "[push] subscribe failed:",
      err instanceof Error ? `${err.name}: ${err.message}` : String(err)
    );
    return { ok: false, reason: "error" };
  }
}

/** Retire the local subscription (and its server row) — used by Settings "Turn off". */
export async function unsubscribeFromPush(): Promise<boolean> {
  if (!pushSupported()) return false;
  try {
    const reg = await navigator.serviceWorker.getRegistration();
    const sub = (await reg?.pushManager.getSubscription()) ?? null;
    if (!sub) return false;
    const endpoint = sub.endpoint;
    await sub.unsubscribe();
    await fetch("/api/notifications/subscribe", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ endpoint }),
    });
    return true;
  } catch {
    return false;
  }
}

/** True when this browser currently holds an active push subscription. */
export async function hasLocalSubscription(): Promise<boolean> {
  if (!pushSupported()) return false;
  try {
    const reg = await navigator.serviceWorker.getRegistration();
    const sub = (await reg?.pushManager.getSubscription()) ?? null;
    return !!sub;
  } catch {
    return false;
  }
}
