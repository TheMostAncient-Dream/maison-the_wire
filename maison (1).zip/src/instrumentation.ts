/**
 * Next.js instrumentation — runs once when the server process starts.
 * Bootstraps first ingestion (if the DB is fresh) and the background
 * scheduler that refreshes sources on their configured intervals.
 */
export async function register() {
  if (process.env.NEXT_RUNTIME !== 'nodejs') return
  // Fail fast when AUTH_SECRET is missing — before a single request is
  // served. auth.ts throws on import when the secret is absent/short.
  await import('@/lib/server/auth')
  // Read-only production smoke checks can opt out of ingestion and timers.
  // Published deployments leave this unset so the existing scheduler runs.
  if (process.env.MAISON_DISABLE_BACKGROUND_INGESTION === 'true') return
  try {
    const { bootstrapIngestion, startScheduler } = await import('@/lib/server/ingest')
    // Kick off asynchronously so server startup is never blocked.
    void bootstrapIngestion()
      .then(() => console.log('[instrumentation] ingestion bootstrap complete'))
      .catch((err) => console.error('[instrumentation] bootstrap failed:', err))
    startScheduler()
    console.log('[instrumentation] news scheduler started')
  } catch (err) {
    console.error('[instrumentation] failed to initialize ingestion:', err)
  }
}
