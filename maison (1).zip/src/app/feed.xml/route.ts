import { getRecentPool } from "@/lib/server/content";
import { siteUrl } from "@/lib/site-url";

export const dynamic = "force-dynamic";

/**
 * The wire, published back out — an RSS 2.0 feed of the latest dispatches
 * so the site can be followed the way it follows others. Deep links carry
 * the ?item=<id> query, which opens the dispatch on any reader's visit.
 */

/** Minimal XML escaping for text nodes. */
function esc(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export async function GET() {
  const base = siteUrl();

  let rows: Awaited<ReturnType<typeof getRecentPool>> = [];
  try {
    rows = await getRecentPool(24 * 7, 50);
  } catch {
    /* an empty channel is better than a broken one */
  }

  const items = rows
    .map((item) => {
      const link = base ? `${base}/?item=${encodeURIComponent(item.id)}` : item.url;
      const title = esc(item.title);
      const description = esc(
        (item.snippet ?? "").slice(0, 400) || `${item.source.name}`
      );
      const pubDate = new Date(item.publishedAt).toUTCString();
      return [
        "    <item>",
        `      <title>${title}</title>`,
        `      <link>${esc(link)}</link>`,
        `      <guid isPermaLink="false">${esc(item.id)}</guid>`,
        `      <pubDate>${pubDate}</pubDate>`,
        `      <description>${description}</description>`,
        `      <source>${esc(item.source.name)}</source>`,
        "    </item>",
      ].join("\n");
    })
    .join("\n");
  const channelLink = base ?? rows[0]?.url;

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0">
  <channel>
    <title>MAISON — The Whole Wire, Beautifully Set</title>
    ${channelLink ? `<link>${esc(channelLink)}</link>` : ""}
    <description>A luxury editorial wire — the latest dispatches, set in type the moment they arrive.</description>
    <language>en</language>
    <lastBuildDate>${new Date().toUTCString()}</lastBuildDate>
    <ttl>15</ttl>
${items}
  </channel>
</rss>`;

  return new Response(xml, {
    headers: {
      "Content-Type": "application/rss+xml; charset=utf-8",
      "Cache-Control": "public, max-age=600",
    },
  });
}
