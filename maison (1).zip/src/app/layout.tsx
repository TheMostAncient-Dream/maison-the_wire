import type { Metadata, Viewport } from "next";
import { Inter, Playfair_Display } from "next/font/google";
import { siteUrl } from "@/lib/site-url";
import "./globals.css";

/* Heading face — high-contrast editorial serif (variable, normal + italic) */
const playfair = Playfair_Display({
  variable: "--font-playfair",
  subsets: ["latin"],
  style: ["normal", "italic"],
  display: "swap",
});

/* Body face — clean humanist sans (variable) */
const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const canonicalOrigin = siteUrl();
const siteDescription =
  "A considered global news wire: trusted sources, clustered stories and the day’s essentials, beautifully set.";
const websiteStructuredData = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: "MAISON",
  description: siteDescription,
  ...(canonicalOrigin ? { url: canonicalOrigin } : {}),
};

export const metadata: Metadata = {
  ...(canonicalOrigin ? { metadataBase: new URL(canonicalOrigin) } : {}),
  title: "MAISON — The Whole Wire, Beautifully Set",
  description: siteDescription,
  keywords: ["luxury", "editorial", "rss", "news", "wire", "maison"],
  openGraph: {
    type: "website",
    siteName: "MAISON",
    title: "MAISON — The Whole Wire, Beautifully Set",
    description: siteDescription,
    ...(canonicalOrigin
      ? {
          url: canonicalOrigin,
          images: [
            {
              url: `${canonicalOrigin}/editorial/hero.jpg`,
              width: 1600,
              height: 900,
              alt: "MAISON — the whole wire, beautifully set",
            },
          ],
        }
      : {}),
  },
  twitter: {
    card: canonicalOrigin ? "summary_large_image" : "summary",
    title: "MAISON — The Whole Wire, Beautifully Set",
    description: siteDescription,
    ...(canonicalOrigin ? { images: [`${canonicalOrigin}/editorial/hero.jpg`] } : {}),
  },
  alternates: {
    ...(canonicalOrigin ? { canonical: canonicalOrigin } : {}),
    types: { "application/rss+xml": "/feed.xml" },
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#F9F8F6" },
    { media: "(prefers-color-scheme: dark)", color: "#131211" },
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(websiteStructuredData).replace(/</g, "\\u003c"),
          }}
        />
        {/* Restore the reader's edition before first paint — no flash. */}
        <script
          dangerouslySetInnerHTML={{
            __html:
              "try{if(localStorage.getItem('maison-theme')==='dark')document.documentElement.classList.add('dark')}catch(e){}document.documentElement.classList.add('js')",
          }}
        />
      </head>
      <body
        className={`${playfair.variable} ${inter.variable} bg-alabaster text-charcoal antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
