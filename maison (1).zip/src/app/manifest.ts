import type { MetadataRoute } from "next";

/**
 * PWA manifest — completes the installable half of the app (push already
 * ships via sw.js). The night edition is a reader preference, so the
 * manifest stays on the day-edition paper; standalone display, house
 * wordmark icon at both required sizes.
 */
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "MAISON — The Whole Wire, Beautifully Set",
    short_name: "MAISON",
    description:
      "A luxury editorial wire. Every dispatch from 105 sources — clustered, filtered and set in type the moment it arrives.",
    id: "/",
    start_url: "/",
    scope: "/",
    display: "standalone",
    background_color: "#F9F8F6",
    theme_color: "#F9F8F6",
    icons: [
      {
        src: "/push-icon.png",
        sizes: "192x192",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/maison-icon-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "any",
      },
    ],
  };
}
