import type { MetadataRoute } from "next";
import { getRecentPool } from "@/lib/server/content";
import { siteUrl } from "@/lib/site-url";

export const dynamic = "force-dynamic";

/**
 * Sitemap — the front page plus the month's dispatches (their deep-link
 * URLs are the only shareable, indexable pages on the site). Capped so a
 * viral intake week can't balloon the file past sitemap limits.
 */
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = siteUrl();
  if (!base) return [];

  const entries: MetadataRoute.Sitemap = [
    {
      url: base,
      lastModified: new Date(),
      changeFrequency: "hourly",
      priority: 1,
    },
  ];

  try {
    const recent = await getRecentPool(24 * 30, 500);
    for (const item of recent) {
      entries.push({
        url: `${base}/?item=${item.id}`,
        lastModified: new Date(item.publishedAt),
        changeFrequency: "never",
        priority: 0.6,
      });
    }
  } catch {
    /* the front page alone is still a valid sitemap */
  }

  return entries;
}
