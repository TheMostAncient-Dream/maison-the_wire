"use client";

/**
 * Runtime error boundary — the presses jam, the paper stays composed.
 * Offers a genuine retry (reset re-renders the segment) and an honest
 * escape hatch back to the front page. The failure itself is logged,
 * never hidden.
 */

import { useEffect } from "react";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[maison] segment error:", error);
  }, [error]);

  return (
    <section className="flex min-h-[70vh] items-center justify-center bg-alabaster px-8">
      <div className="max-w-xl py-24 text-center">
        <p className="text-[10px] uppercase tracking-[0.3em] text-warm-grey">
          Technical difficulties
        </p>
        <h1 className="mt-6 font-serif text-5xl leading-[0.95] text-charcoal md:text-7xl">
          The presses jammed.
        </h1>
        <div className="mx-auto mt-10 h-px w-24 bg-gold" aria-hidden />
        <p className="mx-auto mt-10 max-w-sm text-sm leading-relaxed text-warm-grey">
          Something interrupted this page — not the whole edition. Run the
          press again, or step back to the front page.
        </p>
        <div className="mt-12 flex flex-col items-center justify-center gap-6 sm:flex-row">
          <button
            type="button"
            onClick={reset}
            className="cursor-pointer border border-charcoal px-8 py-3.5 text-xs uppercase tracking-[0.25em] text-charcoal transition-colors duration-500 ease-luxe hover:bg-charcoal hover:text-alabaster"
          >
            Try again
          </button>
          <a
            href="/"
            className="text-xs uppercase tracking-[0.25em] text-warm-grey underline-offset-8 transition-colors duration-500 ease-luxe hover:text-gold hover:underline"
          >
            Front page
          </a>
        </div>
      </div>
    </section>
  );
}
