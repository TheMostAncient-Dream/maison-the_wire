import { NextResponse } from 'next/server'
import { getItemById, mapItem } from '@/lib/server/content'
import { rateLimit, clientIp } from '@/lib/server/cache'

export const dynamic = 'force-dynamic'

/**
 * One dispatch by id — serves the deep link from a browser notification
 * (notificationclick → /?item=<id> → the dispatch modal opens it).
 */
export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!rateLimit(`item:${clientIp(req)}`, 120, 60_000)) {
    return NextResponse.json({ error: 'Rate limit exceeded' }, { status: 429 })
  }
  const { id } = await params
  const item = await getItemById(id)
  if (!item) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  return NextResponse.json({ item: mapItem(item) })
}
