import { NextResponse } from 'next/server'
import { getFeatured } from '@/lib/server/content'
import { rateLimit, clientIp } from '@/lib/server/cache'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  if (!rateLimit(`featured:${clientIp(req)}`, 120, 60_000)) {
    return NextResponse.json({ error: 'Rate limit exceeded' }, { status: 429 })
  }
  const { searchParams } = new URL(req.url)
  const limit = Math.min(10, Math.max(2, Number(searchParams.get('limit') ?? 6) || 6))
  const result = await getFeatured(limit)
  return NextResponse.json(result)
}
