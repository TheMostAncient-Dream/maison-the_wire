import { NextResponse } from 'next/server'
import { getSessionUser } from '@/lib/server/auth'
import { getContent } from '@/lib/server/content'
import { rateLimit, clientIp } from '@/lib/server/cache'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  if (!rateLimit(`content:${clientIp(req)}`, 120, 60_000)) {
    return NextResponse.json({ error: 'Rate limit exceeded' }, { status: 429 })
  }
  const { searchParams } = new URL(req.url)
  const sort = searchParams.get('sort') ?? 'newest'
  if (!['newest', 'trending', 'source'].includes(sort)) {
    return NextResponse.json({ error: 'Invalid sort' }, { status: 400 })
  }
  const result = await getContent({
    q: searchParams.get('q') ?? undefined,
    topic: searchParams.get('topic') ?? undefined,
    source: searchParams.get('source') ?? undefined,
    type: searchParams.get('type') ?? undefined,
    country: searchParams.get('country') ?? undefined,
    language: searchParams.get('language') ?? undefined,
    since: searchParams.get('since') ?? undefined,
    until: searchParams.get('until') ?? undefined,
    sort: sort as 'newest' | 'trending' | 'source',
    page: Number(searchParams.get('page') ?? 1) || 1,
    pageSize: Number(searchParams.get('pageSize') ?? 24) || 24,
  })
  return NextResponse.json(result)
}

export async function POST() {
  const user = await getSessionUser()
  return NextResponse.json({ error: 'Not supported', user: user?.email ?? null }, { status: 405 })
}
