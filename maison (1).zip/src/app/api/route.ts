import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    service: "newswire-terminal",
    status: "ok",
    endpoints: ["/api/content", "/api/featured", "/api/columns", "/api/sources", "/api/topics", "/api/status", "/api/auth/*", "/api/bookmarks", "/api/preferences", "/api/admin/*"],
  });
}
