import type { NextRequest } from "next/server";
import { isPrivateHost } from "@/lib/server/image";

/**
 * Image proxy — some publisher CDNs (Engadget, NPR's Brightspot, CBC…)
 * reject hot-linked <img> requests with 403 based on referer / bot UA.
 * The browser asks us instead; we fetch with a browser UA + same-site
 * referer and stream the bytes back with a long-lived cache header.
 *
 * GET /api/img?u=<encoded https url>
 */
export const dynamic = "force-dynamic";

const BROWSER_UA =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

function bad(status: number, message: string) {
  return new Response(message, {
    status,
    headers: { "Content-Type": "text/plain", "Cache-Control": "no-store" },
  });
}

export async function GET(req: NextRequest) {
  const raw = req.nextUrl.searchParams.get("u");
  if (!raw) return bad(400, "missing u");

  let target: URL;
  try {
    target = new URL(raw);
  } catch {
    return bad(400, "invalid url");
  }
  if (!/^https?:$/.test(target.protocol)) return bad(400, "unsupported protocol");
  if (isPrivateHost(target.hostname)) return bad(403, "blocked host");

  try {
    const upstream = await fetch(target, {
      headers: {
        "User-Agent": BROWSER_UA,
        Accept: "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
        Referer: `${target.protocol}//${target.host}/`,
      },
      redirect: "follow",
      signal: AbortSignal.timeout(12_000),
      cache: "no-store",
    });

    const ct = upstream.headers.get("content-type") ?? "";
    if (!upstream.ok || !upstream.body || !ct.startsWith("image/")) {
      return bad(502, "upstream refused");
    }

    return new Response(upstream.body, {
      status: 200,
      headers: {
        "Content-Type": ct,
        "Cache-Control": "public, max-age=86400, stale-while-revalidate=604800",
        "X-Img-Proxy": "1",
      },
    });
  } catch {
    return bad(504, "upstream timeout");
  }
}
