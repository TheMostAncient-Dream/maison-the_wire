import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { cached } from '@/lib/server/cache'
import type { SourceDTO } from '@/lib/types'

export const dynamic = 'force-dynamic'

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const type = searchParams.get('type')
  const result = await cached(`sources:${type ?? 'all'}`, 30_000, async () => {
    const where = type ? { type } : {}
    const sources = await db.source.findMany({ where, orderBy: [{ type: 'asc' }, { name: 'asc' }] })
    const dto: SourceDTO[] = sources.map((s) => ({
      id: s.id,
      slug: s.slug,
      name: s.name,
      type: s.type as SourceDTO['type'],
      websiteUrl: s.websiteUrl,
      feedUrl: s.feedUrl,
      externalId: s.externalId,
      country: s.country,
      language: s.language,
      topicSlugs: (() => {
        try {
          return JSON.parse(s.topicSlugs)
        } catch {
          return []
        }
      })(),
      logoUrl: s.logoUrl,
      prominence: s.prominence,
      isActive: s.isActive,
      healthStatus: s.healthStatus,
      lastSuccessAt: s.lastSuccessAt?.toISOString() ?? null,
      lastError: s.lastError,
      itemsIngested: s.itemsIngested,
    }))
    return dto
  })
  return NextResponse.json(result)
}
