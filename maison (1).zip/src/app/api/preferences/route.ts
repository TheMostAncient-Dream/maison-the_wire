import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/server/auth'
import { getUserPrefs } from '@/lib/server/content'
import { DEFAULT_PREFS } from '@/lib/types'

export const dynamic = 'force-dynamic'

export async function GET() {
  const user = await getSessionUser()
  if (!user) return NextResponse.json({ prefs: null, guest: true })
  const prefs = await getUserPrefs(user.id)
  return NextResponse.json({ prefs, guest: false })
}

export async function PUT(req: Request) {
  const user = await getSessionUser()
  if (!user) return NextResponse.json({ error: 'Sign in to persist preferences across devices' }, { status: 401 })
  const body = await req.json()

  const clampInt = (v: unknown, min: number, max: number, fallback: number) => {
    const n = Number(v)
    if (!Number.isFinite(n)) return fallback
    return Math.min(max, Math.max(min, Math.round(n)))
  }
  const strArr = (v: unknown, max: number) =>
    Array.isArray(v) ? v.map((x) => String(x).slice(0, 100)).slice(0, max) : undefined

  const data: Record<string, unknown> = {}
  const columns = strArr(body.columns, 12)
  if (columns) data.columns = JSON.stringify(columns)
  const sourceSlugs = strArr(body.sourceSlugs, 200)
  if (sourceSlugs) data.sourceSlugs = JSON.stringify(sourceSlugs)
  const youtubeChannelIds = strArr(body.youtubeChannelIds, 100)
  if (youtubeChannelIds) data.youtubeChannelIds = JSON.stringify(youtubeChannelIds)
  const instagramHandles = strArr(body.instagramHandles, 100)
  if (instagramHandles) data.instagramHandles = JSON.stringify(instagramHandles)
  const languages = strArr(body.languages, 20)
  if (languages) data.languages = JSON.stringify(languages)
  const countries = strArr(body.countries, 20)
  if (countries) data.countries = JSON.stringify(countries)
  const contentTypes = strArr(body.contentTypes, 3)
  if (contentTypes) data.contentTypes = JSON.stringify(contentTypes.filter((t: string) => ['article', 'video', 'instagram'].includes(t)))
  if (body.itemsPerColumn !== undefined) data.itemsPerColumn = clampInt(body.itemsPerColumn, 4, 30, DEFAULT_PREFS.itemsPerColumn)
  if (body.refreshIntervalMin !== undefined) data.refreshIntervalMin = clampInt(body.refreshIntervalMin, 1, 60, DEFAULT_PREFS.refreshIntervalMin)
  if (typeof body.theme === 'string' && ['light', 'dark', 'system'].includes(body.theme)) data.theme = body.theme

  await db.userPreference.upsert({
    where: { userId: user.id },
    update: data,
    create: { userId: user.id, ...data },
  })

  const prefs = await getUserPrefs(user.id)
  return NextResponse.json({ prefs })
}
