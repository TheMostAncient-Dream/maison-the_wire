import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/server/auth'
import { mapItem } from '@/lib/server/content'
import { rateLimit, clientIp } from '@/lib/server/cache'

export const dynamic = 'force-dynamic'

/** GET → user's bookmarked items (newest first). */
export async function GET() {
  const user = await getSessionUser()
  if (!user) return NextResponse.json({ error: 'Sign in to view saved stories' }, { status: 401 })
  const bookmarks = await db.bookmark.findMany({
    where: { userId: user.id },
    include: { item: { include: { source: true } } },
    orderBy: { createdAt: 'desc' },
    take: 200,
  })
  return NextResponse.json({
    items: bookmarks.map((b) => ({ ...mapItem(b.item), savedAt: b.createdAt.toISOString() })),
  })
}

/** POST {itemId} → add; DELETE {itemId} → remove. */
export async function POST(req: Request) {
  if (!rateLimit(`bookmark:${clientIp(req)}`, 60, 60_000)) {
    return NextResponse.json({ error: 'Rate limit exceeded' }, { status: 429 })
  }
  const user = await getSessionUser()
  if (!user) return NextResponse.json({ error: 'Sign in to save stories' }, { status: 401 })
  const body = await req.json()
  const itemId = String(body.itemId ?? '')
  if (!itemId) return NextResponse.json({ error: 'itemId is required' }, { status: 400 })
  const item = await db.contentItem.findUnique({ where: { id: itemId } })
  if (!item) return NextResponse.json({ error: 'Item not found' }, { status: 404 })

  const existing = await db.bookmark.findUnique({
    where: { userId_itemId: { userId: user.id, itemId } },
  })
  if (existing) {
    await db.bookmark.delete({ where: { id: existing.id } })
    return NextResponse.json({ saved: false })
  }
  await db.bookmark.create({ data: { userId: user.id, itemId } })
  return NextResponse.json({ saved: true })
}

export async function DELETE(req: Request) {
  const user = await getSessionUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { searchParams } = new URL(req.url)
  const itemId = searchParams.get('itemId')
  if (!itemId) return NextResponse.json({ error: 'itemId is required' }, { status: 400 })
  await db.bookmark.deleteMany({ where: { userId: user.id, itemId } })
  return NextResponse.json({ ok: true })
}
