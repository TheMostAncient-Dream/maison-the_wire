import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { rateLimit, clientIp } from '@/lib/server/cache'
import { extractArticleText, distillBrief, type StoryBrief } from '@/lib/server/brief'

export const dynamic = 'force-dynamic'
export const maxDuration = 60

/** One generation per item at a time — parallel modals share the same promise. */
const inflight = new Map<string, Promise<StoryBrief | null>>()

async function generateAndCache(item: {
  id: string
  title: string
  snippet: string | null
  type: string
  url: string
  publishedAt: Date
  sourceName: string
}): Promise<StoryBrief | null> {
  const articleText =
    item.type === 'article' ? await extractArticleText(item.url) : null
  const result = await distillBrief({
    title: item.title,
    sourceName: item.sourceName,
    type: item.type,
    publishedAt: item.publishedAt.toISOString(),
    snippet: item.snippet,
    articleText,
  })
  if (result) {
    await db.contentItem
      .update({
        where: { id: item.id },
        data: {
          brief: result.brief,
          keyPoints: JSON.stringify(result.keyPoints),
          briefAt: new Date(),
        },
      })
      .catch(() => undefined)
  }
  return result
}

export async function GET(req: Request) {
  if (!rateLimit(`brief:${clientIp(req)}`, 30, 60_000)) {
    return NextResponse.json({ error: 'Rate limit exceeded' }, { status: 429 })
  }

  const id = new URL(req.url).searchParams.get('id')?.trim()
  if (!id) return NextResponse.json({ error: 'Missing id' }, { status: 400 })

  const item = await db.contentItem.findUnique({
    where: { id },
    select: {
      id: true,
      title: true,
      snippet: true,
      type: true,
      url: true,
      publishedAt: true,
      brief: true,
      keyPoints: true,
      briefAt: true,
      source: { select: { name: true } },
    },
  })
  if (!item) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  // Cached from an earlier open — instant.
  if (item.brief && item.briefAt) {
    let keyPoints: string[] = []
    try {
      const parsed: unknown = JSON.parse(item.keyPoints ?? '[]')
      if (Array.isArray(parsed)) keyPoints = parsed.filter((k): k is string => typeof k === 'string')
    } catch {
      /* brief without key points is still valid */
    }
    return NextResponse.json(
      { brief: item.brief, keyPoints, cached: true },
      { headers: { 'Cache-Control': 'public, max-age=3600' } },
    )
  }

  // Generate (shared promise so concurrent opens don't double-spend the LLM).
  let job = inflight.get(id)
  if (!job) {
    job = generateAndCache({
      id: item.id,
      title: item.title,
      snippet: item.snippet,
      type: item.type,
      url: item.url,
      publishedAt: item.publishedAt,
      sourceName: item.source.name,
    }).finally(() => inflight.delete(id))
    inflight.set(id, job)
  }
  const result = await job

  if (!result) {
    // Graceful empty — the client falls back to the wire snippet.
    return NextResponse.json(
      { brief: null, keyPoints: [], cached: false },
      { headers: { 'Cache-Control': 'no-store' } },
    )
  }
  return NextResponse.json(
    { brief: result.brief, keyPoints: result.keyPoints, cached: false },
    { headers: { 'Cache-Control': 'public, max-age=3600' } },
  )
}
