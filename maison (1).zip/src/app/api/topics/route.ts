import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { cached } from '@/lib/server/cache'

export const dynamic = 'force-dynamic'

export async function GET() {
  const topics = await cached('topics:v1', 60_000, async () =>
    db.topic.findMany({ orderBy: { sortOrder: 'asc' }, select: { id: true, slug: true, name: true, description: true, sortOrder: true } })
  )
  return NextResponse.json(topics)
}
