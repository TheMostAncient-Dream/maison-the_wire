import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin } from '@/lib/server/auth'

export const dynamic = 'force-dynamic'

/** GET — the last 50 entries of the admin audit trail (newest first). */
export async function GET() {
  const admin = await requireAdmin()
  if (!admin) return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
  const entries = await db.adminAuditLog.findMany({
    orderBy: { createdAt: 'desc' },
    take: 50,
    include: { actor: { select: { email: true, name: true } } },
  })
  return NextResponse.json(
    entries.map((e) => ({
      id: e.id,
      actor: e.actor.email,
      action: e.action,
      targetId: e.targetId,
      detail: e.detail,
      createdAt: e.createdAt.toISOString(),
    }))
  )
}
