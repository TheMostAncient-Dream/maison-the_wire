import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin } from '@/lib/server/auth'
import { ingestState } from '@/lib/server/ingest'

export const dynamic = 'force-dynamic'

export async function GET() {
  const admin = await requireAdmin()
  if (!admin) return NextResponse.json({ error: 'Admin access required' }, { status: 403 })

  const since7d = new Date(Date.now() - 7 * 86_400_000)

  const [totalItems, items24h, users, bookmarks, itemsIngested7d, sourcesByType, topSources, healthCounts] =
    await Promise.all([
      db.contentItem.count(),
      db.contentItem.count({ where: { publishedAt: { gte: new Date(Date.now() - 86_400_000) } } }),
      db.user.count(),
      db.bookmark.count(),
      db.contentItem.count({ where: { fetchedAt: { gte: since7d } } }),
      db.source.groupBy({ by: ['type'], _count: true, where: { isActive: true } }),
      db.source.findMany({
        orderBy: { itemsIngested: 'desc' },
        take: 10,
        select: { name: true, itemsIngested: true, type: true },
      }),
      db.source.groupBy({ by: ['healthStatus'], _count: true }),
    ])

  // Fetch only the timestamp column in the seven-day window, then bucket by
  // UTC day in JS so the chart is independent of SQL dialect/time zone.
  const fetchedRows = await db.contentItem.findMany({
    where: { fetchedAt: { gte: since7d } },
    select: { fetchedAt: true },
    orderBy: { fetchedAt: 'asc' },
  })
  const dayCounts = new Map<string, number>()
  for (const row of fetchedRows) {
    const day = row.fetchedAt.toISOString().slice(0, 10)
    dayCounts.set(day, (dayCounts.get(day) ?? 0) + 1)
  }
  const perDay = [...dayCounts.entries()].map(([date, count]) => ({ date, count }))

  // Topic slugs are stored as serialized JSON strings; aggregate using Prisma
  // so the reporting path works identically on SQLite and managed MySQL.
  const topicRows = await db.contentItem.groupBy({ by: ['topicSlugs'], _count: true })
  const topicCounts = new Map<string, number>()
  for (const row of topicRows) {
    try {
      const slugs = JSON.parse(row.topicSlugs) as string[]
      for (const s of slugs) topicCounts.set(s, (topicCounts.get(s) ?? 0) + row._count)
    } catch { /* ignore malformed */ }
  }
  const topTopicList = [...topicCounts.entries()]
    .map(([slug, count]) => ({ slug, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 8)

  return NextResponse.json({
    totalItems,
    items24h,
    users,
    bookmarks,
    itemsIngested7d,
    sourcesByType: sourcesByType.map((s) => ({ type: s.type, count: s._count })),
    healthCounts: healthCounts.map((h) => ({ status: h.healthStatus, count: h._count })),
    perDay,
    topTopics: topTopicList,
    topSources,
    ingesting: ingestState.ingesting,
    lastRunAt: ingestState.lastRunAt?.toISOString() ?? null,
  })
}
