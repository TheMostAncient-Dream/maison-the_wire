import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin } from '@/lib/server/auth'

export const dynamic = 'force-dynamic'

/** GET ?sourceId=&limit= — recent health log entries, newest first. */
export async function GET(req: Request) {
  const admin = await requireAdmin()
  if (!admin) return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
  const { searchParams } = new URL(req.url)
  const sourceId = searchParams.get('sourceId')
  const limit = Math.min(200, Math.max(1, Number(searchParams.get('limit') ?? 100) || 100))

  const logs = await db.sourceHealthLog.findMany({
    where: sourceId ? { sourceId } : undefined,
    include: { source: { select: { name: true, slug: true, type: true } } },
    orderBy: { createdAt: 'desc' },
    take: limit,
  })

  return NextResponse.json(
    logs.map((l) => ({
      id: l.id,
      sourceName: l.source.name,
      sourceSlug: l.source.slug,
      sourceType: l.source.type,
      status: l.status,
      message: l.message,
      itemCount: l.itemCount,
      durationMs: l.durationMs,
      createdAt: l.createdAt.toISOString(),
    }))
  )
}
