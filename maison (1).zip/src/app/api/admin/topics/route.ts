import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin } from '@/lib/server/auth'
import { bumpDataEpoch } from '@/lib/server/cache'
import { logAdminAction } from '@/lib/server/audit'

export const dynamic = 'force-dynamic'

function slugify(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40)
}

export async function GET() {
  const admin = await requireAdmin()
  if (!admin) return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
  const topics = await db.topic.findMany({ orderBy: { sortOrder: 'asc' } })
  return NextResponse.json(topics)
}

export async function POST(req: Request) {
  const admin = await requireAdmin()
  if (!admin) return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
  const body = await req.json()
  const name = String(body.name ?? '').trim()
  if (!name) return NextResponse.json({ error: 'Name is required' }, { status: 400 })
  const slug = slugify(String(body.slug ?? name))
  if (!slug) return NextResponse.json({ error: 'Invalid slug' }, { status: 400 })
  const exists = await db.topic.findUnique({ where: { slug } })
  if (exists) return NextResponse.json({ error: 'Topic slug already exists' }, { status: 409 })
  const maxOrder = await db.topic.aggregate({ _max: { sortOrder: true } })
  const topic = await db.topic.create({
    data: {
      slug,
      name: name.slice(0, 60),
      description: body.description ? String(body.description).slice(0, 200) : null,
      sortOrder: (maxOrder._max.sortOrder ?? 0) + 1,
    },
  })
  bumpDataEpoch()
  await logAdminAction(admin.id, 'topic.create', topic.id, `${topic.name} (${slug}) created`)
  return NextResponse.json({ topic })
}

export async function PUT(req: Request) {
  const admin = await requireAdmin()
  if (!admin) return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
  const body = await req.json()
  const id = String(body.id ?? '')
  if (!id) return NextResponse.json({ error: 'id is required' }, { status: 400 })
  const data: Record<string, unknown> = {}
  if (body.name !== undefined) data.name = String(body.name).trim().slice(0, 60)
  if (body.description !== undefined) data.description = body.description ? String(body.description).slice(0, 200) : null
  if (body.sortOrder !== undefined) data.sortOrder = Number(body.sortOrder) || 0
  await db.topic.update({ where: { id }, data })
  bumpDataEpoch()
  await logAdminAction(admin.id, 'topic.update', id, `topic edited (${Object.keys(data).join(', ')})`)
  return NextResponse.json({ ok: true })
}

export async function DELETE(req: Request) {
  const admin = await requireAdmin()
  if (!admin) return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
  const { searchParams } = new URL(req.url)
  const id = searchParams.get('id')
  if (!id) return NextResponse.json({ error: 'id is required' }, { status: 400 })
  const removed = await db.topic.delete({ where: { id } }).catch(() => null)
  bumpDataEpoch()
  if (removed) await logAdminAction(admin.id, 'topic.delete', id, `${removed.name} removed from the taxonomy`)
  return NextResponse.json({ ok: true })
}
