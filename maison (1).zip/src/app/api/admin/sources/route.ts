import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin } from '@/lib/server/auth'
import { bumpDataEpoch } from '@/lib/server/cache'
import { logAdminAction } from '@/lib/server/audit'

export const dynamic = 'force-dynamic'

function slugify(name: string): string {
  return name
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60)
}

/** GET /api/admin/sources — full registry incl. disabled & erroring sources. */
export async function GET() {
  const admin = await requireAdmin()
  if (!admin) return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
  const sources = await db.source.findMany({
    orderBy: [{ type: 'asc' }, { name: 'asc' }],
    include: { _count: { select: { items: true } } },
  })
  return NextResponse.json(
    sources.map((s) => ({
      id: s.id,
      slug: s.slug,
      name: s.name,
      type: s.type,
      websiteUrl: s.websiteUrl,
      feedUrl: s.feedUrl,
      externalId: s.externalId,
      country: s.country,
      language: s.language,
      topicSlugs: JSON.parse(s.topicSlugs),
      logoUrl: s.logoUrl,
      prominence: s.prominence,
      fetchIntervalMin: s.fetchIntervalMin,
      isActive: s.isActive,
      healthStatus: s.healthStatus,
      lastFetchedAt: s.lastFetchedAt?.toISOString() ?? null,
      lastSuccessAt: s.lastSuccessAt?.toISOString() ?? null,
      lastError: s.lastError,
      consecutiveFailures: s.consecutiveFailures,
      itemsCount: s._count.items,
    }))
  )
}

/** POST — add a new source to the registry. */
export async function POST(req: Request) {
  const admin = await requireAdmin()
  if (!admin) return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
  const body = await req.json()
  const name = String(body.name ?? '').trim()
  const type = String(body.type ?? '')
  if (!name) return NextResponse.json({ error: 'Name is required' }, { status: 400 })
  if (!['rss', 'youtube', 'instagram'].includes(type)) return NextResponse.json({ error: 'Type must be rss, youtube or instagram' }, { status: 400 })
  if (type === 'rss' && !/^https?:\/\//.test(String(body.feedUrl ?? ''))) {
    return NextResponse.json({ error: 'A valid RSS feed URL is required' }, { status: 400 })
  }
  if (type === 'youtube' && !/^UC[\w-]{20,}$/.test(String(body.externalId ?? ''))) {
    return NextResponse.json({ error: 'YouTube channel ID must look like UC…' }, { status: 400 })
  }

  const slug = slugify(String(body.slug ?? name)) || `src-${Date.now()}`
  const exists = await db.source.findUnique({ where: { slug } })
  if (exists) return NextResponse.json({ error: 'A source with this slug already exists' }, { status: 409 })

  const source = await db.source.create({
    data: {
      slug,
      name: name.slice(0, 120),
      type,
      feedUrl: type === 'rss' ? String(body.feedUrl).trim() : null,
      websiteUrl: body.websiteUrl ? String(body.websiteUrl).trim() : null,
      externalId: body.externalId ? String(body.externalId).trim() : null,
      country: body.country ? String(body.country).trim().slice(0, 8) : null,
      language: body.language ? String(body.language).trim().slice(0, 8) : 'en',
      topicSlugs: JSON.stringify(Array.isArray(body.topicSlugs) && body.topicSlugs.length ? body.topicSlugs.slice(0, 4) : ['world']),
      logoUrl: body.logoUrl ? String(body.logoUrl).trim() : null,
      prominence: Math.min(3, Math.max(1, Number(body.prominence) || 1)),
      fetchIntervalMin: Math.min(120, Math.max(3, Number(body.fetchIntervalMin) || 10)),
      isActive: true,
    },
  })
  bumpDataEpoch()
  await logAdminAction(admin.id, 'source.create', source.id, `${source.name} (${type}) added to the registry`)
  return NextResponse.json({ source })
}

/** PUT {id, …fields} — edit an existing source. */
export async function PUT(req: Request) {
  const admin = await requireAdmin()
  if (!admin) return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
  const body = await req.json()
  const id = String(body.id ?? '')
  if (!id) return NextResponse.json({ error: 'id is required' }, { status: 400 })
  const source = await db.source.findUnique({ where: { id } })
  if (!source) return NextResponse.json({ error: 'Source not found' }, { status: 404 })

  const data: Record<string, unknown> = {}
  if (body.name !== undefined) data.name = String(body.name).trim().slice(0, 120)
  if (body.feedUrl !== undefined) data.feedUrl = body.feedUrl ? String(body.feedUrl).trim() : null
  if (body.websiteUrl !== undefined) data.websiteUrl = body.websiteUrl ? String(body.websiteUrl).trim() : null
  if (body.externalId !== undefined) data.externalId = body.externalId ? String(body.externalId).trim() : null
  if (body.country !== undefined) data.country = body.country ? String(body.country).trim().slice(0, 8) : null
  if (body.language !== undefined) data.language = String(body.language).trim().slice(0, 8) || 'en'
  if (body.topicSlugs !== undefined && Array.isArray(body.topicSlugs)) data.topicSlugs = JSON.stringify(body.topicSlugs.slice(0, 4))
  if (body.prominence !== undefined) data.prominence = Math.min(3, Math.max(1, Number(body.prominence) || 1))
  if (body.fetchIntervalMin !== undefined) data.fetchIntervalMin = Math.min(120, Math.max(3, Number(body.fetchIntervalMin) || 10))
  if (body.isActive !== undefined) {
    data.isActive = !!body.isActive
    if (data.isActive) {
      data.consecutiveFailures = 0
      data.healthStatus = 'unknown'
      data.lastError = null
    }
  }

  await db.source.update({ where: { id }, data })
  bumpDataEpoch()
  const action = body.isActive !== undefined ? (body.isActive ? 'source.enable' : 'source.disable') : 'source.update'
  await logAdminAction(
    admin.id,
    action,
    id,
    body.isActive !== undefined
      ? `${source.name} ${body.isActive ? 'enabled' : 'disabled'}`
      : `${source.name} edited (${Object.keys(data).join(', ')})`
  )
  return NextResponse.json({ ok: true })
}

/** DELETE ?id= — remove a source and its items/logs. */
export async function DELETE(req: Request) {
  const admin = await requireAdmin()
  if (!admin) return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
  const { searchParams } = new URL(req.url)
  const id = searchParams.get('id')
  if (!id) return NextResponse.json({ error: 'id is required' }, { status: 400 })
  const source = await db.source.findUnique({ where: { id }, select: { name: true } })
  if (!source) return NextResponse.json({ error: 'Source not found' }, { status: 404 })
  await db.source.delete({ where: { id } })
  bumpDataEpoch()
  await logAdminAction(admin.id, 'source.delete', id, `${source.name} removed from the registry`)
  return NextResponse.json({ ok: true })
}
