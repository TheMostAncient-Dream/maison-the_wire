import { NextResponse } from 'next/server'
import { requireAdmin } from '@/lib/server/auth'
import { runIngestion } from '@/lib/server/ingest'
import { rateLimit, clientIp } from '@/lib/server/cache'
import { logAdminAction } from '@/lib/server/audit'

export const dynamic = 'force-dynamic'
export const maxDuration = 300

/** POST {sourceId?} — trigger a manual (re)fetch. Force = ignore interval/backoff. */
export async function POST(req: Request) {
  const admin = await requireAdmin()
  if (!admin) return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
  if (!rateLimit(`ingest:${clientIp(req)}`, 6, 60_000)) {
    return NextResponse.json({ error: 'Manual refetch is rate-limited. Wait a moment.' }, { status: 429 })
  }
  let sourceId: string | undefined
  try {
    const body = await req.json()
    sourceId = body.sourceId ? String(body.sourceId) : undefined
  } catch {
    /* empty body = full run */
  }
  const result = await runIngestion({ force: true, onlySourceId: sourceId })
  await logAdminAction(
    admin.id,
    sourceId ? 'ingest.refetch' : 'ingest.run-all',
    sourceId ?? null,
    sourceId
      ? `manual refetch: ${result.ingested ?? 0} fetched, ${result.newItems ?? 0} new`
      : `full run: ${result.ingested ?? 0} fetched, ${result.newItems ?? 0} new`
  )
  return NextResponse.json(result)
}
