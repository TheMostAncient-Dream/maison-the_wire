import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/server/auth'
import { rateLimit, clientIp } from '@/lib/server/cache'
import { isPushConfigured } from '@/lib/server/push'

export const dynamic = 'force-dynamic'

/**
 * Notification preferences — the single store both the onboarding flow and
 * the Settings section read/write. notifySourceIds lives on the User row
 * (JSON string[] of Source ids, the schema's list convention).
 */

async function currentState(userId: string) {
  const user = await db.user.findUnique({
    where: { id: userId },
    select: { notifySourceIds: true, onboardingCompletedAt: true },
  })
  let notifySourceIds: string[] = []
  try {
    notifySourceIds = user ? (JSON.parse(user.notifySourceIds) as string[]) : []
  } catch {
    /* malformed — treat as empty */
  }
  return {
    notifySourceIds,
    onboarded: user?.onboardingCompletedAt != null,
    pushSupported: isPushConfigured(),
    vapidPublicKey: process.env.VAPID_PUBLIC_KEY ?? null,
  }
}

export async function GET() {
  const user = await getSessionUser()
  if (!user) return NextResponse.json({ error: 'Sign in first' }, { status: 401 })
  return NextResponse.json(await currentState(user.id))
}

export async function PUT(req: Request) {
  const user = await getSessionUser()
  if (!user) return NextResponse.json({ error: 'Sign in first' }, { status: 401 })
  if (!rateLimit(`notif:${clientIp(req)}`, 30, 60_000)) {
    return NextResponse.json({ error: 'Too many updates. Wait a moment.' }, { status: 429 })
  }

  let body: {
    notifySourceIds?: unknown
    completeOnboarding?: unknown
  }
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid request body' }, { status: 400 })
  }

  const data: { notifySourceIds?: string; onboardingCompletedAt?: Date } = {}

  if (body.notifySourceIds !== undefined) {
    if (!Array.isArray(body.notifySourceIds)) {
      return NextResponse.json({ error: 'notifySourceIds must be an array' }, { status: 400 })
    }
    // Keep only ids that actually exist in the registry — no dangling refs.
    const wanted = [...new Set(body.notifySourceIds.map((x) => String(x).slice(0, 60)))].slice(0, 100)
    const found = await db.source.findMany({
      where: { id: { in: wanted } },
      select: { id: true },
    })
    const valid = new Set(found.map((s) => s.id))
    data.notifySourceIds = JSON.stringify(wanted.filter((id) => valid.has(id)))
  }

  if (body.completeOnboarding === true) {
    const existing = await db.user.findUnique({
      where: { id: user.id },
      select: { onboardingCompletedAt: true },
    })
    if (existing && existing.onboardingCompletedAt == null) {
      data.onboardingCompletedAt = new Date()
    }
  }

  if (Object.keys(data).length > 0) {
    await db.user.update({ where: { id: user.id }, data })
  }
  return NextResponse.json(await currentState(user.id))
}
