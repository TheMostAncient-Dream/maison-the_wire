import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/server/auth'
import { rateLimit, clientIp } from '@/lib/server/cache'

export const dynamic = 'force-dynamic'

/**
 * Browser push subscriptions — created only after the reader has expressed
 * intent (onboarding Step 2 or the Settings section) and granted permission.
 * One row per browser profile (endpoint is unique); re-subscribing the same
 * endpoint simply refreshes the keys.
 */

interface SubscriptionBody {
  endpoint?: unknown
  keys?: { p256dh?: unknown; auth?: unknown }
}

function parseSubscription(raw: unknown): { endpoint: string; p256dh: string; auth: string } | null {
  const sub = raw as SubscriptionBody | null
  if (!sub || typeof sub.endpoint !== 'string' || !sub.keys) return null
  const { endpoint, keys } = sub
  if (!/^https:\/\//.test(endpoint) && !/^http:\/\/localhost(:\d+)?/.test(endpoint)) return null
  if (endpoint.length > 2000) return null
  if (typeof keys.p256dh !== 'string' || typeof keys.auth !== 'string') return null
  if (!keys.p256dh || keys.p256dh.length > 512 || !keys.auth || keys.auth.length > 512) return null
  return { endpoint, p256dh: keys.p256dh, auth: keys.auth }
}

export async function POST(req: Request) {
  const user = await getSessionUser()
  if (!user) return NextResponse.json({ error: 'Sign in first' }, { status: 401 })
  // Desk alerts ring at an address — an unproven address rings nobody.
  if (!user.emailVerified && user.role !== 'admin') {
    return NextResponse.json(
      {
        error: 'Verify your email address first — quiet alerts wait on it.',
        code: 'email_unverified',
      },
      { status: 403 }
    )
  }
  if (!rateLimit(`pushsub:${clientIp(req)}`, 20, 60_000)) {
    return NextResponse.json({ error: 'Too many attempts. Try again later.' }, { status: 429 })
  }
  try {
    const body = await req.json()
    const sub = parseSubscription(body.subscription ?? body)
    if (!sub) return NextResponse.json({ error: 'Malformed subscription' }, { status: 400 })

    await db.pushSubscription.upsert({
      where: { endpoint: sub.endpoint },
      update: { userId: user.id, p256dh: sub.p256dh, auth: sub.auth },
      create: { userId: user.id, endpoint: sub.endpoint, p256dh: sub.p256dh, auth: sub.auth },
    })
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'Could not store the subscription' }, { status: 500 })
  }
}

export async function DELETE(req: Request) {
  const user = await getSessionUser()
  if (!user) return NextResponse.json({ error: 'Sign in first' }, { status: 401 })
  try {
    const body = await req.json()
    const endpoint = typeof body.endpoint === 'string' ? body.endpoint : null
    if (!endpoint || endpoint.length > 2000) {
      return NextResponse.json({ error: 'Malformed request' }, { status: 400 })
    }
    // Ownership check — a reader may only retire their own endpoints.
    const res = await db.pushSubscription.deleteMany({ where: { endpoint, userId: user.id } })
    return NextResponse.json({ ok: true, removed: res.count })
  } catch {
    return NextResponse.json({ error: 'Could not remove the subscription' }, { status: 500 })
  }
}
