import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/server/auth'
import { rateLimit, clientIp } from '@/lib/server/cache'
import { issueEmailVerification, RESEND_COOLDOWN_MS } from '@/lib/server/verification'

export const dynamic = 'force-dynamic'

/**
 * Send another code — after the cooldown, never before. Each issuance
 * replaces the pending hash and restarts the clock.
 */
export async function POST(req: Request) {
  const user = await getSessionUser()
  if (!user) return NextResponse.json({ error: 'Sign in first' }, { status: 401 })
  if (!rateLimit(`resend:${user.id}`, 5, 15 * 60_000) ||
      !rateLimit(`resend-ip:${clientIp(req)}`, 10, 15 * 60_000)) {
    return NextResponse.json({ error: 'Too many attempts. Try again later.' }, { status: 429 })
  }
  try {
    const row = await db.user.findUnique({
      where: { id: user.id },
      select: { emailVerifiedAt: true, verificationSentAt: true },
    })
    if (!row) return NextResponse.json({ error: 'Sign in first' }, { status: 401 })
    if (row.emailVerifiedAt) return NextResponse.json({ ok: true, verified: true })

    if (row.verificationSentAt) {
      const resendAfter = row.verificationSentAt.getTime() + RESEND_COOLDOWN_MS
      if (Date.now() < resendAfter) {
        return NextResponse.json(
          { error: 'Another letter is already on its way — give it a minute.', retryAfterMs: resendAfter - Date.now() },
          { status: 429 }
        )
      }
    }

    const issued = await issueEmailVerification(user.id, user.email)
    return NextResponse.json({
      ok: true,
      expiresAt: issued.expiresAt,
      resendAfter: issued.sentAt + RESEND_COOLDOWN_MS,
      ...(issued.devCode ? { devCode: issued.devCode } : {}),
    })
  } catch {
    return NextResponse.json({ error: 'Could not send another code' }, { status: 500 })
  }
}
