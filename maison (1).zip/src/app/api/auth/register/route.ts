import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { hashPassword, createToken, SESSION_COOKIE, sessionCookieOptions } from '@/lib/server/auth'
import { rateLimit, clientIp } from '@/lib/server/cache'
import { issueEmailVerification } from '@/lib/server/verification'

export const dynamic = 'force-dynamic'

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

export async function POST(req: Request) {
  if (!rateLimit(`register:${clientIp(req)}`, 5, 15 * 60_000)) {
    return NextResponse.json({ error: 'Too many attempts. Try again later.' }, { status: 429 })
  }
  try {
    const body = await req.json()
    const email = String(body.email ?? '').trim().toLowerCase()
    const password = String(body.password ?? '')
    const name = String(body.name ?? '').trim().slice(0, 80) || null

    if (!EMAIL_RE.test(email)) return NextResponse.json({ error: 'Please enter a valid email address' }, { status: 400 })
    if (password.length < 8) return NextResponse.json({ error: 'Password must be at least 8 characters' }, { status: 400 })

    const existing = await db.user.findUnique({ where: { email } })
    if (existing) return NextResponse.json({ error: 'An account with this email already exists' }, { status: 409 })

    const user = await db.user.create({
      data: {
        email,
        name,
        passwordHash: hashPassword(password),
        role: 'user',
        preference: { create: {} },
      },
    })

    // The post goes out with the subscription — a timed code to prove the
    // address. A mail failure must never block the registration itself.
    let verification: { expiresAt: number; resendAfter: number; devCode?: string } | undefined
    try {
      const issued = await issueEmailVerification(user.id, email)
      verification = {
        expiresAt: issued.expiresAt,
        resendAfter: issued.sentAt + (Number(process.env.MAIL_RESEND_COOLDOWN_SEC) || 60) * 1000,
        ...(issued.devCode ? { devCode: issued.devCode } : {}),
      }
    } catch {
      verification = undefined
    }

    const token = createToken(user.id, 0)
    const res = NextResponse.json({
      user: { id: user.id, email: user.email, name: user.name, role: user.role, onboarded: false },
      ...(verification ? { verification } : {}),
    })
    res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions)
    return res
  } catch {
    return NextResponse.json({ error: 'Registration failed' }, { status: 500 })
  }
}
