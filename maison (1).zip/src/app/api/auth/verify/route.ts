import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser, verifyPassword } from '@/lib/server/auth'
import { rateLimit, clientIp } from '@/lib/server/cache'

export const dynamic = 'force-dynamic'

/**
 * Prove the address: the reader answers with the six digits the post
 * delivered. The code dies at its expiry (default 15 minutes); wrong
 * guesses are rate-limited per account (they are password guesses).
 * Success stamps emailVerifiedAt and retires the code.
 */
export async function POST(req: Request) {
  const user = await getSessionUser()
  if (!user) return NextResponse.json({ error: 'Sign in first' }, { status: 401 })
  if (!rateLimit(`verify:${user.id}`, 10, 10 * 60_000) ||
      !rateLimit(`verify-ip:${clientIp(req)}`, 30, 15 * 60_000)) {
    return NextResponse.json(
      { error: 'Too many attempts. Wait a little, then ask for a fresh code.' },
      { status: 429 }
    )
  }
  try {
    const body = await req.json()
    const code = String(body.code ?? '').replace(/\s+/g, '')
    if (!/^\d{6}$/.test(code)) {
      return NextResponse.json({ error: 'The code is six digits.' }, { status: 400 })
    }

    const row = await db.user.findUnique({
      where: { id: user.id },
      select: {
        emailVerifiedAt: true,
        verificationCodeHash: true,
        verificationExpiresAt: true,
      },
    })
    if (!row) return NextResponse.json({ error: 'Sign in first' }, { status: 401 })
    if (row.emailVerifiedAt) return NextResponse.json({ ok: true }) // already proven

    if (!row.verificationCodeHash || !row.verificationExpiresAt) {
      return NextResponse.json(
        { error: 'No code is on its way — send one first.', noPending: true },
        { status: 400 }
      )
    }
    if (row.verificationExpiresAt.getTime() <= Date.now()) {
      return NextResponse.json(
        { error: 'That code has expired — send another.', expired: true },
        { status: 410 }
      )
    }
    if (!verifyPassword(code, row.verificationCodeHash)) {
      return NextResponse.json({ error: "That code doesn't match the letter." }, { status: 400 })
    }

    await db.user.update({
      where: { id: user.id },
      data: {
        emailVerifiedAt: new Date(),
        verificationCodeHash: null,
        verificationExpiresAt: null,
        // verificationSentAt stays — it is history, not a pending code
      },
    })
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'Could not check the code' }, { status: 500 })
  }
}
