import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/server/auth'
import { verificationSnapshot } from '@/lib/server/verification'

export const dynamic = 'force-dynamic'

/**
 * Verification status for the signed-in reader — the verify screen reads
 * this on mount: whether the address is proven, when the pending code dies,
 * when another may be sent, and (dev only) the demo-post code itself.
 */
export async function GET() {
  const user = await getSessionUser()
  if (!user) return NextResponse.json({ error: 'Sign in first' }, { status: 401 })
  try {
    const row = await db.user.findUnique({
      where: { id: user.id },
      select: {
        id: true,
        emailVerifiedAt: true,
        verificationExpiresAt: true,
        verificationSentAt: true,
      },
    })
    if (!row) return NextResponse.json({ error: 'Sign in first' }, { status: 401 })
    return NextResponse.json(verificationSnapshot(row))
  } catch {
    return NextResponse.json({ error: 'Could not read the verification state' }, { status: 500 })
  }
}
