import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser, SESSION_COOKIE } from '@/lib/server/auth'

export const dynamic = 'force-dynamic'

/**
 * POST — clear the session cookie. With { everywhere: true } the user's
 * sessionVersion is bumped first, which invalidates every token issued
 * for that account (other browsers, other devices) immediately.
 */
export async function POST(req: Request) {
  let everywhere = false
  try {
    const body = await req.json()
    everywhere = body?.everywhere === true
  } catch {
    /* plain sign-out has no body */
  }

  if (everywhere) {
    const user = await getSessionUser()
    if (user) {
      await db.user.update({
        where: { id: user.id },
        data: { sessionVersion: { increment: 1 }, failedLogins: 0, lockedUntil: null },
      })
    }
  }

  const res = NextResponse.json({ ok: true, everywhere })
  res.cookies.set(SESSION_COOKIE, '', { path: '/', maxAge: 0 })
  return res
}
