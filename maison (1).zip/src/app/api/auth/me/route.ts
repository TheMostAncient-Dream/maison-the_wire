import { NextResponse } from 'next/server'
import { getSessionUser } from '@/lib/server/auth'
import { getUserPrefs } from '@/lib/server/content'

export const dynamic = 'force-dynamic'

export async function GET() {
  const user = await getSessionUser()
  if (!user) return NextResponse.json({ user: null, prefs: null })
  const prefs = await getUserPrefs(user.id)
  return NextResponse.json({ user, prefs })
}
