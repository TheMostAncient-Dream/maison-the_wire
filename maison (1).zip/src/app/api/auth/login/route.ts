import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { createToken, verifyPassword, SESSION_COOKIE, sessionCookieOptions } from '@/lib/server/auth'
import { rateLimit, clientIp } from '@/lib/server/cache'

export const dynamic = 'force-dynamic'

const MAX_FAILED = 5 // consecutive failures before the account cools down
const LOCKOUT_MS = 15 * 60_000
const GENERIC_LOCKED = 'Too many attempts. Try again later.'

export async function POST(req: Request) {
  // Brute force is the realistic attack here: 8 attempts / 15 min / IP.
  if (!rateLimit(`login:${clientIp(req)}`, 8, 15 * 60_000)) {
    return NextResponse.json({ error: GENERIC_LOCKED }, { status: 429 })
  }
  try {
    const body = await req.json()
    const email = String(body.email ?? '').trim().toLowerCase()
    const password = String(body.password ?? '')
    if (!email || !password) {
      return NextResponse.json({ error: 'Email and password are required' }, { status: 400 })
    }

    const user = await db.user.findUnique({ where: { email } })

    // Per-account backoff — independent of which IP the attempts come from.
    if (user?.lockedUntil && user.lockedUntil.getTime() > Date.now()) {
      return NextResponse.json({ error: GENERIC_LOCKED }, { status: 429 })
    }

    if (!user || !verifyPassword(password, user.passwordHash)) {
      if (user) {
        const failed = user.failedLogins + 1
        await db.user.update({
          where: { id: user.id },
          data: {
            failedLogins: failed >= MAX_FAILED ? MAX_FAILED : failed,
            lockedUntil: failed >= MAX_FAILED ? new Date(Date.now() + LOCKOUT_MS) : null,
          },
        })
      }
      // Generic message — never reveal whether the email exists.
      return NextResponse.json({ error: 'Invalid email or password' }, { status: 401 })
    }

    await db.user.update({
      where: { id: user.id },
      data: { failedLogins: 0, lockedUntil: null },
    })
    const token = createToken(user.id, user.sessionVersion)
    const res = NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        onboarded: user.onboardingCompletedAt != null,
      },
    })
    res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions)
    return res
  } catch {
    return NextResponse.json({ error: 'Login failed' }, { status: 500 })
  }
}
