import { NextResponse } from 'next/server'
import { getStatus } from '@/lib/server/content'
import { ensureSchedulerStarted } from '@/lib/server/ingest'

export const dynamic = 'force-dynamic'

export async function GET() {
  // Lazy-start the ingestion scheduler (idempotent) in case instrumentation
  // didn't run on this server boot.
  if (process.env.MAISON_DISABLE_BACKGROUND_INGESTION !== 'true') {
    ensureSchedulerStarted()
  }
  const status = await getStatus()
  return NextResponse.json(status)
}
