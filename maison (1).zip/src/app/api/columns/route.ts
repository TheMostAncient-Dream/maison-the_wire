import { NextResponse } from 'next/server'
import { getSessionUser } from '@/lib/server/auth'
import { getColumnFeed, getUserPrefs } from '@/lib/server/content'
import { rateLimit, clientIp } from '@/lib/server/cache'
import { DEFAULT_PREFS, type ItemType } from '@/lib/types'

export const dynamic = 'force-dynamic'

const PSEUDO_TOPICS = new Set(['latest', 'trending'])

export async function GET(req: Request) {
  if (!rateLimit(`columns:${clientIp(req)}`, 120, 60_000)) {
    return NextResponse.json({ error: 'Rate limit exceeded' }, { status: 429 })
  }
  const { searchParams } = new URL(req.url)

  const user = await getSessionUser()
  let columns: string[]
  let sourceSlugs: string[] = []
  let contentTypes: ItemType[] = ['article', 'video']
  let languages: string[] = []
  let countries: string[] = []
  let itemsPerColumn: number

  if (user) {
    const prefs = await getUserPrefs(user.id)
    columns = prefs.columns
    sourceSlugs = prefs.sourceSlugs
    contentTypes = prefs.contentTypes
    languages = prefs.languages
    countries = prefs.countries
    itemsPerColumn = prefs.itemsPerColumn
  } else {
    // Guests: client passes its locally-persisted config.
    columns = (searchParams.get('columns') ?? DEFAULT_PREFS.columns.join(','))
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean)
      .slice(0, 12)
    itemsPerColumn = Math.min(30, Math.max(4, Number(searchParams.get('limit') ?? DEFAULT_PREFS.itemsPerColumn) || DEFAULT_PREFS.itemsPerColumn))
    sourceSlugs = (searchParams.get('sources') ?? '').split(',').filter(Boolean)
    contentTypes = (searchParams.get('types') ?? 'article,video')
      .split(',')
      .filter((type): type is ItemType => type === 'article' || type === 'video' || type === 'instagram')
  }

  const limited = await Promise.all(
    columns.map(async (slug) => ({
      slug,
      items: await getColumnFeed(slug, itemsPerColumn, { sourceSlugs, contentTypes, languages, countries }),
    }))
  )

  return NextResponse.json({ columns: limited, itemsPerColumn })
}
