import type { Metadata } from "next";
import { GridLines, NoiseOverlay } from "@/components/luxe/atoms";
import { FeedExperience } from "@/components/luxe/feed/feed-experience";
import { NewsModalProvider } from "@/components/luxe/feed/news-modal";
import { HeadingHop } from "@/components/luxe/heading-hop";
import { RuleRandomizer } from "@/components/luxe/rule-randomizer";
import { AdminConsole } from "@/components/luxe/sections/admin-console";
import { ColumnsView } from "@/components/luxe/sections/columns-view";
import { FrontPage } from "@/components/luxe/sections/front-page";
import { Masthead } from "@/components/luxe/sections/masthead";
import { SavedView } from "@/components/luxe/sections/saved-view";
import { SiteFooter } from "@/components/luxe/sections/site-footer";
import { SourcesView } from "@/components/luxe/sections/sources-view";
import { SessionProvider } from "@/components/luxe/session/session-provider";
import { SiteNav } from "@/components/luxe/site-nav";
import { getItemById } from "@/lib/server/content";
import { siteUrl } from "@/lib/site-url";

export const dynamic = "force-dynamic";

/**
 * Per-dispatch metadata — a deep link landing with the ?item=<id> query
 * shares a card with the story's own headline, source and date instead
 * of the homepage's blank one.
 */
export async function generateMetadata({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}): Promise<Metadata> {
  const params = await searchParams;
  const id = typeof params.item === "string" ? params.item : undefined;
  if (!id) return {};

  const item = await getItemById(id).catch(() => null);
  if (!item) return {};

  const published = new Date(item.publishedAt);
  const description =
    item.snippet?.trim().slice(0, 155) ||
    `${item.source.name} — ${published.toLocaleDateString("en-GB", { day: "2-digit", month: "long", year: "numeric" })}`;
  const canonical = siteUrl();
  const shareImage = item.thumbnailUrl && /^https?:\/\//i.test(item.thumbnailUrl)
    ? item.thumbnailUrl
    : undefined;

  return {
    title: `${item.title} — MAISON`,
    description,
    ...(canonical ? { alternates: { canonical: `${canonical}/?item=${item.id}` } } : {}),
    openGraph: {
      type: "article",
      title: item.title,
      description,
      siteName: "MAISON",
      publishedTime: published.toISOString(),
      ...(canonical ? { url: `${canonical}/?item=${item.id}` } : {}),
      ...(shareImage ? { images: [{ url: shareImage, alt: item.title }] } : {}),
    },
    twitter: {
      card: shareImage ? "summary_large_image" : "summary",
      title: item.title,
      description,
      ...(shareImage ? { images: [shareImage] } : {}),
    },
  };
}

export default function Home() {
  return (
    <div className="relative flex min-h-screen flex-col">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:bg-alabaster focus:px-4 focus:py-3 focus:text-charcoal focus:shadow-lg"
      >
        Skip to content
      </a>
      {/* Fixed structural layers: editorial grid + paper grain */}
      <GridLines />
      <NoiseOverlay />
      {/* Every third editorial rule breaks formation — fully random per load */}
      <RuleRandomizer />
      {/* Display headings give a small jump on the first hover */}
      <HeadingHop />

      {/* Session sits above everything — the nav, cards and views all
          read the reader (account, saved marks, preferences) from it. */}
      <SessionProvider>
        <NewsModalProvider>
          <SiteNav />

          <main id="main" tabIndex={-1} className="relative z-10 flex-1">
            <Masthead />
            <FrontPage />
            <FeedExperience />
            <ColumnsView />
            <SourcesView />
            <SavedView />
            <AdminConsole />
          </main>

          <SiteFooter />
        </NewsModalProvider>
      </SessionProvider>
    </div>
  );
}
