/**
 * 404 — the same paper as the rest of the edition, not the framework's
 * white default. A quiet note that the requested page isn't in the
 * archive, with the two doors that matter: the front page and the wire.
 */
export default function NotFound() {
  return (
    <section className="flex min-h-[70vh] items-center justify-center bg-alabaster px-8">
      <div className="max-w-xl py-24 text-center">
        <p className="text-[10px] uppercase tracking-[0.3em] text-warm-grey">
          Forty — Four
        </p>
        <h1 className="mt-6 font-serif text-5xl leading-[0.95] text-charcoal md:text-7xl">
          Lost in the stacks.
        </h1>
        <div className="mx-auto mt-10 h-px w-24 bg-gold" aria-hidden />
        <p className="mx-auto mt-10 max-w-sm text-sm leading-relaxed text-warm-grey">
          The page you asked for isn&apos;t in this edition. It may have been
          moved, retired, or never set in type at all.
        </p>
        <div className="mt-12 flex flex-col items-center justify-center gap-6 sm:flex-row">
          <a
            href="/"
            className="border border-charcoal px-8 py-3.5 text-xs uppercase tracking-[0.25em] text-charcoal transition-colors duration-500 ease-luxe hover:bg-charcoal hover:text-alabaster"
          >
            Front page
          </a>
          <a
            href="/#wire"
            className="text-xs uppercase tracking-[0.25em] text-warm-grey underline-offset-8 transition-colors duration-500 ease-luxe hover:text-gold hover:underline"
          >
            Read the Wire
          </a>
        </div>
      </div>
    </section>
  );
}
