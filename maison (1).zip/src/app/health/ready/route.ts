import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

/**
 * Platform readiness probe. Returns no connection details or application data;
 * the container is ready only when its durable managed database answers.
 */
export async function GET() {
  try {
    await db.$queryRaw`SELECT 1`
    return NextResponse.json({ status: 'ready' }, { status: 200 })
  } catch {
    return NextResponse.json({ status: 'unavailable' }, { status: 503 })
  }
}
