# MAISON refinement and durable deployment plan

## Objective
Refine the supplied MAISON site in place, preserving its luxury-editorial identity, page composition, imagery, content, and working product features. Interpret “debloat” as removing demonstrably unused code/dependencies/assets, reducing avoidable runtime/asset weight, and simplifying repeated implementation—not deleting functionality or flattening the bespoke design. The user has additionally authorized migrating all supplied SQLite application records to the project's managed MySQL database, then preparing deployment and requesting publication confirmation.

## Implementation
Use the uploaded Next.js App Router project as the source of truth. Preserve its Next/React/TypeScript/Prisma architecture, behavior, APIs, supplied content, and account records; keep credentials out of Git and out of logs. The original SQLite database is immutable migration input and must remain unchanged. Inspect the managed database before any writes. Use additive reviewed MySQL schema, transfer every table/row preserving IDs, relationships, serialized JSON text, and UTC timestamps. Validate row counts and deterministic per-table row-content digests, foreign-key integrity, uniqueness, and representative app operations. Do not seed, reset, truncate, drop, or let one dataset overwrite another; stop for explicit resolution if target collisions are found. Adapt SQLite-only query assumptions, regenerate Prisma Client, and keep operational migration tooling separate from seed scripts. The platform DSN's explicit TLS peer-verification setting is translated into Prisma's `sslaccept=strict`; both runtime and migration paths fail closed rather than silently weakening TLS.

Make the Next.js application portable to managed MySQL and add an unauthenticated database-readiness path plus a committed, pinned Node 22.23.4/npm 10.9.9 container build/start contract using `.next/standalone`, static assets, and public assets. Read connection credentials only at runtime; use only unreachable placeholder credentials while building, and never put `.env`, secrets, or the SQLite database in the image. Configure the Webdev `deploy` contract only after the persistent data and runtime are ready. The project currently has `publishing.auto_publish: true`; do not push a deployment-ready checkpoint that would bypass the user's requested publication confirmation. Use the explicit platform publish confirmation flow only after preparation and an appropriate approval.

The previously completed preservation-first site refactor remains the baseline: retain the established bespoke MAISON layouts and component boundaries; improve responsive behavior, keyboard/focus handling, reduced motion, semantics, image/font loading, metadata, and code quality; prune only code/assets/packages proven unused. Keep the required static route manifest and project-level logo metadata. Verify with diagnostics, application checks, and a production build without touching the original SQLite file.

## Structure
- `src/app/`: Next App Router home, metadata, global styles, static SEO files, API handlers, and dedicated runtime health route.
- `src/components/luxe/`: established MAISON editorial site sections and interactions; refine rather than redesign.
- `src/lib/`: shared DTOs/utilities, Prisma access, strict TLS URL adapter, feed aggregation, sessions, and server services; keep database access provider-portable.
- `prisma/`, `db/`, `scripts/`: versioned MySQL schema/migrations, the Python read-only SQLite exporter, Prisma importer, TLS-aware migration runner, and guarded seed; retain `db/custom.db` unchanged as original local source/backup input. Seed tooling must not run as migration.
- `public/`: brand, icons, editorial imagery, service-worker assets, route manifest, and SEO resources.
- `Dockerfile`: reproducible production image with runtime-only database and auth configuration.

## Design
- **Design movement:** retain the existing quiet-luxury editorial / contemporary magazine aesthetic.
- **Core principles:** restrained typography; warm paper and ink; editorial hierarchy; subtle, intentional motion.
- **Color philosophy:** preserve alabaster, charcoal, taupe and the metallic gold accent. Use a deeper shade from the same gold family for text on paper/taupe surfaces to meet AA contrast without shifting the decorative accent or adding an unrelated color.
- **Layout paradigm:** preserve the existing layered masthead, typographic grid and varied editorial columns; tune breakpoints and spacing rather than imposing a new centered-card template.
- **Signature elements:** Playfair-style display serif; fine rules/editorial grid; muted gold details and the supplied photography.
- **Interaction philosophy:** tactile but restrained feedback; strong keyboard focus; no interaction depends solely on hover.
- **Animation:** retain existing gentle editorial reveals; honor reduced-motion preferences and avoid unnecessary work.
- **Typography system:** retain Playfair Display with Inter, using responsive, clear editorial scale.
- **Brand essence:** curated news and culture in an elegant live wire; discerning, calm, precise.
- **Brand voice:** keep the existing concise editorial voice. Examples: “The whole wire, beautifully set.” “A quieter way to stay close to what matters.”
- **Wordmark & logo:** retain the supplied MAISON wordmark/logo assets.
- **Signature color:** the existing muted metallic gold.
