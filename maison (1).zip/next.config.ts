import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  outputFileTracingExcludes: {
    '/*': ['./.env', './.env.*', './db/**/*'],
  },
  reactStrictMode: false,
};

export default nextConfig;
